---
name: AIPSL_Knowledge
title: AI Professional Skills Library — Enterprise Knowledge Base
version: 2.0.0-pass10-frontier-capability
status: GPT-ready Pass 10 build with standing standards, Python tooling, product conversion, and frontier model capability layers
source: AIPSL_Combined_Core_Volumes_I-V.skill.md
generated: 2026-06-28
architecture: three-file AIPSL runtime
companion_files:
  - skill.md
  - patterns.md
  - knowledge.md
---

# AI Professional Skills Library — Enterprise Knowledge Base

## Purpose
Durable governance, maturity, lifecycle, versioning, changelog, and institutional reference material.

## Operating Note
This file is part of the three-file GPT-ready AIPSL architecture. It preserves source material while reorganizing it by execution function.


# Knowledge Base Contract

Use this file for durable AIPSL reference material: governance, maturity, lifecycle, versioning, standards, catalogs, ownership, changelogs, and institutional memory.

## Knowledge Use Rules

1. Treat knowledge as reusable but reviewable, not permanently fixed.
2. Preserve provenance and source routing.
3. Retire or supersede outdated knowledge instead of silently deleting it.
4. Use maturity and governance standards to determine whether a module is ready for release.
5. Maintain changelogs and compatibility notes when modifying the architecture.

## Knowledge Lifecycle

```text
Acquire → Validate → Normalize → Classify → Store → Reuse → Review → Update → Archive → Retire
```


# Refactor Source Map

- R1: Source lines 2490-3124 — Volume I Governance, Maturity, Summary, Changelog
- R2: Source lines 4613-4630 — Volume II Summary and Changelog
- R3: Source lines 5913-6024 — Volume III Publishing, Governance, Summary, Changelog
- R4: Source lines 7255-7337 — Volume IV Governance, Summary, Changelog
- R5: Source lines 9453-9552 — Volume V Governance, Summary, Consolidated Changelog

---


# R1 — Volume I Governance, Maturity, Summary, Changelog

<!-- Source lines 2490-3124 from AIPSL_Combined_Core_Volumes_I-V.skill.md -->


# Part 9 — Enterprise Governance, Versioning & Lifecycle Management

## 9.1 Purpose

The purpose of this chapter is to define the governance model for the AI Professional Skills Library. Governance ensures that changes are intentional, quality is preserved, compatibility is maintained, and the library continues to evolve as a trusted engineering standard.

The governance model applies to:

- Foundation
- Engineering Manual
- Shared Frameworks
- Domain Modules
- Pattern Libraries
- Template Libraries
- Benchmark Suites
- Reference Appendices

## 9.2 Governance Principles

Governance is guided by the following principles:

- **Integrity:** Changes preserve the reliability and coherence of the library.
- **Traceability:** Every modification can be traced to its rationale.
- **Consistency:** Standards are applied uniformly across modules.
- **Transparency:** Significant decisions are documented.
- **Stewardship:** The library is treated as a long-term organizational asset.
- **Continuous Improvement:** Governance should enable evolution without sacrificing stability.

## 9.3 Roles and Responsibilities

Recommended governance roles include:

### Library Steward

Owns the overall direction of the library, approves major structural changes, and resolves conflicts between modules.

### Module Maintainer

Responsible for the quality, documentation, benchmarks, and lifecycle of one or more modules.

### Reviewer

Performs independent technical and quality reviews before release.

### Contributor

Proposes enhancements, corrections, or new modules in accordance with contribution standards.

In smaller projects, a single individual may fulfill multiple roles, but responsibilities should remain conceptually distinct.

## 9.4 Semantic Versioning

The library should follow semantic versioning:

### Major

Breaking architectural changes or substantial reorganizations.

### Minor

New capabilities or chapters that remain backward compatible.

### Patch

Corrections, clarifications, editorial improvements, or benchmark updates that do not materially alter behavior.

Each release should document:

- Version number
- Release date
- Summary of changes
- Compatibility notes
- Known issues

## 9.5 Release Lifecycle

Every release should progress through defined stages:

1. Draft
2. Internal Review
3. Technical Review
4. Quality Validation
5. Release Candidate
6. Production Release
7. Maintenance
8. Superseded
9. Archived

Movement between stages should be supported by documented review and quality evidence.

## 9.6 Change Classification

Changes should be categorized to communicate their expected impact.

### Editorial

Grammar, formatting, clarifications.

### Functional

New workflows, templates, or capabilities.

### Architectural

Changes to inheritance, module organization, or shared services.

### Governance

Policies, standards, review procedures.

### Reference

Benchmarks, examples, pattern catalog updates.

This classification helps determine review depth and version increments.

## 9.7 Change Request Workflow

All significant changes should follow a structured workflow:

```text
Proposal
    │
Impact Assessment
    │
Technical Review
    │
Quality Review
    │
Approval
    │
Implementation
    │
Benchmarking
    │
Regression Testing
    │
Release
```

Each stage should produce documented artifacts.

## 9.8 Compatibility Policy

Backward compatibility should be preserved whenever practical.

When incompatible changes are necessary:

- Explain the rationale.
- Document affected modules.
- Provide migration guidance.
- Increment the major version.

Compatibility should be evaluated for:

- Interfaces
- Templates
- Workflows
- Shared services
- Metadata schemas

## 9.9 Deprecation Strategy

Capabilities may be deprecated when they are:

- Superseded by improved approaches.
- No longer maintained.
- Incompatible with current architecture.
- Operationally obsolete.

Deprecated content should:

- Remain documented until retirement.
- Include migration guidance.
- Record the planned retirement version.
- Explain the replacement.

## 9.10 Contribution Standards

Contributors should provide:

- Purpose
- Scope
- Design rationale
- Dependencies
- Benchmarks
- Test cases
- Documentation
- Version impact
- Known limitations

Submissions lacking essential information should not proceed to review.

## 9.11 Review Boards

For enterprise deployments, consider multiple review perspectives:

### Technical Review

Evaluates architecture, interfaces, and implementation quality.

### Analytical Review

Assesses reasoning, evidence standards, and analytical rigor.

### Quality Review

Verifies benchmarks, regression testing, and documentation.

### Governance Review

Ensures consistency with enterprise policies and strategic direction.

## 9.12 Roadmap Management

The library should maintain a documented roadmap identifying:

- Planned modules
- Planned enhancements
- Technical debt
- Deprecated capabilities
- Research priorities
- Long-term architectural goals

Roadmaps should be reviewed periodically and updated as priorities evolve.

## 9.13 Risk Management

Governance should identify and monitor risks such as:

- Architectural drift
- Duplication
- Outdated guidance
- Inconsistent quality
- Incomplete documentation
- Dependency conflicts
- Benchmark degradation
- Knowledge obsolescence

Mitigation strategies should be documented for significant risks.

## 9.14 Governance Metrics

Suggested indicators include:

- Number of active modules
- Review completion rate
- Benchmark pass rate
- Regression pass rate
- Documentation completeness
- Average time to approve changes
- Technical debt backlog
- Percentage of modules at each maturity level

These metrics provide objective insight into the health of the library.

## 9.15 Enterprise Governance Checklist

Before approving a release, verify:

- Version increment is appropriate.
- Changelog is complete.
- Compatibility assessed.
- Benchmarks executed.
- Regression testing completed.
- Documentation updated.
- Governance reviews completed.
- Roadmap updated if necessary.
- Risks documented.
- Release artifacts archived.

## 9.16 Long-Term Stewardship

The AI Professional Skills Library should be managed as a living engineering standard.

Stewardship responsibilities include:

- Periodic architectural reviews.
- Scheduled knowledge refreshes.
- Benchmark maintenance.
- Pattern library refinement.
- Deprecation of obsolete guidance.
- Incorporation of lessons learned.
- Monitoring developments in AI engineering and updating the library where they materially improve quality.

---

# Part 10 — Enterprise Maturity Model, Continuous Learning & Future Evolution

## 10.1 Purpose

The purpose of this chapter is to establish the long-term operating philosophy for the AI Professional Skills Library. It defines how the library should evolve, how organizational capability should mature, how lessons learned should be incorporated, and how the architecture should remain effective as AI technology changes.

Unlike previous chapters, which focus on building and governing modules, this chapter focuses on building organizational capability.

## 10.2 Philosophy of Continuous Improvement

No engineering library is ever complete.

Every module should be considered an evolving capability rather than a finished artifact.

Continuous improvement should be driven by:

- Operational experience
- User feedback
- Benchmark results
- New engineering practices
- Technological advances
- Regulatory changes
- Lessons learned
- Emerging risks

Improvement should be systematic rather than reactive.

## 10.3 Enterprise Learning Cycle

The recommended improvement cycle is:

```text
Observe
    │
Measure
    │
Analyze
    │
Prioritize
    │
Implement
    │
Validate
    │
Release
    │
Monitor
    │
Capture Lessons
    │
Repeat
```

Every significant release should complete this cycle.

## 10.4 Capability Maturity Model

Every module should be evaluated against five maturity levels.

### Level 1 — Prototype

Characteristics:

- Concept demonstrated.
- Minimal documentation.
- Manual execution.
- Limited testing.
- Experimental architecture.

Suitable for research and proof-of-concept work.

### Level 2 — Operational

Characteristics:

- Defined workflows.
- Documented interfaces.
- Basic benchmarks.
- Basic quality assurance.
- Repeatable execution.

Suitable for internal operational use.

### Level 3 — Professional

Characteristics:

- Modular architecture.
- Enterprise documentation.
- Regression testing.
- Reusable templates.
- Pattern catalog integration.
- Structured benchmarks.

Suitable for professional production environments.

### Level 4 — Enterprise

Characteristics:

- Governance integrated.
- Shared services reused.
- Performance monitored.
- Organizational adoption.
- Comprehensive benchmark coverage.
- Extensive documentation.

Suitable for large organizations.

### Level 5 — Reference Standard

Characteristics:

- Canonical implementation.
- Industry-leading engineering practices.
- Mature governance.
- Comprehensive validation.
- Continuous optimization.
- Extensive interoperability.
- Long-term maintainability.

This represents the target maturity level for every module in the AI Professional Skills Library.

## 10.5 Organizational Adoption

Successful adoption requires more than publishing documentation.

Organizations should establish:

- Governance ownership.
- Standard workflows.
- Review procedures.
- Training materials.
- Quality expectations.
- Release schedules.
- Improvement processes.

The library should become part of normal engineering practice.

## 10.6 Lessons Learned Framework

Every completed project should produce documented lessons learned.

Suggested structure:

### Context

What was attempted?

### Outcome

What happened?

### Successes

Which approaches worked well?

### Challenges

Which problems occurred?

### Root Causes

Why did the problems occur?

### Improvements

What changes should be made?

### Reusable Knowledge

Can new templates, workflows, patterns, or benchmarks be created?

Lessons learned should feed back into the Foundation and shared libraries.

## 10.7 Innovation Pipeline

New capabilities should progress through a structured innovation process.

```text
Idea
    │
Research
    │
Prototype
    │
Evaluation
    │
Pilot
    │
Operational Adoption
    │
Shared Service
    │
Enterprise Standard
```

Not every innovation should become part of the Foundation.

Promotion should depend on demonstrated value and reuse potential.

## 10.8 Technology Evolution

The Foundation should remain technology-neutral.

Architectural guidance should emphasize enduring engineering principles rather than implementation details tied to a specific AI model or platform.

Technology-specific adaptations should be implemented in compatibility appendices rather than modifying the Foundation itself.

This preserves long-term stability while allowing future expansion.

## 10.9 Future-Proofing Principles

The library should be designed to accommodate:

- Larger context windows.
- New reasoning capabilities.
- Improved multimodal processing.
- Expanded automation.
- Enhanced interoperability.
- Emerging evaluation methodologies.
- Advances in knowledge management.
- New deployment environments.

Future evolution should preserve architectural consistency wherever practical.

## 10.10 Organizational Metrics

Organizations adopting the library should monitor:

- Module maturity distribution.
- Benchmark performance trends.
- Defect trends.
- Documentation completeness.
- Reuse rates.
- Shared service adoption.
- Time required to develop new modules.
- User satisfaction.
- Review completion rates.
- Technical debt.

Metrics should inform improvement priorities.

## 10.11 Strategic Roadmap

The long-term roadmap should identify:

### Short-Term (0–12 months)

- Complete Foundation.
- Expand engineering manuals.
- Standardize templates.
- Build benchmark suites.

### Medium-Term (1–3 years)

- Mature domain modules.
- Expand pattern libraries.
- Improve automation.
- Increase interoperability.

### Long-Term (3+ years)

- Continuous optimization.
- Integration with emerging AI technologies.
- Expansion into new domains.
- Industry reference status.

The roadmap should be reviewed and updated periodically.

## 10.12 Enterprise Sustainability

Long-term sustainability depends on:

- Active stewardship.
- Regular reviews.
- Knowledge refresh cycles.
- Contributor engagement.
- Stable governance.
- Clear ownership.
- Comprehensive documentation.
- Ongoing benchmarking.

The objective is to ensure that the library remains useful over decades rather than becoming obsolete after a single generation of AI models.

## 10.13 Foundation Review Checklist

Before declaring the Foundation complete, verify:

- Philosophy documented.
- Engineering principles established.
- Enterprise architecture defined.
- Analytical standards complete.
- Evidence and knowledge framework implemented.
- Workflow engine established.
- Quality system implemented.
- Template and pattern libraries initialized.
- Governance defined.
- Maturity model implemented.
- Continuous improvement process documented.
- Future evolution strategy established.

## 10.14 Completion Criteria

The Foundation is considered complete when it:

- Serves as the authoritative operating system for all downstream modules.
- Eliminates unnecessary duplication.
- Provides reusable engineering guidance.
- Supports enterprise governance.
- Enables modular extension.
- Encourages continuous improvement.
- Remains platform-agnostic.
- Supports long-term organizational adoption.

---

# Foundation Summary

Volume I establishes the AI Professional Operating System that every subsequent engineering manual, shared framework, and domain module will inherit.

Together, its ten parts define:

- Engineering philosophy
- Core design principles
- Enterprise architecture
- Analytical standards
- Evidence and knowledge management
- Workflow orchestration
- Quality assurance
- Reusable templates and patterns
- Governance
- Maturity and continuous improvement

By centralizing these capabilities in a single Foundation, the remainder of the AI Professional Skills Library can focus on domain-specific expertise while maintaining consistency, reducing duplication, and supporting long-term evolution.

---

# Changelog

## v1.0.0

- Consolidated all ten parts of Volume I — Foundation into a single standalone skill file.
- Established the AI Professional Operating System architecture.
- Added engineering principles, analytical standards, evidence framework, workflow engine, QA framework, pattern library, governance, and maturity model.

---



---


# R2 — Volume II Summary and Changelog

<!-- Source lines 4613-4630 from AIPSL_Combined_Core_Volumes_I-V.skill.md -->


# Volume II Summary

Volume II defines the practical engineering methods used to build professional AI capabilities. It translates the Foundation into repeatable practices across systems engineering, requirements, architecture, prompts, context, knowledge, workflows, reasoning, validation, deployment, maintenance, and enterprise integration.

Together, Volume I and Volume II provide the core operating system and engineering manual for all future AIPSL domain modules.

---

# Changelog

## v1.0.0

- Created Volume II — AI Engineering Manual.
- Added systems engineering, requirements engineering, architecture engineering, prompt engineering, context engineering, knowledge engineering, workflow engineering, reasoning engineering, validation engineering, deployment engineering, maintenance engineering, and enterprise integration.
- Designed as a standalone skill file inheriting Volume I — Foundation.

---



---


# R3 — Volume III Publishing, Governance, Summary, Changelog

<!-- Source lines 5913-6024 from AIPSL_Combined_Core_Volumes_I-V.skill.md -->


# Part 13 — Publishing, Governance & Continuous Improvement

## 13.1 Purpose

Publishing and governance ensure that skills are released, maintained, and improved responsibly.

## 13.2 Release Package

A professional skill release should include:

- Skill file
- Version number
- Changelog
- Benchmark suite
- Known limitations
- Example cases
- Maintenance notes

## 13.3 Changelog Template

```markdown
# Changelog

## vX.Y.Z

Added:
Changed:
Fixed:
Deprecated:
Known Issues:
```

## 13.4 Versioning Rules

- Major version for breaking architecture changes.
- Minor version for new compatible capabilities.
- Patch version for fixes and clarifications.

## 13.5 Governance Checklist

- Owner assigned.
- Version assigned.
- Changelog updated.
- Benchmarks passed.
- Known limitations documented.
- Compatibility checked.
- Maintenance schedule defined.

## 13.6 Continuous Improvement

Improvement sources include:

- User feedback
- Benchmark failures
- Regression tests
- New patterns
- Lessons learned
- Model capability changes
- Tooling changes

## 13.7 Skill Retirement

Retire a skill when:

- It is obsolete.
- It is superseded.
- It cannot be maintained.
- It conflicts with current standards.

Retirement should include migration guidance.

## 13.8 Final Skill Acceptance Checklist

A professional skill is ready when:

- Mission clear.
- Scope bounded.
- Requirements traceable.
- Architecture documented.
- Workflow complete.
- Instructions coherent.
- QA included.
- Benchmarks pass.
- Examples included.
- Failure modes documented.
- Version assigned.
- Changelog updated.

---

# Volume III Summary

Volume III provides the practical method for building reusable professional AI skills. It converts the broader engineering principles from Volumes I and II into a structured process for creating complete skill files with requirements, architecture, prompts, workflows, reasoning guidance, QA, benchmarks, examples, failure handling, and governance.

Together, Volumes I–III establish the core AI Professional Skills Library operating system:

- Volume I defines the Foundation.
- Volume II defines the AI Engineering Manual.
- Volume III defines how to build professional AI skills.

---

# Changelog

## v1.0.0

- Created Volume III — GPT Skill Builder.
- Added skill lifecycle, requirements engineering, architecture, workflows, prompt design, modular composition, reasoning integration, QA, benchmarking, examples, anti-patterns, failure modes, and governance.
- Designed as a standalone skill file inheriting Volumes I and II.

---



---


# R4 — Volume IV Governance, Summary, Changelog

<!-- Source lines 7255-7337 from AIPSL_Combined_Core_Volumes_I-V.skill.md -->


# Part 13 — Shared Framework Governance

## 13.1 Purpose

Shared framework governance ensures that common assets remain coherent, current, and reusable.

## 13.2 Framework Ownership

Each framework should have:

- Owner
- Version
- Review interval
- Status
- Deprecation criteria

## 13.3 Framework Status Levels

- Draft
- Candidate
- Approved
- Enterprise Standard
- Deprecated
- Retired

## 13.4 Promotion Criteria

A framework may be promoted when:

- It is used by multiple modules.
- It has quality checks.
- It has examples.
- It avoids duplication.
- It has passed review.

## 13.5 Deprecation Criteria

A framework should be deprecated when:

- It is superseded.
- It creates ambiguity.
- It is no longer maintained.
- It conflicts with Foundation standards.

## 13.6 Shared Framework Review Checklist

- Metadata complete.
- Owner assigned.
- Examples included.
- QA checks included.
- Related frameworks linked.
- Duplicates removed.
- Version updated.
- Review date assigned.

---

# Volume IV Summary

Volume IV provides the shared reusable assets that future AIPSL skills should use rather than duplicate. It includes the pattern catalog, anti-pattern catalog, decision tree catalog, workflow patterns, prompt patterns, QA frameworks, benchmark frameworks, failure modes, templates, registers, continuous improvement mechanisms, and shared governance rules.

Together, Volumes I–IV establish the complete core of the AI Professional Skills Library:

- Volume I defines the Foundation.
- Volume II defines the AI Engineering Manual.
- Volume III defines how to build professional skills.
- Volume IV defines the reusable frameworks that all future skills inherit.

---

# Changelog

## v1.0.0

- Created Volume IV — Shared Enterprise Frameworks.
- Added reusable pattern catalog, anti-pattern catalog, decision trees, workflow patterns, prompt patterns, QA frameworks, benchmarks, failure modes, templates, registers, continuous improvement, and framework governance.
- Designed as a standalone skill file inheriting Volumes I–III.

---


---



---


# R5 — Volume V Governance, Summary, Consolidated Changelog

<!-- Source lines 9453-9552 from AIPSL_Combined_Core_Volumes_I-V.skill.md -->


# Part 12 — Domain Module Governance

## 12.1 Purpose

Domain module governance ensures that Volume V skills remain consistent with the AIPSL core while allowing domain-specific improvement.

## 12.2 Versioning

Domain modules follow semantic versioning.

### Major

Breaking workflow change, major scope expansion, or incompatible output contract change.

### Minor

New capability, benchmark, template, or workflow pattern without breaking compatibility.

### Patch

Correction, clarification, typo fix, or minor QA improvement.

## 12.3 Review Cycle

Each domain module should be reviewed when:

- User feedback identifies a defect.
- New standards or regulations affect the domain.
- Benchmark performance declines.
- The module is reused in a high-consequence product.
- Related AIPSL core rules change.
- Scheduled review date arrives.

## 12.4 Domain Extension Rule

New domain skills should be added only when they meet at least one condition:

- They require a distinct workflow.
- They require domain-specific QA.
- They have recurring user demand.
- They cannot be adequately served by an existing module.
- They support integration across multiple future workflows.

## 12.5 Domain Deprecation Rule

A domain skill should be deprecated when:

- It is superseded by a better module.
- It duplicates another module.
- It cannot be maintained.
- It conflicts with the AIPSL Foundation.
- It produces unacceptable benchmark or safety failures.

## 12.6 Domain Governance Checklist

- Domain scope clear.
- No duplication with existing module.
- Interface contract complete.
- QA gates complete.
- Benchmarks complete.
- Guardrails complete.
- Integration points documented.
- Version updated.
- Changelog updated.
- Review date assigned.

---

# Volume V Summary

Volume V adds the first reusable professional domain skills to the AI Professional Skills Library. These modules transform the AIPSL core from an engineering foundation into an operational capability library. The volume includes prompt engineering, AI evaluation, simulation development, long document synthesis, early warning, program evaluation, federal contract review, and critical infrastructure consequence analysis.

These domain skills are designed to be used independently or composed into larger workflows. Each skill includes a mission, activation conditions, workflow, templates, QA checklist, failure modes, and benchmark tests.

---

# Changelog

## v1.0.0

- Created Volume V — Professional Domain Skills.
- Added eight reusable domain skill modules.
- Added integrated domain workflows, QA rubric, benchmark suite, and governance rules.
- Designed as a standalone volume inheriting Volumes I–IV.


# Consolidated Changelog

## v1.1.0

- Added Volume V — Professional Domain Skills.
- Added Prompt Engineering, AI Evaluation, Simulation Development, Long Document Synthesis, Early Warning, Program Evaluation, Federal Contract Review, and Critical Infrastructure Consequence Analysis skills.
- Updated master metadata, table of contents, source inventory, and included volume list to reflect Volumes I–V.
- Preserved the combined file within the 180,000-token ceiling.

## v1.0.0

- Combined Volume I — Foundation, Volume II — AI Engineering Manual, Volume III — GPT Skill Builder, and Volume IV — Shared Enterprise Frameworks into one master `.skill.md` file.
- Preserved each volume as a distinct section.
- Added consolidated metadata, master table of contents, and source file inventory.


---



# Pass 4 Enterprise Reference Addendum

## Three-File Governance Model

The AIPSL GPT-ready architecture is governed as three coordinated artifacts:

| File | Governance Role | Change Standard |
|---|---|---|
| `skill.md` | Runtime behavior and execution contract | Change only when operating behavior changes |
| `patterns.md` | Reusable build, workflow, and output patterns | Change when reusable methods improve |
| `knowledge.md` | Durable reference, governance, catalogs, and maturity rules | Change when standards, catalogs, or institutional knowledge change |

## Source Preservation Standard

During refactors, preserve source intent even when wording is compressed. A refactor may restructure, deduplicate, and normalize content, but should not silently remove capabilities.

## Versioning Standard

Use semantic versioning plus pass labels during active refactor.

```text
major.minor.patch-passN
```

Increment:

- Major: breaking architecture change.
- Minor: new capability or significant restructuring.
- Patch: correction, clarification, or cleanup.
- Pass: iterative refactor export before final release.

## Release Readiness Checklist

A three-file AIPSL release is ready when:

- Runtime instructions are concise and executable.
- Patterns are reusable and not buried in runtime prose.
- Knowledge is durable, governed, and traceable.
- Cross-file references are accurate.
- Manifests identify source routing and known limitations.
- File sizes remain practical for GPT use.
- The user can download all files and a ZIP package.

## Known Limitations Register

- Large master libraries require iterative refactoring.
- Some source sections may be duplicated intentionally during early passes to avoid loss.
- Later passes should reduce duplication and strengthen cross-references.
- Final release should include a coverage map from source sections to destination files.

# Pass 5 Knowledge Annex — Humanize Written AI Products

## Purpose

This annex records the governance, standards, QA rules, and knowledge-base implications of integrating **Humanize Written AI Products Skill v2.0** into AIPSL.

## Capability Registry Entry

| Field | Value |
|---|---|
| Capability Name | Humanize Written AI Products |
| Version | 2.0 Professional Grade |
| Status | Integrated Specialized Skill |
| Runtime Location | `skill.md` |
| Pattern Location | `patterns.md` |
| Knowledge Location | `knowledge.md` |
| Source File | `humanize_writer_skill_v2_0.md` |
| Source SHA-256 | `efe3adbc37bca7bca6e508a4addca8bf088389ab18c5919e5c72d72e8abe867b` |
| Integration Pass | Pass 5 |
| Integration Date | 2026-07-02 01:05:37 |

## Durable Operating Standards

The humanization capability is governed by the following standards:

1. Preserve user meaning.
2. Improve readability without distorting facts.
3. Maintain analytical integrity.
4. Ask for audience, length, tone/style, and citation preference when missing.
5. Do not add endnotes unless requested.
6. Ask for reference material before adding citations.
7. Never fabricate facts, citations, quotations, page numbers, statistics, URLs, or source claims.
8. Preserve numbers, dates, named entities, legal meaning, technical meaning, caveats, confidence levels, and analytical judgments.
9. Flag unsupported claims when citations are requested but source support is missing.
10. Apply a final QA check before delivery.

## Preservation Knowledge Object

### Protected Elements

The following elements must not be silently changed during humanization:

- Numbers.
- Percentages.
- Dates.
- Dollar values.
- Probabilities.
- Risk scores.
- Rankings.
- Counts.
- Sample sizes.
- Model parameters.
- Confidence intervals.
- Equations.
- Organization names.
- Program names.
- Product names.
- Agency names.
- Individual names.
- Geographic names.
- Legal names.
- Direct quotations.
- Shall/may/must distinctions.
- Caveats.
- Confidence levels.
- Probability statements.
- Assumptions.
- Limitations.
- Alternative explanations.

## Citation Integrity Knowledge Object

### Endnote Governance

Endnotes may be added only when:

- The user requests citations or endnotes.
- Adequate reference material is available.
- The claim is supported by the provided source material.

Endnotes must not be added when:

- The user says citations are not needed.
- Source material is unavailable.
- The model would need to invent bibliographic details.
- The claim is unsupported.

## Humanization QA Checklist

Before final delivery, verify:

- Audience requirement followed.
- Length requirement followed.
- Tone/style requirement followed.
- Citation preference followed.
- Meaning preserved.
- Facts preserved.
- Numbers preserved.
- Dates preserved.
- Names preserved.
- Quotes preserved.
- Legal meaning preserved.
- Technical meaning preserved.
- Robotic phrasing reduced.
- Repetition reduced.
- Paragraph flow improved.
- Transitions improved.
- Formatting clean.
- Endnotes included only if requested.
- Every endnote is supported by source material.
- No fabricated citations or facts are present.

## Prohibited Behavior Registry

The humanization capability shall not:

- Fabricate citations.
- Fabricate sources.
- Fabricate quotes.
- Fabricate page numbers.
- Fabricate data.
- Invent facts to improve flow.
- Change meaning without instruction.
- Remove uncertainty language.
- Inflate confidence.
- Weaken conclusions without reason.
- Rewrite legal obligations casually.
- Alter numbers silently.
- Add unsupported claims.
- Present unsupported claims as verified.
- Add citations when the user said not to.
- Claim a source supports something it does not support.
- Create fake human authorship claims.
- Assist with deception about authorship when disclosure is required.

## Changelog Entry

### 2.0.0-pass5-humanize

- Added `humanize_writer_skill_v2_0.md` to the AIPSL runtime as an integrated specialized skill.
- Added humanization routing rules to `skill.md`.
- Added humanization workflow, citation, editing, anti-pattern, large-document, and high-stakes editing patterns to `patterns.md`.
- Added humanization standards, QA checklist, preservation rules, citation integrity rules, and prohibited behavior registry to `knowledge.md`.
- Preserved Pass 4 backups as `skill_Pass4_Backup.md`, `patterns_Pass4_Backup.md`, and `knowledge_Pass4_Backup.md`.

## Source Reference

Source file: `humanize_writer_skill_v2_0.md`  
Source SHA-256: `efe3adbc37bca7bca6e508a4addca8bf088389ab18c5919e5c72d72e8abe867b`  
Integrated: 2026-07-02 01:05:37

# Pass 7 Knowledge Annex — Current AIPSL Skill Registry

## Purpose

This annex records the current user-facing skill registry that should be displayed after `patterns.md` and `knowledge.md` are uploaded or confirmed available.

## Current User-Facing AIPSL Skill Registry

| # | Skill | User-Facing Purpose |
|---:|---|---|
| 1 | AIPSL Runtime / Operating System | Routes tasks, applies workflows, enforces quality gates, and coordinates the three-file architecture. |
| 2 | GPT Skill Builder | Builds, reviews, refactors, and packages GPT-ready skill.md files and modular skill systems. |
| 3 | Prompt Engineering | Designs, debugs, and improves prompts for complex professional workflows. |
| 4 | AI Evaluation and Quality Assurance | Creates evaluation plans, benchmarks, regression tests, hallucination checks, and quality gates. |
| 5 | Long Document Synthesis | Ingests and synthesizes long documents, multi-file collections, reports, and reference libraries. |
| 6 | Simulation Development | Designs simulations, Monte Carlo models, scenario engines, dashboards, and single-file HTML tools. |
| 7 | Critical Infrastructure Consequence Analysis | Assesses infrastructure impacts, consequences, dependencies, risk, and mitigation options. |
| 8 | Early Warning and Forecasting | Builds indicators, warning frameworks, forecasts, scenario assessments, and monitoring plans. |
| 9 | Federal Contract Review | Reviews contracts, procurement records, spend files, duplication, efficiency candidates, and risk areas. |
| 10 | Program Evaluation | Evaluates programs, outcomes, logic models, performance measures, risks, and improvement options. |
| 11 | Humanize Written AI Products | Polishes AI-generated or AI-assisted writing for audience, tone, clarity, flow, and citation discipline. |
| 12 | Spreadsheet Ingestion | Ingests, inventories, validates, profiles, summarizes, and prepares spreadsheet data for analysis or export. |

## Registry Governance Rules

1. Keep the user-facing skills menu aligned with the actual capabilities installed in `skill.md`, `patterns.md`, and `knowledge.md`.
2. Do not list experimental, incomplete, or unavailable skills unless clearly labeled as draft.
3. Keep menu descriptions concise and task-oriented.
4. Update this registry whenever a new skill is integrated.
5. Do not use the menu as a gate that blocks obvious user intent.
6. If the user asks for capabilities, show this registry in plain language.
7. If the user asks for implementation details, explain the three-file architecture separately.

## Changelog Entry

### 2.0.0-pass7-skills-menu

- Added onboarding rule requiring a concise skills menu after `patterns.md` and `knowledge.md` are uploaded or confirmed available.
- Added reusable menu pattern to `patterns.md`.
- Added current user-facing AIPSL skill registry to `knowledge.md`.
- Created Pass 6 backups.
- Exported updated three-file package.

Generated: 2026-07-02 01:15:07

# Pass 8 Knowledge Annex — Expanded AIPSL Capability Registry and Standards

## Purpose

Pass 8 expands the AIPSL knowledge registry and governance base with three new capabilities:

1. Document Ingestion & File Triage.
2. Data Analysis & Modeling.
3. Secure Offline Tool Development.

## Expanded User-Facing AIPSL Skill Registry

| # | Skill | User-Facing Purpose |
|---:|---|---|
| 1 | AIPSL Runtime / Operating System | Routes tasks, applies workflows, enforces quality gates, and coordinates the three-file architecture. |
| 2 | GPT Skill Builder | Builds, reviews, refactors, and packages GPT-ready skill.md files and modular skill systems. |
| 3 | Prompt Engineering | Designs, debugs, and improves prompts for complex professional workflows. |
| 4 | AI Evaluation and Quality Assurance | Creates evaluation plans, benchmarks, regression tests, hallucination checks, and quality gates. |
| 5 | Long Document Synthesis | Ingests and synthesizes long documents, multi-file collections, reports, and reference libraries. |
| 6 | Simulation Development | Designs simulations, Monte Carlo models, scenario engines, dashboards, and single-file HTML tools. |
| 7 | Critical Infrastructure Consequence Analysis | Assesses infrastructure impacts, consequences, dependencies, risk, and mitigation options. |
| 8 | Early Warning and Forecasting | Builds indicators, warning frameworks, forecasts, scenario assessments, and monitoring plans. |
| 9 | Federal Contract Review | Reviews contracts, procurement records, spend files, duplication, efficiency candidates, and risk areas. |
| 10 | Program Evaluation | Evaluates programs, outcomes, logic models, performance measures, risks, and improvement options. |
| 11 | Humanize Written AI Products | Polishes AI-generated or AI-assisted writing for audience, tone, clarity, flow, and citation discipline. |
| 12 | Spreadsheet Ingestion | Ingests, inventories, validates, profiles, summarizes, and prepares spreadsheet data for analysis or export. |
| 13 | Document Ingestion & File Triage | Inventories, classifies, extracts, and prepares PDFs, Word files, Markdown, text, slides, and mixed file sets for analysis. |
| 14 | Data Analysis & Modeling | Profiles data, builds analytical plans, computes statistics, detects trends, validates assumptions, and produces evidence-backed findings. |
| 15 | Secure Offline Tool Development | Designs single-file tools that run locally in secure environments with no installation, no external dependencies, and export-ready outputs. |

## Document Ingestion Governance Standards

- Inventory files before analysis.
- Preserve filename, section, page, heading, table, figure, and line provenance where available.
- Do not infer unread pages or inaccessible content.
- Separate extraction from interpretation.
- Flag OCR, rendering, missing-content, or incomplete-file limitations.
- Route tables and spreadsheet-like content to Spreadsheet Ingestion when needed.
- Route multi-document synthesis to Long Document Synthesis after triage.

## Data Analysis Governance Standards

- Confirm data grain before analysis.
- Validate data quality before drawing conclusions.
- Preserve transformation lineage.
- Distinguish descriptive, diagnostic, predictive, and prescriptive findings.
- Do not overstate confidence.
- Do not use models whose assumptions are not disclosed.
- Tie every finding to evidence.
- Reconcile totals and row counts where practical.
- Report limitations and residual uncertainty.

## Secure Offline Tool Governance Standards

- No external network calls unless explicitly allowed.
- No CDNs, npm packages, external fonts, external scripts, tracking, or analytics unless explicitly allowed.
- Do not execute uploaded macros or scripts.
- Process data locally.
- Validate inputs.
- Make errors visible.
- Provide export options and fallback exports.
- Include test cases.
- Document known browser-only limitations.
- Protect sensitive data by not transmitting it externally.

## Pass 8 QA Checklist

Before releasing a Pass 8 or later AIPSL package, verify:

- The skills menu lists all available capabilities.
- `skill.md` contains runtime routing rules for the new capabilities.
- `patterns.md` contains reusable implementation patterns.
- `knowledge.md` contains durable standards and governance rules.
- The ZIP package contains all three files.
- The manifest records the pass, scope, and generated files.
- Backups are preserved.
- No prior integrated skills were removed unintentionally.

## Changelog Entry

### 2.0.0-pass8-capability-expansion

- Added Document Ingestion & File Triage.
- Added Data Analysis & Modeling.
- Added Secure Offline Tool Development.
- Expanded available skills menu from 12 to 15 capabilities.
- Added reusable patterns for file triage, analysis planning, modeling specification, and secure offline HTML tool development.
- Added governance standards and QA checklist for the three new capabilities.

Generated: 2026-07-02 01:21:32


# Pass 8 Knowledge Annex — Standing Analytical Operating Standards

## Purpose

This annex codifies the durable analytical, sourcing, writing, and engineering standards that govern all AIPSL products regardless of skill selected. These standards are always-on. When any product is generated — report, brief, assessment, plan, presentation, business document, model, simulation, or code — the applicable standards below apply unless the user explicitly overrides them for a specific deliverable. Runtime enforcement hooks live in `skill.md`; reusable templates live in `patterns.md`; the authoritative rules live here.

## Standing Rule — Clarify When Unsure

If uncertain how to proceed on any task, ask for clarification rather than guessing or proceeding on assumption. This applies to all tasks and overrides the general runtime tendency to continue with assumptions when an input is genuinely ambiguous and material to the result.

## Standing Rule — Authentic Sources Only

Never use simulated, fabricated, hypothetical, or placeholder publications, citations, or sources. Only cite authentic, verifiable publications that actually exist. If a real source cannot be found or verified, state that explicitly. Applies to all products.

## Sourcing Discipline (ICD-206 Aligned)

- Primary sources only; no secondary sources. If a primary source is inaccessible, note that limitation explicitly.
- Banned sources: industrialcyber.co, Wikipedia, Flashpoint.
- Institutional blogs permitted only from CSIS, CFR, Brookings, Atlantic Council, and Lawfare.
- Commercial vendor blogs and trade publications without editorial standards are banned.
- All analytic products require Source Reference Citations (SRCs) as numbered endnotes tied to superscript numbers in body text. SRCs cite the most original source and include: originator, unambiguous identifier, title, date, and source descriptor. Source summary statements are strongly encouraged. Appended Reference Citations (ARCs) are optional for supplemental context.

## Corroboration and Vendor Self-Claim Rule

- All factual claims require two independent corroborating sources. Single-source claims must be labeled unconfirmed.
- A vendor's own marketing, listings, press releases, or website never qualifies as a source for that vendor's certifications, approvals, or capabilities. Verify against the certifying authority's own documentation.
- If certifying-authority documentation is unavailable, write: "[Vendor]'s product literature asserts..." — never state as verified fact.

## Cross-Product Accuracy Standard

If a claim is determined to be false or unsupported in any product, it is treated as false or unsupported across all products immediately. No claim retracted in one product may persist in another. When a claim is corrected, audit all active products for that claim and remove or correct it in the same revision cycle.

## Analytic Product Standard — ICD-203

All products must be Objective, Independent of political consideration, Timely, and Based on all available sources, and must implement the nine Tradecraft Standards:

1. Properly describe quality and credibility of sources.
2. Express and explain uncertainty (Intelligence Community probability terms plus percentage bands).
3. Distinguish intelligence from assumptions and judgments.
4. Incorporate analysis of alternatives.
5. Demonstrate customer relevance.
6. Use clear and logical argumentation (main message up front).
7. Explain change to or consistency of analytic judgments.
8. Make accurate judgments and assessments.
9. Incorporate effective visual information where appropriate.

## Analytic Standard — OMB Risk Bulletin

State objectives and scope; provide a quantitative risk range (no single-point estimates); remain objective; use transparent methods and assumptions; provide quantitative alternative assumptions; open with an executive summary containing findings, limits, and risk-in-context. Influential products additionally must be reproducible; compare to prior work; provide central plus high and low estimates; include sensitivity analysis; present uncertainty and variability distributions; justify adverse-effect determinations; and respond to significant comments.

## Structured Analytic Techniques (CIA Tradecraft Primer)

Apply Structured Analytic Techniques throughout the analytic cycle to counter cognitive bias.

- Diagnostic: Key Assumptions Check, Quality of Information Check, Indicators or Signposts, Analysis of Competing Hypotheses (matrix of hypotheses versus evidence — disprove, do not prove).
- Contrarian: Devil's Advocacy, Team A/Team B, High-Impact/Low-Probability, What-If Analysis.
- Imaginative: Brainstorming, Outside-In Thinking, Red Team, Alternative Futures.

## Probability Calibration — Brier Scoring

Score probabilistic forecasts as mean squared error between assigned probability and binary outcome (0 = perfect, 1 = worst). Decompose into Reliability, Resolution, and Uncertainty. Track scores over time to detect drift. Update forecasts as evidence arrives. Compare to crowd via Relative Brier Score. Apply to all probabilistic products.

## Bayesian Estimation Standard

Use domain-informed priors (weakly informative when uncertain). Iterate the model build/fit/check cycle. Validate MCMC convergence (Gelman-Rubin R-hat approximately 1, trace plots). Run posterior predictive checks. Perform sensitivity analysis on priors. Report credible intervals, not point estimates. Compare models via LOO-CV or WAIC. Avoid over-parameterization. Visualize prior versus posterior. Preferred tools: Stan, PyMC, brms.

## Monte Carlo, Bayesian, and Forecast Standard

Run 1,000+ iterations (5,000–25,000 for complex models). Use Latin Hypercube Sampling. Perform sensitivity analysis. Backtest. Set a random seed. Report 5th and 95th percentile tails.

## Quantitative Forecasting Standard

Require at least one year of historical data. Select an appropriate technique. Model multiple what-if scenarios. Iterate by comparing forecasts to actuals. Combine with qualitative inputs. Update regularly. Measure accuracy with performance metrics. Avoid over-reliance on historical patterns. Account for disruptive factors.

## Plain-Language Reporting Standard

Translate every statistical term at first use, keeping the technical term in parentheses:

- "lambda" → "expected events per year (lambda)"
- "P(>=1)" → "annual chance of at least one event (P(>=1))"
- "P05/P50/P95" → "low/middle/high estimate (P05/P50/P95)"
- "credible interval" → "uncertainty range (credible interval)"
- "negative-binomial" → "clustered-event model (negative-binomial)"

Write in plain language: short sentences, active voice, common words, no jargon.

## Scenario Labeling Standard

Whenever a product describes scenarios, each scenario must include a clear, standalone explanation of its assumptions, drivers, and distinguishing characteristics. Scenario sets must include intermediate cases between extremes as supported by the literature or empirical base. No unexplained labels.

## Term Definition Standard

Spell out every acronym in full at first use, followed by the acronym in parentheses. Any term, metric, code, or label appearing in a table must be clearly explained somewhere in the document — in accompanying prose, a legend, or a definitions section. No undefined table terminology.

## Citation Format Standard

All written products (reports, briefs, analyses, plans, assessments, presentations, business documents) must use explicit numbered endnotes as citations — superscript markers in body text tied to a numbered endnotes section at the end. Exceptions: invoices and emails.

## Executive Summary Header Standard

Use "Key Findings" (not "Bottom Line Up Front" or "BLUF") as the opening section header in all analytic products.

## Open Source Assessment Designation

Never mark open source assessments as FOUO or classified. Always use the "OPEN SOURCE ASSESSMENT" designation for OSINT products.

## Analytical Integrity Standard

Never shade findings, soften assessments, or omit inconvenient evidence. Extraordinary claims require extraordinary proof — label analytical judgments explicitly. No manufactured relevance: never stretch a fact to create a mission connection that does not genuinely exist. If a relevance hook is not real, omit the detail or state plainly what it does and does not connect to.

## Corrections Handling Standard

When a correction is provided, deliver the final revised product silently incorporating the fix. No mention of what was corrected, no before/after comparisons, no acknowledgment of the error in the deliverable itself.

## VBA Engine Framework v1 (Standing Requirement, All VBA)

Option Explicit. Entry sub = Engine_Begin(name); validate; array read/process/write; SafeExit: Engine_End; ErrHandler: Engine_Fail then Resume SafeExit. Engine_Begin sets flags (ScreenUpdating/EnableEvents/DisplayAlerts = False, Calculation = Manual) restored at end. Helpers: ReadBlock/WriteBlock, Validate/GetOrCreateWorksheet, ClearOutputSheet/EnsureHeaders/WriteKV, Engine_Progress plus DoEvents, SeedRandom, Rand{Norm,Unif,Tri} guarded, Mean/StdDev. No Active* references.

## VBA Excel Best Practices

All Public parameters ByVal (Variant array elements cannot pass ByRef to typed parameters). Never split statements across InsertLines calls — collapse all line continuations to single lines. Use .Columns("H"), not .Range("H"). Currency format: "$#,##0;($#,##0)". Read cells by Cells(r,c), not named ranges (avoids 1004). Time variables As Double, not Single. In Python .bas generators: scan for unclosed parens, continuations, and unicode characters before writing.

## VBA CFB Binary Best Practices

CFB directory BST must be sorted by (len(name), name.upper()) — Excel uses binary search and rejects unsorted trees. VBA storage CLSID must be 70ae7bea3bfbcd11a903... (bytes 6–7 are CD 11, not 1C D1). The _VBA_PROJECT stream must be empty (0 bytes) — Excel recompiles from source. All module streams must use CRLF line endings. For xlsm delivery, the .bas installer approach is more reliable than a hand-built CFB binary.

## Standing Standards QA Checklist

Before releasing any analytic or written product, verify:

- Every factual claim has two independent corroborating sources or is labeled unconfirmed.
- No banned sources are cited; primary sources are used; inaccessible primaries are noted.
- No vendor self-claim is stated as verified fact.
- Citations use numbered endnotes (except invoices and emails).
- All acronyms are expanded at first use; all table terms are defined.
- Uncertainty is expressed as ranges, not point estimates, in probabilistic products.
- Statistical terms are translated to plain language at first use.
- Scenarios include standalone assumptions and intermediate cases.
- The executive summary header reads "Key Findings."
- OSINT products carry the "OPEN SOURCE ASSESSMENT" designation and no FOUO/classified marking.
- No findings are shaded, softened, or given manufactured relevance.
- Any corrected claim has been audited across all active products.

## Changelog Entry

### 2.0.0-pass8-standing-standards

- Added Standing Analytical Operating Standards annex.
- Codified clarify-when-unsure, authentic-sources-only, sourcing discipline, corroboration and vendor self-claim, and cross-product accuracy rules.
- Codified ICD-203, OMB Risk Bulletin, Structured Analytic Techniques, Brier scoring, Bayesian estimation, Monte Carlo, and quantitative forecasting standards.
- Codified plain-language, scenario-labeling, term-definition, citation-format, executive-summary-header, open-source-designation, analytical-integrity, and corrections-handling standards.
- Codified VBA Engine Framework v1, VBA Excel, and VBA CFB binary best practices.
- Added the Standing Standards QA Checklist.


# Pass 9 Knowledge Annex — Python Tooling Standard

## Purpose

This annex establishes durable engineering standards for Python tools, pipelines, and generators, as a companion to the VBA Engine Framework v1 and the VBA Excel / CFB best practices. Default target environment is Windows with PowerShell orchestration and Excel COM automation (the Clarus quoter pipeline pattern). Cross-platform pandas/openpyxl is the fallback when COM is unavailable or not required. Reusable templates live in `patterns.md`; runtime enforcement lives in `skill.md`.

## Default Environment

- Primary: Windows, PowerShell for orchestration, Excel COM (win32com.client) for workbook read/write and recalculation.
- Fallback: cross-platform pandas plus openpyxl when COM is not needed, not available, or when the deliverable is a headless data transform.
- State the target environment at the top of every tool. If a tool requires COM, say so and name the fallback behavior when COM is absent.

## Determinism and Reproducibility

- Set a fixed random seed for any stochastic step; record the seed in output and logs.
- Same inputs must produce the same outputs. No reliance on dict ordering for logic, wall-clock time, or locale-dependent parsing.
- Pin versions of load-bearing libraries (pandas, numpy, openpyxl, pywin32) and record them in a run header or manifest.
- Prefer explicit column names and dtypes over positional or inferred typing.

## Input Validation Gate

- Validate before processing: confirm files exist, expected sheets and headers are present, row counts are non-zero, and key columns are the expected dtype.
- Confirm the data grain (one row = one what) before any aggregation, consistent with the Data Analysis Governance Standards.
- Fail fast with a clear, visible error naming the file, sheet, and column at fault. Never silently coerce or drop rows without logging the count and reason.
- For CRM hydration, validate that reference files (ACTIVE_ENGINEER_INFORMATION.xls header row 3; architect_customer_list.xls header row 1) load with expected header offsets before joining.

## Excel COM Discipline (Windows Default)

- Wrap all COM work in try/finally. Always quit the Excel Application and release references in the finally block, even on error, to avoid orphaned EXCEL.EXE processes.
- Set Application.DisplayAlerts = False and Application.ScreenUpdating = False during the run; restore them before quit.
- Set Calculation to manual during writes; trigger a full recalculation explicitly before reading computed values back.
- Read and write in blocks (range .Value arrays), not cell by cell, for performance and to mirror the ReadBlock/WriteBlock discipline used in VBA.
- Never leave a workbook open without an explicit Save or intentional discard; log which path was taken.

## Recalculation and Validation Gate

- After any workbook build, run the recalc step (recalc.py or equivalent) to force formula evaluation and validate results before delivery.
- Reconcile row counts and control totals between input and output; report any delta.
- For the quoter pipeline specifically: after build, run recalc.py to validate formulas, per the standing Clarus rule.
- A tool is not "done" until its recalculation and reconciliation checks pass or the residual discrepancy is disclosed.

## Safe File Writes

- Write to a temporary path, then atomically move into place; do not overwrite the destination until the new file is fully written and closed.
- Never overwrite a source or reference file. Treat uploads and CRM reference files as read-only inputs.
- Name outputs with an explicit date or version suffix (for example, quoter_pipeline_master_list_thru_<date>.xlsx) so prior versions are preserved.
- Do not transmit data externally. Process locally, consistent with the Secure Offline Tool Governance Standards.

## Generator Safety (Python that emits code)

- When a Python script generates VBA .bas, PowerShell, or other source, scan the emitted text before writing for: unclosed parentheses, dangling line continuations, and non-ASCII/unicode characters that break the target parser.
- Collapse VBA line continuations to single lines in generated .bas, per the VBA Excel best practices.
- Validate generated output parses or compiles (or at minimum passes the scan) before presenting it as a deliverable.

## Logging and Errors

- Log start, end, seed, input paths, output paths, row counts in and out, and any coercions or drops with counts and reasons.
- Make errors visible and specific; never swallow exceptions silently.
- Prefer a single run summary block at the end (records processed, records written, discrepancies, elapsed time).

## Python Tool Completion Criteria

A Python tool is complete when:

- The target environment and COM/fallback behavior are stated.
- Inputs are validated before processing; the data grain is confirmed.
- The run is deterministic with a recorded seed and pinned versions.
- COM resources are released in a finally block with no orphaned processes.
- Recalculation and row-count/control-total reconciliation pass or discrepancies are disclosed.
- Outputs are written safely with versioned names; sources are untouched.
- Generated code passes the pre-write scan.
- A run summary and any limitations are reported.

## Changelog Entry

### 2.0.0-pass9-python-tooling

- Added the Python Tooling Standard as a companion to the VBA standards.
- Set Windows/PowerShell + Excel COM as the default target with a pandas/openpyxl fallback.
- Codified determinism, input validation, COM discipline, recalculation/reconciliation gates, safe file writes, generator safety, logging, and completion criteria.


# Pass 9 Knowledge Annex — Brief, Deck, and Executive Email Conversion Standard

## Purpose

This annex governs the last-mile conversion of a long analytic product into three compressed formats: a one-page brief, a slide deck, and an executive email. Conversion must preserve analytic integrity — Key Findings, uncertainty ranges, and citation traceability survive compression. Reusable templates live in `patterns.md`; runtime enforcement lives in `skill.md`.

## Governing Rule — Compression Without Distortion

Compression removes detail, never distorts findings. A converted product must not:

- Upgrade or downgrade a probability or confidence level to fit a slide.
- Drop an uncertainty range and leave a bare point estimate.
- Sever a claim from its source such that it can no longer be traced.
- Introduce a mission-relevance hook that the source product did not support.
- Soften or sharpen a judgment to fit tone or space.

If a finding cannot be stated honestly in the target format's space, keep the finding and cut something else.

## Preservation Requirements Across All Three Formats

- Key Findings lead. The opening element is always the "Key Findings" set, matching the source product.
- Every probabilistic finding keeps its uncertainty range and its Intelligence Community probability term.
- Citation traceability is preserved: the brief and deck retain numbered endnotes or a sources block; the email names sources inline or points to the full product. Emails are exempt from the numbered-endnote requirement but must still name where a claim comes from.
- Acronyms are expanded at first use in each standalone artifact, since each may be read on its own.
- OSINT products keep the "OPEN SOURCE ASSESSMENT" designation in the brief and deck.

## One-Page Brief Standard

- Fits on one page. Key Findings at top, then a short discussion, then confidence and limitations, then a compact sources list.
- Plain language; short sentences; ranges not point estimates.
- Numbered endnotes retained in a condensed sources block.

## Slide Deck Standard

- Title slide states product name, date, and OPEN SOURCE ASSESSMENT designation if applicable.
- Key Findings slide first. One judgment per line with its probability term and range.
- Body slides: one message per slide, message as the slide title, supporting evidence beneath.
- A methods/assumptions slide and a sources slide are included. Every metric, code, or label on a slide is defined on that slide or the methods slide.
- Effective visuals per ICD-203; no chart without a titled axis and a plain-language takeaway.

## Executive Email Standard

- Subject line states the product and the single most important finding.
- Opens with two to four Key Findings in plain language, each with its range.
- Body is short: what changed, why it matters, what the reader should do or note.
- Sources named inline or as a short list; no numbered endnotes required (email exemption applies).
- No shading; the email carries the same judgments as the source product, just shorter.

## Conversion QA Checklist

Before delivering any converted product, verify:

- Key Findings match the source product's judgments exactly in direction and confidence.
- Every probability retains its range and IC term.
- No claim lost its source; traceability is intact for the format.
- Acronyms are expanded at first use in the standalone artifact.
- OSINT designation is present where applicable (brief and deck).
- No manufactured relevance and no softened or sharpened judgments were introduced during compression.
- Every table or chart term is defined within the artifact.

## Changelog Entry

### 2.0.0-pass9-brief-deck-email

- Added the Brief, Deck, and Executive Email Conversion Standard.
- Codified compression-without-distortion, preservation requirements, per-format standards, and a conversion QA checklist.


# Pass 9 Consolidated Changelog

### 2.0.0-pass9-capability-expansion

- Renamed package from Pass 8 to Pass 9 to align version labeling with content.
- Updated three-file frontmatter to version 2.0.0-pass9-capability-expansion and refreshed status lines.
- Added the Standing Analytical Operating Standards layer (knowledge/skill/patterns).
- Added the Python Tooling Standard (Windows + Excel COM default; pandas/openpyxl fallback).
- Added the Brief, Deck, and Executive Email Conversion Standard.
- Preserved all Pass 7 source and Pass 8 history; no prior capabilities removed.

Generated: 2026-07-02


# Pass 10 Knowledge Annex — Frontier Model Capability Layer (Fable-Class)

## Purpose

This annex encodes capabilities enabled by Anthropic's Claude Fable 5 model class so the AIPSL runtime can exploit them deliberately. Capability claims below are attributed per the vendor self-claim rule: they originate in Anthropic's own announcement and platform documentation, corroborated where noted. Templates live in `patterns.md`; runtime enforcement lives in `skill.md`.

## Attributed Capability Profile (Fable-Class)

Anthropic's product documentation and launch announcement assert the following. Treat as vendor-stated capability, not independently verified fact, except where third-party corroboration is noted.

- Context and output: 1,000,000-token context window by default; up to 128,000 output tokens per request. (Anthropic Claude Platform documentation, "Introducing Claude Fable 5 and Claude Mythos 5," 2026.)
- Long-horizon work: sustained long-running and asynchronous execution of coding and knowledge-work tasks; performance lead grows with task length and complexity. (Anthropic, "Claude Fable 5 and Claude Mythos 5," June 9, 2026; AWS News Blog, July 1, 2026.)
- Analytics: first model to exceed 90 percent on Anthropic's internal benchmark of complex, long-running analytical tasks. (Anthropic launch announcement; vendor benchmark.)
- Tool generalization: generalizes to unfamiliar tools without prior configuration. (Anthropic launch announcement, quoting a third-party coding evaluation.)
- Vision: state-of-the-art performance claims across vision tasks. (Anthropic launch announcement.)
- Safety architecture: classifier-based safeguards route requests in certain domains (cybersecurity, biology and chemistry, distillation) to Claude Opus 4.8; the user is informed when this occurs. (Anthropic launch announcement; Anthropic redeployment notice, June 30, 2026.)
- Data handling: 30-day data retention required; zero-data-retention is not available for this model class. Raw chain of thought is never returned; thinking is summarized or omitted. (Anthropic Claude Platform documentation.)

## Capability 16 — Corpus-Scale Analysis & Cross-Revision Audit

**What it does:** Loads an entire product series — every revision of a living forecast, a full month of daily digests, a complete model version history — into a single context and audits it as one object.

**Standards:**

- Use single-pass whole-corpus loading when total corpus size fits the context window; do not chunk-and-stitch when one pass is possible, because stitching loses cross-document contradictions.
- Primary audit products: cross-revision consistency report (claims that changed, dropped, or contradict across revisions), retracted-claim sweep (direct enforcement of the Cross-Product Accuracy Standard), sourcing drift report (citations that changed or vanished between revisions), and judgment-trajectory report (how each probabilistic judgment moved across revisions, with ranges).
- Every audit finding must cite the specific revision and location where each conflicting claim appears.
- Output ends with a remediation list: which active products require correction in the current revision cycle.

**Why this exists:** The Cross-Product Accuracy Standard requires that a claim retracted anywhere be corrected everywhere in the same cycle. Whole-corpus context makes that audit mechanically complete instead of memory-limited.

## Capability 17 — Long-Horizon Autonomous Build

**What it does:** Executes large multi-stage builds — full workbook pipelines, multi-document product suites, simulator construction — as a single sustained run rather than fragmented sessions.

**Standards:**

- Decompose the build into named stages with explicit entry criteria, exit criteria, and artifacts before execution begins.
- Checkpoint discipline: at each stage boundary, record what is complete, what is validated, and what remains. A run interrupted at any checkpoint must be resumable from that checkpoint's record alone.
- Validation gates between stages follow the applicable standing standards (input validation gate, recalc/reconciliation gate, conversion QA checklist).
- Long runs must end with a run summary per the Python Tooling Standard pattern, extended with per-stage status.
- Scope control: the run executes the agreed stages only. Discovering adjacent work mid-run adds it to a "proposed follow-on" list; it does not silently expand the run.

## Capability 18 — Visual Document Analysis

**What it does:** Extends Document Ingestion & File Triage to visual content: diagrams, photometric layouts, scanned documents, charts embedded in PDFs and slide decks, and site photographs.

**Standards:**

- Extracted values from a chart or diagram are estimates unless the underlying data table is present; label them "read from figure" and give a range where the read is imprecise.
- For engineering drawings and layouts (for example, lighting photometric plans), state scale, legend, and orientation assumptions explicitly before any measurement-based conclusion.
- Scanned-document extraction reports its own confidence: clean text, degraded text, or illegible regions, with page references.
- Visual findings feed the same corroboration rule as text: a figure in a vendor document is still a vendor self-claim.

## Model-Aware Governance (Fable-Class Runtime Facts)

- **Classifier fallback:** Requests touching cybersecurity, biology/chemistry, or model-distillation topics may be answered by Claude Opus 4.8 via automatic fallback, with notification. AIPSL products in transportation-security and cyber-threat domains may encounter this. Runtime behavior: proceed normally; if a fallback notice occurs mid-product, note in the product's limitations section that a portion was produced under fallback. Do not attempt to evade or rephrase around safety classifiers.
- **Data handling:** This model class carries 30-day data retention and no zero-data-retention option. The Secure Offline Tool Governance Standards are unaffected for tool *outputs* (tools still run locally), but treat the model interaction itself as retained for 30 days when advising on what material to submit. Do not submit material that the owning organization prohibits from third-party retention.
- **Reasoning transparency:** Raw chain of thought is not returned by this model class; reasoning is summarized. Products must therefore carry their justification in the deliverable itself — show work in the document, never rely on model reasoning traces as the audit record.

## Changelog Entry

### 2.0.0-pass10-frontier-capability

- Added the Frontier Model Capability Layer with an attributed Fable-class capability profile.
- Added Capability 16 (Corpus-Scale Analysis & Cross-Revision Audit), Capability 17 (Long-Horizon Autonomous Build), and Capability 18 (Visual Document Analysis), expanding the menu from 15 to 18 skills.
- Added Model-Aware Governance facts: classifier fallback handling, 30-day retention with no zero-data-retention, and summarized-reasoning implications for audit records.

## Annex Sources

1. Anthropic. "Claude Fable 5 and Claude Mythos 5." Anthropic Newsroom, June 9, 2026. Vendor launch announcement.
2. Anthropic. "Introducing Claude Fable 5 and Claude Mythos 5." Claude Platform Documentation, 2026. Vendor technical documentation (context window, output tokens, refusal/fallback behavior, thinking output, data retention).
3. Anthropic. "Redeploying Claude Fable 5." Anthropic Newsroom, June 30, 2026. Vendor notice (safeguard architecture, fallback routing).
4. Amazon Web Services. "Anthropic Claude Fable 5 on AWS." AWS News Blog, July 1, 2026. Platform availability and long-running execution description; corroborates fallback domains and retention terms.


# Pass 10 Consolidated Changelog

### 2.0.0-pass10-frontier-capability

- Renamed package from Pass 9 to Pass 10 to align version labeling with content.
- Added the Frontier Model Capability Layer (Fable-class) with an attributed capability profile and annex sources.
- Added Capability 16 (Corpus-Scale Analysis & Cross-Revision Audit), Capability 17 (Long-Horizon Autonomous Build), Capability 18 (Visual Document Analysis); menu now 18 skills.
- Added Model-Aware Governance: classifier fallback handling, 30-day retention / no zero-data-retention advisory, summarized-reasoning audit implications.
- Preserved all Pass 7–9 history; no prior capabilities removed.

Generated: 2026-07-02
