---
name: AIPSL_Patterns
title: AI Professional Skills Library — Engineering Pattern Library
version: 2.0.0-pass10-frontier-capability
status: GPT-ready Pass 10 build with standing standards, Python tooling, product conversion, and frontier model capability layers
source: AIPSL_Combined_Core_Volumes_I-V.skill.md
generated: 2026-06-28
architecture: three-file AIPSL runtime
companion_files:
  - skill.md
  - patterns.md
  - knowledge.md
---

# AI Professional Skills Library — Engineering Pattern Library

## Purpose
Reusable engineering patterns, workflow templates, prompt structures, domain skill patterns, benchmarks, anti-patterns, and failure modes.

## Operating Note
This file is part of the three-file GPT-ready AIPSL architecture. It preserves source material while reorganizing it by execution function.


# Pattern Library Contract

Use this file when the task requires reusable structures: prompt patterns, workflows, templates, benchmarks, anti-patterns, failure modes, domain build logic, or artifact generation designs.

## Pattern Selection Rules

1. Prefer an existing pattern before creating a new one.
2. Adapt patterns explicitly to the user objective and constraints.
3. Keep analytical logic separate from presentation logic.
4. Preserve interfaces: inputs, outputs, assumptions, quality gates, failure modes.
5. Escalate reusable improvements into the pattern library.

## Canonical Pattern Contract

```text
Pattern Name:
Purpose:
Best Used When:
Inputs:
Outputs:
Workflow:
Quality Gates:
Failure Modes:
Adaptation Notes:
```


# Refactor Source Map

- R1: Source lines 2154-2489 — Volume I Templates, Design Patterns, Components
- R2: Source lines 5659-5912 — Volume III Benchmarks, Examples, Anti-Patterns, Failure Modes
- R3: Source lines 6025-7254 — Volume IV Shared Enterprise Frameworks
- R4: Source lines 7564-9452 — Volume V Professional Domain Skill Patterns

---


# R1 — Volume I Templates, Design Patterns, Components

<!-- Source lines 2154-2489 from AIPSL_Combined_Core_Volumes_I-V.skill.md -->


# Part 8 — Enterprise Templates, Design Patterns & Reusable Components

## 8.1 Purpose

This chapter establishes the reusable assets that underpin the AI Professional Skills Library. By standardizing templates, patterns, interface contracts, and component catalogs, it reduces duplication, improves consistency, and accelerates the development of new skills.

The objective is to ensure that future modules are assembled from well-defined, validated components instead of reimplementing common functionality.

## 8.2 Reuse Philosophy

The library follows a simple hierarchy:

1. Reuse an existing component.
2. Extend an existing component.
3. Create a new component only when necessary.

New capabilities should be promoted to shared components when they demonstrate value across multiple modules.

## 8.3 Standard Module Template

Every reusable module should conform to a common structure.

### Module Metadata

- Name
- Version
- Purpose
- Scope
- Owner
- Dependencies
- Status
- Last Updated

### Functional Definition

- Inputs
- Outputs
- Preconditions
- Postconditions
- Configuration
- Failure Behavior

### Quality Information

- Benchmarks
- Regression Tests
- Quality Gates
- Known Limitations
- Changelog

This metadata enables discovery, maintenance, and interoperability.

## 8.4 Standard Workflow Template

Every workflow should include:

### Objective

The business or analytical purpose.

### Trigger

The event that initiates execution.

### Inputs

Required data and assumptions.

### Workflow States

Ordered execution stages.

### Decision Points

Explicit branching conditions.

### Quality Gates

Validation checkpoints.

### Deliverables

Expected outputs.

### Completion Criteria

Conditions for successful termination.

## 8.5 Standard Analytical Product Template

Every analytical product should contain:

1. Executive Summary
2. Purpose
3. Scope
4. Background
5. Evidence
6. Analysis
7. Alternative Explanations
8. Confidence Assessment
9. Recommendations
10. Limitations
11. References
12. Version History

This structure promotes consistency across reports and assessments.

## 8.6 Prompt Pattern Catalog

Reusable prompt patterns should be cataloged by purpose rather than copied into individual skills.

Examples include:

### Intake Pattern

Clarifies objectives, constraints, and deliverables.

### Evidence Review Pattern

Evaluates information quality and provenance.

### Analytical Pattern

Guides structured reasoning.

### Forecast Pattern

Supports scenario development and uncertainty analysis.

### Report Pattern

Produces standardized outputs.

### Self-Review Pattern

Performs quality assurance before delivery.

Each pattern should define:

- Purpose
- Required inputs
- Expected outputs
- Failure conditions
- Typical use cases

## 8.7 Workflow Pattern Catalog

Reusable workflow archetypes include:

- Sequential
- Branching
- Parallel
- Iterative
- Hierarchical
- Event-driven

Each workflow pattern should include selection guidance and example implementations.

## 8.8 Architectural Pattern Catalog

Common architectural patterns include:

- Layered Architecture
- Pipeline Architecture
- Hub-and-Spoke
- Service Composition
- Plug-in Architecture
- Shared Library
- Event Bus
- Orchestrator/Worker

Each pattern should document:

- Appropriate use cases
- Advantages
- Limitations
- Dependencies
- Example implementations

## 8.9 Decision Tree Template

Decision trees should follow a consistent structure.

```text
Question
├── Condition A
│     ├── Action 1
│     └── Action 2
└── Condition B
      ├── Action 3
      └── Action 4
```

Every decision tree should define:

- Decision objective
- Decision criteria
- Branch conditions
- Expected outcomes
- Escalation points

## 8.10 Interface Contract Template

Reusable components should publish interface contracts describing:

- Purpose
- Inputs
- Outputs
- Data types
- Constraints
- Error conditions
- Configuration options
- Compatibility notes

Stable interfaces reduce integration risk.

## 8.11 Benchmark Template

Every benchmark should include:

- Identifier
- Objective
- Dataset or scenario
- Expected behavior
- Acceptance threshold
- Evaluation procedure
- Success criteria
- Known limitations
- Version

## 8.12 Quality Checklist Template

Standard QA checklists should address:

- Requirements completeness
- Workflow correctness
- Interface compliance
- Documentation completeness
- Benchmark coverage
- Regression status
- Version consistency
- Known limitations

Checklists should be reusable across modules.

## 8.13 Failure Mode Template

Every reusable component should document:

- Failure description
- Detection method
- Impact
- Likely causes
- Recovery actions
- Preventive measures

Maintaining a consistent format simplifies troubleshooting.

## 8.14 Reusable Component Catalog

Shared components should be organized into categories such as:

### Evidence Components

- Source Evaluation
- Confidence Assessment
- Provenance Tracking

### Workflow Components

- Intake
- Validation
- Orchestration
- Reporting

### Knowledge Components

- Classification
- Indexing
- Refresh
- Retirement

### Quality Components

- Benchmark Execution
- Regression Comparison
- Defect Tracking

Future skills should reference these catalogs instead of redefining functionality.

## 8.15 Component Lifecycle

Every reusable component progresses through:

1. Proposal
2. Prototype
3. Validation
4. Shared Adoption
5. Enterprise Standard
6. Maintenance
7. Retirement

Promotion should be based on demonstrated reuse and quality.

## 8.16 Pattern Governance

Pattern libraries should be curated to avoid redundancy.

Each pattern should have:

- A unique identifier
- Clear ownership
- Version history
- Compatibility notes
- Usage examples
- Review schedule

Deprecated patterns should remain archived for historical reference.

## 8.17 Component Review Checklist

Before accepting a reusable component into the shared library, verify:

- Purpose is clearly defined.
- Interface contract is complete.
- Metadata is populated.
- Quality gates are documented.
- Benchmarks exist.
- Failure modes are documented.
- Reuse potential has been assessed.
- Dependencies are identified.
- Version history is initialized.
- Maintenance owner is assigned.

---



---


# R2 — Volume III Benchmarks, Examples, Anti-Patterns, Failure Modes

<!-- Source lines 5659-5912 from AIPSL_Combined_Core_Volumes_I-V.skill.md -->


# Part 10 — Benchmarking & Regression Testing

## 10.1 Purpose

Benchmarking measures skill performance. Regression testing ensures updates do not degrade performance.

## 10.2 Benchmark Categories

- Functional correctness
- Output completeness
- Analytical quality
- Citation preservation
- Robustness
- Consistency
- Maintainability
- User usefulness

## 10.3 Benchmark Template

```yaml
benchmark_id:
skill:
objective:
input:
expected_output:
evaluation_criteria:
passing_threshold:
known_limitations:
version:
```

## 10.4 Benchmark Suite Example

### Skill

Long Document Synthesis

### Benchmarks

- Small document summary
- Large report synthesis
- Conflicting evidence detection
- Citation preservation
- Executive summary generation

## 10.5 Regression Workflow

```text
Run old benchmark
    ↓
Run updated skill
    ↓
Compare outputs
    ↓
Classify differences
    ↓
Accept or fix
    ↓
Document result
```

## 10.6 Regression Difference Categories

- Expected improvement
- Acceptable variation
- Minor regression
- Major regression
- Critical failure

## 10.7 Release Gate

A skill may be released only when:

- Required benchmarks pass.
- No critical regressions remain.
- Major regressions are resolved or documented.
- Changelog updated.
- Known limitations documented.

---

# Part 11 — Examples, Templates & Reference Implementations

## 11.1 Purpose

Examples make skills easier to understand, test, and reuse.

## 11.2 Example Types

- Minimal example
- Standard example
- Complex example
- Edge case example
- Failure example
- Benchmark example

## 11.3 Example Template

```yaml
example_id:
title:
scenario:
input:
expected_process:
expected_output:
notes:
```

## 11.4 Golden Example

A golden example is a reference case that represents ideal behavior.

Golden examples should be:

- Realistic
- Complete
- Repeatable
- Aligned with requirements
- Suitable for regression testing

## 11.5 Reference Implementation Template

```markdown
# Reference Implementation

Scenario:
Inputs:
Workflow:
Expected output:
Quality checks:
Failure handling:
```

## 11.6 Template Library

Every major skill should include templates for:

- Intake
- Requirements
- Workflow
- Evidence
- Analysis
- QA
- Benchmark
- Output
- Changelog

## 11.7 Example QA Checklist

- Example matches skill scope.
- Input is realistic.
- Expected output is clear.
- Quality criteria included.
- Edge cases represented.
- Example can support regression testing.

---

# Part 12 — Anti-Patterns, Failure Modes & Recovery

## 12.1 Purpose

Anti-patterns identify common design failures. Failure modes define how skills can break. Recovery guidance explains how to fix them.

## 12.2 Common Anti-Patterns

### Prompt Bloat

Too many repeated instructions reduce clarity.

### Undefined Scope

Skill attempts to do too much.

### Hidden Assumptions

The skill relies on unstated conditions.

### Weak QA

No benchmark or validation process.

### Template Duplication

Same template appears in several places.

### Monolithic Skill

Everything is embedded in one large instruction block.

### No Failure Behavior

Skill does not specify what to do when inputs are missing or invalid.

## 12.3 Failure Mode Template

```yaml
failure_mode:
symptoms:
likely_causes:
impact:
detection:
recovery:
prevention:
```

## 12.4 Example Failure Mode

```yaml
failure_mode: Unsupported conclusion
symptoms: Recommendation appears without evidence
likely_causes:
  - missing evidence requirement
  - weak QA
  - vague output format
impact: reduced analytical integrity
detection: evidence-to-finding traceability review
recovery: add evidence table and QA gate
prevention: enforce evidence standards in workflow
```

## 12.5 Recovery Workflow

```text
Detect issue
    ↓
Classify severity
    ↓
Identify root cause
    ↓
Revise requirements or prompt
    ↓
Run benchmark
    ↓
Run regression test
    ↓
Release patch
```

## 12.6 Anti-Pattern Checklist

Before release, verify:

- Scope is bounded.
- No duplicated sections.
- Instructions do not conflict.
- Failure behavior exists.
- QA exists.
- Benchmarks exist.
- Examples are relevant.
- Outputs are defined.

---



---


# R3 — Volume IV Shared Enterprise Frameworks

<!-- Source lines 6025-7254 from AIPSL_Combined_Core_Volumes_I-V.skill.md -->


# Volume IV — Shared Enterprise Frameworks

<!-- Source: AIPSL_Volume_IV_Shared_Enterprise_Frameworks.skill.md -->

# AI Professional Skills Library (AIPSL)
# Volume IV — Shared Enterprise Frameworks

## Version

**Version:** 1.0.0  
**Status:** Draft  
**Inherits:** Volume I — Foundation; Volume II — AI Engineering Manual; Volume III — GPT Skill Builder  
**Purpose:** Shared reusable framework library for all future AIPSL skills and domain modules  
**Token Budget:** Designed to remain far below the 180,000-token ceiling  
**Generated:** 2026-06-28  

---

# Table of Contents

1. Enterprise Framework Overview  
2. Pattern Catalog  
3. Anti-Pattern Catalog  
4. Decision Tree Catalog  
5. Workflow Pattern Library  
6. Prompt Pattern Library  
7. QA Framework Library  
8. Benchmark Framework Library  
9. Failure Mode Catalog  
10. Template Library  
11. Risk, Issue & Defect Registers  
12. Continuous Improvement Framework  
13. Shared Framework Governance  

---

# Volume IV Overview

Volume IV contains the reusable assets that future AI Professional Skills Library modules should reference instead of duplicating.

The purpose of this volume is to make future skills:

- Faster to build.
- Easier to maintain.
- More consistent.
- More testable.
- More interoperable.
- Less repetitive.
- Easier to govern.

Future domain modules should inherit from this volume and reference the shared frameworks whenever possible.

---

# Part 1 — Enterprise Framework Overview

## 1.1 Purpose

This volume provides shared frameworks for professional AI skill development and operations.

A shared framework is a reusable method, pattern, template, checklist, benchmark, or decision aid that can be used across multiple skills.

Examples include:

- Input validation pattern
- Evidence evaluation template
- Benchmark suite template
- Defect register
- Prompt QA checklist
- Failure-mode catalog
- Continuous improvement cycle

## 1.2 Reuse Principle

Before creating new guidance, check whether an existing shared framework applies.

Preferred sequence:

```text
Reuse existing framework
    ↓
Extend existing framework
    ↓
Create new framework
    ↓
Promote to shared library if broadly useful
```

## 1.3 Shared Framework Categories

This volume organizes reusable assets into:

- Patterns
- Anti-patterns
- Decision trees
- Workflow patterns
- Prompt patterns
- QA frameworks
- Benchmark frameworks
- Failure modes
- Templates
- Registers
- Continuous improvement tools
- Governance artifacts

## 1.4 Framework Metadata Standard

Every reusable framework should define:

```yaml
framework_id:
name:
category:
purpose:
when_to_use:
inputs:
outputs:
procedure:
quality_checks:
examples:
failure_modes:
related_frameworks:
version:
owner:
```

## 1.5 Framework Acceptance Criteria

A framework is accepted into the shared library when:

- It solves a recurring problem.
- It is reusable across multiple skills.
- Its inputs and outputs are defined.
- It has quality checks.
- It includes at least one example.
- It does not duplicate an existing framework.
- It has a version and owner.

---

# Part 2 — Pattern Catalog

## 2.1 Purpose

Patterns are reusable solutions to recurring design problems.

Each pattern should be:

- Named
- Defined
- Repeatable
- Testable
- Documented with examples

## 2.2 Pattern Template

```yaml
pattern_id:
name:
problem:
context:
solution:
steps:
example:
quality_checks:
anti_patterns:
related_patterns:
```

## 2.3 Core Enterprise Patterns

### P-001 — Input Validation Pattern

**Problem:** AI systems often proceed with incomplete or invalid inputs.

**Solution:** Validate inputs before analysis.

**Steps:**

1. Identify required inputs.
2. Check availability.
3. Check format.
4. Check completeness.
5. Document missing items.
6. Decide whether to proceed, ask clarification, or produce partial output.

**Example Use:** Spreadsheet consolidation, contract review, simulation input validation.

**Quality Checks:**

- Required inputs listed.
- Missing inputs documented.
- Assumptions stated.
- Output limitations described.

---

### P-002 — Evidence Fusion Pattern

**Problem:** Multiple sources may provide overlapping or conflicting information.

**Solution:** Normalize, compare, reconcile, and document evidence.

**Steps:**

1. Identify evidence items.
2. Normalize terminology.
3. Compare source claims.
4. Identify corroboration.
5. Identify conflicts.
6. Produce integrated finding.
7. Document uncertainty.

**Example Use:** Intelligence analysis, long document synthesis, early warning.

---

### P-003 — Source Ranking Pattern

**Problem:** Not all sources should be weighted equally.

**Solution:** Rank sources by authority, relevance, timeliness, and independence.

**Evaluation Fields:**

- Authority
- Authenticity
- Relevance
- Timeliness
- Independence
- Transparency
- Corroboration

**Output:** Source reliability score or qualitative rating.

---

### P-004 — Hallucination Detection Pattern

**Problem:** AI outputs may include unsupported statements.

**Solution:** Perform evidence-to-claim traceability review.

**Steps:**

1. Extract key claims.
2. Identify support for each claim.
3. Flag unsupported claims.
4. Remove or qualify unsupported content.
5. Document limitations.

**Quality Gate:** No high-impact factual claim should remain unsupported.

---

### P-005 — Decision Escalation Pattern

**Problem:** Some decisions require human review.

**Solution:** Escalate based on risk, uncertainty, or policy sensitivity.

**Escalation Triggers:**

- High consequence
- Low confidence
- Conflicting evidence
- Legal or ethical uncertainty
- User-specific policy decision
- Safety-sensitive recommendation

---

### P-006 — Confidence Calibration Pattern

**Problem:** Confidence is often overstated or inconsistently expressed.

**Solution:** Link confidence to evidence quality, quantity, agreement, and uncertainty.

**Output Fields:**

```yaml
finding:
confidence_level:
basis_for_confidence:
uncertainty:
what_would_change_assessment:
```

---

### P-007 — Output Verification Pattern

**Problem:** Deliverables may be incomplete or internally inconsistent.

**Solution:** Check against required output schema before delivery.

**Steps:**

1. Identify required sections.
2. Confirm all sections exist.
3. Check internal consistency.
4. Verify formatting.
5. Confirm requested export exists.

---

### P-008 — Conflict Resolution Pattern

**Problem:** Evidence, requirements, or instructions may conflict.

**Solution:** Classify conflict and resolve using priority rules.

**Resolution Order:**

1. Governing safety and system constraints.
2. User objective.
3. Evidence quality.
4. Domain standards.
5. Practical feasibility.

---

### P-009 — Prompt Compression Pattern

**Problem:** Long prompts become bloated and hard to maintain.

**Solution:** Move repeated guidance into shared references and compress task-specific instructions.

**Compression Strategy:**

- Remove duplicates.
- Use cross-references.
- Convert prose into checklists.
- Replace repeated examples with template references.
- Keep only task-critical context.

---

### P-010 — Knowledge Refresh Pattern

**Problem:** Knowledge becomes outdated.

**Solution:** Define review intervals and refresh triggers.

**Refresh Triggers:**

- New evidence
- Regulation change
- Benchmark failure
- User correction
- Scheduled review
- Domain event

---

# Part 3 — Anti-Pattern Catalog

## 3.1 Purpose

Anti-patterns identify common design failures and provide prevention and correction guidance.

## 3.2 Anti-Pattern Template

```yaml
anti_pattern_id:
name:
symptoms:
root_causes:
impact:
detection:
correction:
prevention:
related_patterns:
```

## 3.3 Core Anti-Patterns

### AP-001 — Prompt Bloat

**Symptoms:**

- Skill is long but unclear.
- Same rules repeated.
- Important constraints buried.

**Root Causes:**

- No shared framework references.
- Uncontrolled appending.
- Lack of refactoring.

**Correction:**

- Consolidate repeated sections.
- Move shared logic to Volume IV references.
- Use concise templates.

---

### AP-002 — Hidden Assumptions

**Symptoms:**

- Output relies on unstated conditions.
- User cannot tell what was assumed.

**Impact:**

- Reduced trust.
- Poor reproducibility.
- Incorrect downstream use.

**Correction:**

- Add assumption register.
- Require assumption disclosure in outputs.
- Add QA gate for assumptions.

---

### AP-003 — Undefined Scope

**Symptoms:**

- Skill tries to solve too many problems.
- Outputs drift from user objective.

**Correction:**

- Add in-scope and out-of-scope sections.
- Split large skills into modules.
- Add scope validation step.

---

### AP-004 — Weak QA

**Symptoms:**

- No benchmark suite.
- No self-test.
- No acceptance criteria.

**Correction:**

- Add QA checklist.
- Add benchmark cases.
- Add release gate.

---

### AP-005 — Unsupported Conclusions

**Symptoms:**

- Findings lack evidence.
- Recommendations are not traceable.

**Correction:**

- Add evidence table.
- Use evidence-to-finding traceability.
- Downgrade confidence.

---

### AP-006 — Monolithic Skill Design

**Symptoms:**

- Skill is one large undifferentiated block.
- Maintenance is difficult.

**Correction:**

- Decompose into modules.
- Define interfaces.
- Move repeated logic to shared libraries.

---

### AP-007 — Template Duplication

**Symptoms:**

- Same template appears in several modules.
- Updates become inconsistent.

**Correction:**

- Keep canonical template in Volume IV.
- Reference instead of copy.
- Maintain template version.

---

### AP-008 — No Failure Behavior

**Symptoms:**

- Skill fails silently.
- Skill fabricates missing information.
- Skill abandons task unnecessarily.

**Correction:**

- Define failure modes.
- Add fallback behaviors.
- Document partial completion rules.

---

### AP-009 — Overconfident Analysis

**Symptoms:**

- Strong language despite limited evidence.
- Uncertainty not discussed.

**Correction:**

- Add confidence calibration.
- Add uncertainty taxonomy.
- Require "what would change this assessment."

---

### AP-010 — Output Drift

**Symptoms:**

- Final product does not match requested output.
- Extra sections distract from purpose.

**Correction:**

- Add output schema.
- Validate final response against user request.
- Add deliverable QA gate.

---

# Part 4 — Decision Tree Catalog

## 4.1 Purpose

Decision trees standardize recurring choices.

They should be used when:

- A workflow branches.
- A skill must select a method.
- Escalation criteria are needed.
- User input is incomplete.
- Tool availability varies.

## 4.2 Decision Tree Template

```text
Decision Question
├── Condition A → Action A
├── Condition B → Action B
└── Condition C → Action C
```

## 4.3 Task Classification Decision Tree

```text
What is the user asking for?
├── Create or edit a skill → Use GPT Skill Builder workflow.
├── Evaluate AI output → Use AI Evaluation workflow.
├── Summarize documents → Use Long Document Synthesis workflow.
├── Monitor indicators → Use Early Warning workflow.
├── Build simulation → Use Simulation Development workflow.
├── Review contracts → Use Federal Contract Review workflow.
├── Evaluate program → Use Program Evaluation workflow.
└── Other → Use general Foundation workflow.
```

## 4.4 Clarification Decision Tree

```text
Is critical information missing?
├── No → Proceed.
└── Yes
    ↓
Can reasonable assumptions be made safely?
├── Yes → Proceed and state assumptions.
└── No → Ask targeted clarification.
```

## 4.5 Evidence Sufficiency Decision Tree

```text
Is evidence required?
├── No → Continue.
└── Yes
    ↓
Is evidence available?
├── Yes → Evaluate evidence quality.
└── No
    ↓
Can task proceed with assumptions?
├── Yes → State limitations.
└── No → Identify missing evidence.
```

## 4.6 QA Escalation Decision Tree

```text
Is the output high consequence?
├── Yes → Apply expanded QA.
└── No
    ↓
Is uncertainty high?
├── Yes → Apply expanded QA.
└── No
    ↓
Is output routine?
├── Yes → Apply standard QA.
└── No → Apply targeted QA.
```

## 4.7 Export Decision Tree

```text
Did the user request a file?
├── Yes → Generate downloadable artifact.
└── No
    ↓
Would a file materially improve reuse?
├── Yes → Offer or provide file if appropriate.
└── No → Respond in chat.
```

---

# Part 5 — Workflow Pattern Library

## 5.1 Purpose

Workflow patterns define reusable process structures.

## 5.2 Workflow Pattern Template

```yaml
workflow_pattern_id:
name:
use_when:
steps:
decision_points:
quality_gates:
outputs:
failure_modes:
example:
```

## 5.3 Standard Analytical Workflow

```text
Intake
  ↓
Evidence Collection
  ↓
Evidence Evaluation
  ↓
Analysis
  ↓
Alternative Review
  ↓
Confidence Assessment
  ↓
Recommendations
  ↓
QA
  ↓
Deliver
```

## 5.4 Standard Document Synthesis Workflow

```text
File Inventory
  ↓
Structure Detection
  ↓
Theme Extraction
  ↓
Entity Extraction
  ↓
Contradiction Detection
  ↓
Summary Generation
  ↓
Citation Mapping
  ↓
QA
  ↓
Export
```

## 5.5 Standard Simulation Workflow

```text
Scenario Definition
  ↓
Variable Registry
  ↓
Distribution Selection
  ↓
Model Logic
  ↓
Execution
  ↓
Sensitivity Analysis
  ↓
Validation
  ↓
Visualization
  ↓
Export
```

## 5.6 Standard Evaluation Workflow

```text
Define Criteria
  ↓
Collect Artifact
  ↓
Score Artifact
  ↓
Identify Defects
  ↓
Assess Severity
  ↓
Recommend Fixes
  ↓
Regression Test
  ↓
Report
```

## 5.7 Standard Knowledge Base Workflow

```text
Acquire
  ↓
Validate
  ↓
Normalize
  ↓
Classify
  ↓
Index
  ↓
Link
  ↓
Review
  ↓
Refresh
  ↓
Retire
```

---

# Part 6 — Prompt Pattern Library

## 6.1 Purpose

Prompt patterns provide reusable instruction structures.

## 6.2 Intake Prompt Pattern

```markdown
Identify:
- User objective
- Deliverable
- Inputs
- Constraints
- Audience
- Success criteria

Proceed with stated assumptions unless critical ambiguity prevents useful work.
```

## 6.3 Analytical Prompt Pattern

```markdown
Analyze using this sequence:
1. Define the question.
2. Identify evidence.
3. Separate facts from assumptions.
4. Consider alternatives.
5. Assess confidence.
6. Provide findings.
7. State limitations.
```

## 6.4 QA Prompt Pattern

```markdown
Before final output, verify:
- Request addressed
- Required sections included
- Evidence supports claims
- Assumptions stated
- Limitations identified
- Output format correct
```

## 6.5 Export Prompt Pattern

```markdown
When generating a file:
- Use a clear filename.
- Include version metadata.
- Validate that the file exists.
- Provide a download link.
```

## 6.6 Benchmark Prompt Pattern

```markdown
Evaluate the skill against:
- Functional correctness
- Output completeness
- Analytical quality
- Robustness
- Traceability
- User usefulness
```

---

# Part 7 — QA Framework Library

## 7.1 Purpose

This section provides reusable QA frameworks.

## 7.2 General QA Checklist

- User request addressed.
- Scope maintained.
- Inputs validated.
- Assumptions stated.
- Evidence reviewed.
- Reasoning coherent.
- Alternatives considered where appropriate.
- Output format correct.
- Limitations documented.
- File artifacts validated.

## 7.3 Analytical QA Checklist

- Problem framed correctly.
- Evidence quality assessed.
- Claims traceable.
- Confidence calibrated.
- Uncertainty documented.
- Recommendations supported.

## 7.4 Document QA Checklist

- All files inventoried.
- Major sections detected.
- Key themes extracted.
- Contradictions flagged.
- Citations preserved.
- Summary reflects source content.

## 7.5 Spreadsheet QA Checklist

- Sheets inventoried.
- Headers validated.
- Missing values flagged.
- Formulas checked.
- Outputs open correctly.
- Summary tables match source data.

## 7.6 Skill QA Checklist

- Mission clear.
- Requirements traceable.
- Workflow documented.
- Instructions coherent.
- Benchmarks included.
- Failure modes documented.
- Changelog updated.

---

# Part 8 — Benchmark Framework Library

## 8.1 Purpose

Benchmark frameworks provide repeatable ways to measure performance.

## 8.2 Benchmark Metadata Template

```yaml
benchmark_id:
name:
skill:
objective:
input:
expected_behavior:
expected_output:
scoring_method:
passing_threshold:
version:
```

## 8.3 Benchmark Categories

- Functional benchmarks
- Robustness benchmarks
- Analytical benchmarks
- Citation benchmarks
- Formatting benchmarks
- Regression benchmarks
- Performance benchmarks

## 8.4 Scoring Rubric Template

| Criterion | Weight | Score | Notes |
|---|---:|---:|---|
| Completeness | 25% |  |  |
| Accuracy | 25% |  |  |
| Traceability | 20% |  |  |
| Clarity | 15% |  |  |
| Actionability | 15% |  |  |

## 8.5 Benchmark Result Template

```yaml
benchmark_id:
date:
skill_version:
score:
pass_fail:
observations:
regressions:
recommended_actions:
```

## 8.6 Minimum Benchmark Suite for New Skills

Every new skill should include at least:

- One normal case.
- One incomplete input case.
- One edge case.
- One failure case.
- One output validation case.

---

# Part 9 — Failure Mode Catalog

## 9.1 Purpose

Failure modes describe how AI skills can fail and how to detect, recover from, and prevent those failures.

## 9.2 Failure Mode Template

```yaml
failure_id:
name:
description:
symptoms:
causes:
impact:
detection:
recovery:
prevention:
severity:
```

## 9.3 Common Failure Modes

### FM-001 — Missing Input Failure

**Symptoms:** Output lacks required analysis.

**Recovery:** Ask targeted clarification or proceed with explicit assumptions.

### FM-002 — Evidence Gap Failure

**Symptoms:** Findings are weak or unsupported.

**Recovery:** Flag evidence gap, reduce confidence, avoid strong conclusions.

### FM-003 — Formatting Failure

**Symptoms:** Output does not match requested format.

**Recovery:** Regenerate using output schema.

### FM-004 — Reasoning Drift

**Symptoms:** Analysis moves away from user question.

**Recovery:** Reframe objective and re-run analytical workflow.

### FM-005 — Citation Loss

**Symptoms:** Source references are missing.

**Recovery:** Rebuild evidence-to-claim mapping.

### FM-006 — Benchmark Failure

**Symptoms:** Skill fails expected behavior.

**Recovery:** Identify failing requirement, revise skill, rerun benchmark.

### FM-007 — Over-Summarization

**Symptoms:** Important detail removed.

**Recovery:** Re-expand with source-linked detail.

### FM-008 — Scope Creep

**Symptoms:** Skill expands beyond intended task.

**Recovery:** Reassert scope and split into separate modules if needed.

---

# Part 10 — Template Library

## 10.1 Purpose

Templates standardize repeated work.

## 10.2 Skill Template

```yaml
name:
title:
version:
status:
inherits:
mission:
scope:
users:
inputs:
outputs:
constraints:
workflow:
qa:
benchmarks:
failure_modes:
changelog:
```

## 10.3 Report Template

```markdown
# Title

## Executive Summary

## Purpose

## Scope

## Methodology

## Findings

## Analysis

## Confidence

## Recommendations

## Limitations

## Appendices
```

## 10.4 Evidence Table Template

| Claim | Evidence | Source | Confidence | Notes |
|---|---|---|---|---|

## 10.5 Risk Register Template

| Risk | Cause | Impact | Likelihood | Mitigation | Owner | Status |
|---|---|---|---|---|---|---|

## 10.6 Decision Log Template

| Date | Decision | Rationale | Alternatives Considered | Owner |
|---|---|---|---|---|

## 10.7 Changelog Template

```markdown
# Changelog

## vX.Y.Z

Added:
Changed:
Fixed:
Deprecated:
Known Issues:
```

---

# Part 11 — Risk, Issue & Defect Registers

## 11.1 Purpose

Registers provide structured tracking of known risks, open issues, defects, and technical debt.

## 11.2 Issue Register

| Issue ID | Description | Severity | Owner | Status | Resolution |
|---|---|---|---|---|---|

## 11.3 Defect Register

| Defect ID | Module | Symptom | Root Cause | Fix | Validation |
|---|---|---|---|---|---|

## 11.4 Technical Debt Register

| Debt ID | Area | Description | Impact | Priority | Resolution Plan |
|---|---|---|---|---|---|

## 11.5 Risk Register

| Risk ID | Risk | Probability | Impact | Mitigation | Owner |
|---|---|---|---|---|---|

## 11.6 Register QA Checklist

- Every item has an owner.
- Severity or priority assigned.
- Status current.
- Resolution path documented.
- Closed items validated.
- Recurring issues reviewed for root cause.

---

# Part 12 — Continuous Improvement Framework

## 12.1 Purpose

Continuous improvement turns operational experience into better skills, workflows, and frameworks.

## 12.2 Improvement Cycle

```text
Observe
  ↓
Measure
  ↓
Analyze
  ↓
Prioritize
  ↓
Implement
  ↓
Validate
  ↓
Release
  ↓
Monitor
```

## 12.3 Improvement Sources

- User feedback
- Benchmark failures
- Regression tests
- Defects
- New requirements
- New domain knowledge
- Model changes
- Tool changes

## 12.4 Improvement Proposal Template

```yaml
proposal_id:
title:
problem:
evidence:
proposed_change:
affected_modules:
expected_benefit:
risk:
validation_plan:
status:
```

## 12.5 Lessons Learned Template

```yaml
project:
context:
what_worked:
what_failed:
root_causes:
recommendations:
reusable_patterns:
new_benchmarks:
```

## 12.6 Continuous Improvement QA

- Improvement tied to evidence.
- Impact assessed.
- Regression risk reviewed.
- Benchmark updated if needed.
- Changelog updated.
- Lessons learned captured.

---



---


# R4 — Volume V Professional Domain Skill Patterns

<!-- Source lines 7564-9452 from AIPSL_Combined_Core_Volumes_I-V.skill.md -->


# Part 2 — Prompt Engineering Skill

## 2.1 Skill Contract

```text
Skill Name: Prompt Engineering Skill
Purpose: Design, diagnose, improve, test, and document prompts and skill files for professional AI systems.
Primary Users: AI builders, analysts, product owners, evaluators, trainers, and workflow designers.
Inputs: User goal, model context, constraints, source materials, target deliverable, evaluation criteria, safety requirements.
Outputs: Prompt, skill.md, prompt architecture, test cases, evaluation rubric, failure-mode analysis, improvement plan.
Quality Gates: Clarity, specificity, completeness, testability, safety, maintainability, and alignment with user objective.
```

## 2.2 Mission

The Prompt Engineering Skill converts a user objective into a structured, reusable instruction system that can be tested, maintained, and improved over time. It is not limited to writing a single prompt. It should design the operating logic around the prompt, including context ingestion, workflow sequence, output standards, validation checks, and regression tests.

## 2.3 When to Use

Use this skill when the user asks to:

- Build a prompt.
- Improve an existing prompt.
- Build a `.skill.md` file.
- Convert a workflow into reusable AI instructions.
- Design a tool-building prompt.
- Create a prompt for another model.
- Diagnose why a prompt is failing.
- Add quality gates, safety controls, or output formatting rules.
- Convert an ad hoc instruction into an enterprise reusable module.

## 2.4 Core Workflow

```text
Clarify Mission
  ↓
Define Audience and Operating Context
  ↓
Extract Requirements
  ↓
Identify Constraints and Non-Negotiables
  ↓
Select Prompt Architecture
  ↓
Write Modular Instructions
  ↓
Define Output Contract
  ↓
Add QA and Self-Review
  ↓
Add Test Cases
  ↓
Deliver Prompt and Usage Notes
```

## 2.5 Prompt Architecture Patterns

### Direct Task Prompt

Use for simple one-time tasks where the user needs a direct output.

### Role + Workflow Prompt

Use when the model must act in a professional role and follow a repeatable process.

### Skill File Prompt

Use when the model must behave consistently across many tasks and inherit reusable operating rules.

### Tool Builder Prompt

Use when the output is code, an HTML application, a dashboard, a spreadsheet generator, or another executable artifact.

### Evaluation Prompt

Use when the model must assess outputs against explicit criteria.

### Agentic Workflow Prompt

Use when the task requires planning, tool use, iterative validation, and multiple deliverables.

## 2.6 Required Prompt Elements

A professional prompt should specify:

- Role and mission
- Scope and out-of-scope boundaries
- Inputs the model should expect
- Required reasoning or workflow steps
- Evidence and source rules
- Output format
- Quality standards
- Error handling
- Safety constraints
- Examples when helpful
- Acceptance criteria

## 2.7 Prompt Requirements Extraction

When converting a user request into a prompt, extract:

```text
Objective:
Target user:
Domain:
Input types:
Output types:
Required features:
Optional features:
Security constraints:
Data constraints:
Source constraints:
Export requirements:
Quality requirements:
Evaluation criteria:
Known failure modes:
```

## 2.8 Skill.md Construction Pattern

A reusable `skill.md` should include:

1. Metadata
2. Mission
3. Activation conditions
4. Required inputs
5. Workflow
6. Output standards
7. Evidence and validation rules
8. Quality gates
9. Failure modes
10. Examples
11. Benchmark tests
12. Changelog

## 2.9 Prompt QA Checklist

Before finalizing a prompt, verify:

- It states the mission clearly.
- It is specific enough to execute.
- It avoids unnecessary complexity.
- It includes output formatting requirements.
- It identifies quality checks.
- It handles incomplete information.
- It defines what not to do.
- It avoids contradictory instructions.
- It can be tested with realistic examples.
- It supports future modification.

## 2.10 Prompt Failure Modes

Common failures include:

- Vague role definition
- Missing deliverable format
- Hidden assumptions
- Overloaded task scope
- Conflicting requirements
- No quality criteria
- No failure behavior
- Excessive verbosity
- No examples for complex outputs
- No regression tests

## 2.11 Prompt Benchmark Tests

Use benchmark tasks such as:

```text
Benchmark ID: PE-001
Task: Convert a vague user request into a structured prompt.
Pass Criteria: Prompt includes role, mission, workflow, inputs, outputs, constraints, QA, and acceptance criteria.
```

```text
Benchmark ID: PE-002
Task: Diagnose a failing prompt that produces inconsistent outputs.
Pass Criteria: Identifies ambiguity, missing constraints, weak output contract, and proposes corrected prompt.
```

```text
Benchmark ID: PE-003
Task: Build a skill.md for a domain workflow.
Pass Criteria: Produces reusable, modular skill file with activation conditions, workflow, QA, and benchmarks.
```

---

# Part 3 — AI Evaluation Skill

## 3.1 Skill Contract

```text
Skill Name: AI Evaluation Skill
Purpose: Evaluate AI systems, prompts, tools, outputs, agents, and workflows against explicit criteria.
Primary Users: AI builders, QA reviewers, product owners, analysts, auditors, and governance teams.
Inputs: AI output, intended task, source materials, rubric, benchmark data, acceptance criteria, model constraints.
Outputs: Evaluation report, rubric scores, defect log, risk assessment, benchmark results, improvement recommendations.
Quality Gates: Rubric validity, evidence traceability, reproducibility, fairness, severity classification, and actionable findings.
```

## 3.2 Mission

The AI Evaluation Skill determines whether an AI output or system is fit for purpose. It evaluates correctness, completeness, reasoning quality, evidence use, format compliance, safety, maintainability, and operational reliability. It should identify defects, explain their significance, and recommend practical improvements.

## 3.3 When to Use

Use this skill when the user asks to:

- Review an AI-generated product.
- Evaluate a prompt or skill file.
- Compare model outputs.
- Build an evaluation rubric.
- Create benchmark tests.
- Conduct regression testing.
- Assess hallucination risk.
- Check compliance with instructions.
- Identify weaknesses in a tool or workflow.
- Murderboard or red-team an analytical product.

## 3.4 Evaluation Workflow

```text
Define Intended Use
  ↓
Extract Requirements
  ↓
Select Evaluation Rubric
  ↓
Inspect Output Against Source Materials
  ↓
Score Quality Dimensions
  ↓
Identify Defects and Severity
  ↓
Assess Risk and Impact
  ↓
Recommend Improvements
  ↓
Define Regression Tests
  ↓
Produce Evaluation Report
```

## 3.5 Standard Evaluation Dimensions

### Task Alignment

Does the output satisfy the user’s actual objective?

### Factual Accuracy

Are factual claims supported by reliable evidence?

### Completeness

Does the output address all required elements?

### Reasoning Quality

Are conclusions logically connected to evidence?

### Source Integrity

Are sources appropriate, cited, and represented accurately?

### Uncertainty Handling

Are assumptions and confidence levels explicit?

### Safety and Policy Compliance

Does the output avoid harmful or prohibited assistance?

### Format Compliance

Does the output follow requested structure and file requirements?

### Usability

Can the intended user act on the output?

### Maintainability

Can the product be updated, tested, and reused?

## 3.6 Defect Severity Scale

### Critical

The output is materially wrong, unsafe, or unusable for the intended purpose.

### Major

The output has important omissions or errors that require correction before use.

### Moderate

The output is useful but contains weaknesses that reduce reliability or clarity.

### Minor

The output has cosmetic, style, or low-impact issues.

## 3.7 Evaluation Report Template

```text
Evaluation Title:
Object Evaluated:
Intended Use:
Evaluation Date:
Evaluator:
Overall Rating:
Summary Judgment:
Strengths:
Critical Defects:
Major Defects:
Moderate Defects:
Minor Defects:
Rubric Scores:
Evidence Review:
Risk Assessment:
Recommended Corrections:
Regression Tests:
Final Disposition:
```

## 3.8 Rubric Template

```text
Criterion:
Description:
Weight:
Score Scale:
Evidence Required:
Pass Threshold:
Failure Examples:
Reviewer Notes:
```

## 3.9 Regression Testing Pattern

Regression testing should compare new outputs against prior accepted behavior.

```text
Baseline Output
  ↓
New Output
  ↓
Difference Analysis
  ↓
Materiality Review
  ↓
Accepted / Rejected Change
  ↓
Update Benchmark Record
```

## 3.10 AI Evaluation Anti-Patterns

Avoid:

- Evaluating style while ignoring factual accuracy.
- Scoring without a rubric.
- Treating fluency as correctness.
- Ignoring source quality.
- Penalizing reasonable uncertainty.
- Failing to distinguish defects from preferences.
- Providing criticism without corrective guidance.
- Using a single test case to certify broad reliability.

## 3.11 Benchmark Tests

```text
Benchmark ID: AIE-001
Task: Evaluate a report that contains unsupported claims and weak confidence language.
Pass Criteria: Identifies unsupported claims, labels severity, and recommends source-backed corrections.
```

```text
Benchmark ID: AIE-002
Task: Compare two model outputs against a rubric.
Pass Criteria: Scores both outputs consistently and justifies differences with evidence.
```

```text
Benchmark ID: AIE-003
Task: Build a regression suite for a reusable prompt.
Pass Criteria: Defines representative inputs, expected behaviors, failure cases, and pass thresholds.
```

---

# Part 4 — Simulation Development Skill

## 4.1 Skill Contract

```text
Skill Name: Simulation Development Skill
Purpose: Design, document, build, test, and improve simulations, forecasting models, Monte Carlo tools, dashboards, and secure single-file applications.
Primary Users: Analysts, modelers, planners, tool builders, trainers, educators, and decision-support teams.
Inputs: Scenario, variables, assumptions, datasets, equations, constraints, output requirements, validation criteria.
Outputs: Simulation design, model specification, HTML tool prompt, spreadsheet model, Monte Carlo framework, validation plan, user guide.
Quality Gates: Model logic, parameter transparency, sensitivity testing, validation, usability, export reliability, and security constraints.
```

## 4.2 Mission

The Simulation Development Skill converts a scenario or analytical problem into a transparent, testable simulation. It supports deterministic models, stochastic simulations, Monte Carlo engines, discrete-event simulations, system dynamics, physics-inspired models, geospatial visualizations, dashboards, and offline browser-based tools.

## 4.3 When to Use

Use this skill when the user asks to:

- Build a simulation.
- Build a Monte Carlo model.
- Build a dashboard from data.
- Build a single-file `.html` tool.
- Model scenarios over time.
- Forecast distributions rather than point estimates.
- Test assumptions and sensitivities.
- Visualize system behavior.
- Create an exportable spreadsheet or CSV from model outputs.

## 4.4 Simulation Workflow

```text
Define Decision Problem
  ↓
Define System Boundary
  ↓
Identify Entities, Variables, and Flows
  ↓
Classify Variables as Inputs, States, Parameters, or Outputs
  ↓
Select Simulation Type
  ↓
Define Equations and Logic
  ↓
Set Distributions and Assumptions
  ↓
Run Baseline Scenario
  ↓
Run Sensitivity and Stress Tests
  ↓
Validate Against Known Behavior
  ↓
Generate Outputs and User Guide
```

## 4.5 Simulation Types

### Deterministic Calculator

Use when relationships are fixed and uncertainty is low.

### Monte Carlo Simulation

Use when uncertainty in inputs materially affects outputs.

### Discrete-Event Simulation

Use when the timing and sequencing of events matter.

### System Dynamics

Use when feedback loops, stocks, and flows drive outcomes.

### Agent-Based Simulation

Use when individual actor behavior produces system-level outcomes.

### Physics-Based Simulation

Use when motion, forces, energy, or environmental interactions must be modeled.

### Scenario Dashboard

Use when users need to change assumptions and immediately compare outcomes.

## 4.6 Simulation Model Specification

Every simulation should document:

```text
Model Name:
Purpose:
Decision Supported:
System Boundary:
Time Horizon:
Time Step:
Entities:
State Variables:
Input Variables:
Parameters:
Output Variables:
Equations:
Distributions:
Assumptions:
Data Sources:
Validation Method:
Known Limitations:
Export Formats:
```

## 4.7 Distribution Selection Guide

### Fixed Value

Use when the value is known or policy-defined.

### Uniform Distribution

Use when only a plausible range is known and all values are treated as equally likely.

### Triangular Distribution

Use when minimum, most likely, and maximum values are known.

### Normal Distribution

Use when values cluster symmetrically around a mean and negative or impossible values are controlled.

### Lognormal Distribution

Use for positive skewed values such as losses, costs, durations, and demand spikes.

### Beta or PERT Distribution

Use when bounded uncertainty should concentrate around a most likely value.

### Empirical Distribution

Use when historical data are available and should drive the sample behavior.

## 4.8 Monte Carlo Output Requirements

Monte Carlo outputs should include:

- Number of iterations
- Random seed option when reproducibility is needed
- Mean
- Median
- Standard deviation
- Minimum
- Maximum
- Percentiles
- Confidence intervals when appropriate
- Tornado or sensitivity ranking when feasible
- Scenario comparison table
- Assumptions log

## 4.9 Secure Single-File Tool Requirements

When building a secure `.html` tool, default requirements should include:

- No external dependencies unless explicitly permitted.
- All JavaScript, CSS, and logic embedded locally.
- No network calls unless explicitly allowed.
- User files processed locally in the browser.
- Clear import and export controls.
- Export to relevant formats such as CSV, JSON, Markdown, Excel-compatible CSV, or printable HTML.
- Graceful error handling.
- Data reset capability.
- Documentation embedded in the tool.

## 4.10 Simulation QA Checklist

Verify:

- Variables are defined.
- Units are consistent.
- Equations are documented.
- Assumptions are explicit.
- Distributions are justified.
- Outputs are interpretable.
- Edge cases are handled.
- Sensitivity testing is included.
- Export functions work.
- Model limitations are visible to the user.

## 4.11 Simulation Failure Modes

Common failures include:

- False precision
- Hidden assumptions
- Unit mismatches
- Unbounded distributions
- Unrealistic default parameters
- No sensitivity testing
- Confusing scenario outputs with predictions
- Visualization without explanation
- Browser performance failure for large datasets
- Export files that omit key assumptions

## 4.12 Benchmark Tests

```text
Benchmark ID: SIM-001
Task: Build a Monte Carlo design for a scenario with uncertain cost, duration, and impact.
Pass Criteria: Defines variables, distributions, iterations, outputs, sensitivity tests, and limitations.
```

```text
Benchmark ID: SIM-002
Task: Design an offline HTML dashboard for uploaded spreadsheet data.
Pass Criteria: No external dependencies, local file processing, field selection, charts, summaries, and export options.
```

```text
Benchmark ID: SIM-003
Task: Diagnose a simulation whose outputs are unstable or implausible.
Pass Criteria: Identifies model structure, parameter, unit, distribution, or code causes and proposes fixes.
```

---

# Part 5 — Long Document Synthesis Skill

## 5.1 Skill Contract

```text
Skill Name: Long Document Synthesis Skill
Purpose: Ingest, map, summarize, analyze, compare, and synthesize long documents or document collections.
Primary Users: Analysts, reviewers, executives, editors, researchers, attorneys, evaluators, and program managers.
Inputs: Documents, user questions, scope, target audience, citation requirements, output format, analytic standards.
Outputs: Executive summary, detailed synthesis, issue map, evidence matrix, contradictions log, recommendations, appendices.
Quality Gates: Coverage, source fidelity, citation accuracy, theme extraction, contradiction handling, and traceability.
```

## 5.2 Mission

The Long Document Synthesis Skill turns large documents or collections into structured decision support. It should preserve source fidelity, cite claims to the relevant document locations, identify themes and contradictions, and distinguish what the source says from what the analyst infers.

## 5.3 When to Use

Use this skill when the user asks to:

- Summarize a long document.
- Compare multiple reports.
- Extract themes from a corpus.
- Create an executive summary.
- Build a document map or outline.
- Find contradictions or gaps.
- Convert long source material into a decision memo.
- Extract requirements, risks, tasks, accomplishments, or recommendations.
- Synthesize across emails, reports, contracts, policies, or technical documents.

## 5.4 Document Synthesis Workflow

```text
Define User Question
  ↓
Inventory Documents
  ↓
Map Structure and Sections
  ↓
Extract Key Claims and Evidence
  ↓
Cluster Themes
  ↓
Identify Contradictions and Gaps
  ↓
Synthesize Findings
  ↓
Separate Source Claims from Analysis
  ↓
Generate Output with Citations
  ↓
Validate Coverage and Fidelity
```

## 5.5 Document Inventory Template

```text
Document Title:
File Name:
Date:
Author / Originator:
Document Type:
Scope:
Pages / Length:
Primary Topics:
Reliability Notes:
Known Limitations:
Priority for Review:
```

## 5.6 Synthesis Output Levels

### Level 1 — Executive Brief

A concise summary of the most important findings and implications.

### Level 2 — Structured Summary

A section-by-section or theme-by-theme summary preserving major details.

### Level 3 — Analytical Synthesis

Cross-document analysis that integrates findings, identifies patterns, and develops judgments.

### Level 4 — Evidence Matrix

A structured table linking claims, supporting excerpts, sources, confidence, and relevance.

### Level 5 — Decision Product

A complete memo, report, or recommendation package built from the source synthesis.

## 5.7 Evidence Matrix Template

```text
Finding:
Supporting Source:
Location:
Evidence Summary:
Direct Quote if Needed:
Corroborating Source:
Contradictory Evidence:
Analytical Significance:
Confidence:
```

## 5.8 Theme Extraction Pattern

Themes should be extracted through:

```text
Repeated Concepts
  +
High-Significance Claims
  +
Decision-Relevant Evidence
  +
Cross-Document Consistency
  =
Candidate Theme
```

Candidate themes should be tested against the source material before inclusion.

## 5.9 Contradiction Handling

When sources conflict:

1. Identify the specific conflict.
2. Cite or reference the competing claims.
3. Assess source quality and recency.
4. Determine whether the conflict is factual, definitional, methodological, or interpretive.
5. State whether the conflict can be resolved.
6. Explain how the conflict affects confidence.

## 5.10 Synthesis QA Checklist

Verify:

- The output answers the user question.
- Major sections or documents were covered.
- Claims are traceable to source material.
- Direct quotes are not overused.
- Analysis is separated from source summary.
- Contradictions are not hidden.
- Confidence reflects evidence quality.
- The output is appropriate for the intended audience.

## 5.11 Failure Modes

Common failures include:

- Summarizing only the first or most salient section.
- Losing important minority views.
- Treating document claims as verified facts.
- Failing to cite source locations.
- Over-compressing technical material.
- Ignoring tables, footnotes, or appendices.
- Missing contradictions between documents.
- Producing a summary without decision relevance.

## 5.12 Benchmark Tests

```text
Benchmark ID: LDS-001
Task: Summarize a 100-page report into a 2-page executive brief and a detailed appendix.
Pass Criteria: Covers major sections, preserves key evidence, separates findings from recommendations, and cites source locations.
```

```text
Benchmark ID: LDS-002
Task: Compare three documents with conflicting claims.
Pass Criteria: Identifies conflicts, assesses source quality, explains confidence impact, and avoids false reconciliation.
```

```text
Benchmark ID: LDS-003
Task: Extract requirements from a policy document.
Pass Criteria: Produces traceable requirement list with source location, obligation type, responsible party, and deadline where available.
```

---

# Part 6 — Early Warning Skill

## 6.1 Skill Contract

```text
Skill Name: Early Warning Skill
Purpose: Build indicator frameworks, detect meaningful change, assess weak signals, and produce warning products for emerging risks or opportunities.
Primary Users: Analysts, planners, risk managers, executives, program managers, and operations teams.
Inputs: Watch topic, baseline, indicators, data sources, thresholds, reporting cadence, decision triggers, confidence criteria.
Outputs: Warning framework, indicator matrix, watch report, alert, trend assessment, decision triggers, collection plan.
Quality Gates: Indicator validity, source reliability, baseline clarity, threshold logic, false-positive control, confidence calibration.
```

## 6.2 Mission

The Early Warning Skill helps users detect change before consequences fully materialize. It transforms a broad concern into observable indicators, baselines, thresholds, collection plans, and warning judgments.

## 6.3 When to Use

Use this skill when the user asks to:

- Monitor an emerging risk.
- Build an indicator framework.
- Identify warning signs.
- Produce a trend watch report.
- Detect weak signals.
- Develop alert thresholds.
- Compare current conditions to a baseline.
- Build a collection plan for a topic.
- Track changes in markets, policy, operations, security, infrastructure, weather, disease, or program performance.

## 6.4 Early Warning Workflow

```text
Define Warning Question
  ↓
Identify Decision That Warning Supports
  ↓
Establish Baseline
  ↓
Build Indicator Set
  ↓
Classify Indicators by Type
  ↓
Define Thresholds
  ↓
Identify Sources and Collection Cadence
  ↓
Assess Current Signals
  ↓
Evaluate Alternative Explanations
  ↓
Issue Warning Judgment
  ↓
Recommend Monitoring and Actions
```

## 6.5 Indicator Types

### Leading Indicators

Signals that tend to appear before the outcome.

### Concurrent Indicators

Signals that occur as the condition changes.

### Lagging Indicators

Signals that confirm a change after it has occurred.

### Structural Indicators

Stable conditions that shape vulnerability or likelihood.

### Behavioral Indicators

Actions taken by people, organizations, adversaries, customers, markets, or agencies.

### Environmental Indicators

Weather, economic, political, technological, biological, or infrastructure conditions.

## 6.6 Indicator Matrix Template

```text
Indicator:
Type:
Observed Behavior:
Baseline:
Threshold:
Source:
Collection Frequency:
Reliability:
Warning Significance:
False Positive Risk:
Confidence:
Action Trigger:
```

## 6.7 Threshold Design

Thresholds may be:

### Numeric

Example: value exceeds a defined percentage or count.

### Directional

Example: sustained increase, decline, acceleration, or volatility.

### Pattern-Based

Example: multiple weak signals appearing together.

### Event-Based

Example: a policy announcement, system outage, operational incident, or confirmed case.

### Composite

Example: alert triggers when three or more indicators move from green to amber within a defined period.

## 6.8 Warning Levels

Use a consistent warning scale:

### Green

Normal or baseline conditions.

### Blue

Notable change, but no immediate action required.

### Amber

Emerging concern requiring monitoring or preparatory action.

### Red

Material change requiring decision-maker attention or response.

### Black

Severe or cascading disruption requiring immediate escalation.

## 6.9 Warning Product Template

```text
Warning Topic:
Date:
Bottom Line:
Current Warning Level:
What Changed:
Most Important Indicators:
Alternative Explanations:
Confidence:
Potential Impacts:
Recommended Actions:
What to Watch Next:
Source and Data Limitations:
```

## 6.10 False Positive and False Negative Control

Early warning systems must manage two risks:

- **False positives:** alerting when no meaningful change is occurring.
- **False negatives:** missing a meaningful change until too late.

The skill should document which error is more costly for the use case and calibrate thresholds accordingly.

## 6.11 Failure Modes

Common failures include:

- Indicators that cannot be observed.
- Thresholds with no baseline.
- Overreacting to isolated anecdotes.
- Ignoring alternative explanations.
- Treating lagging indicators as early warning.
- No decision linkage.
- No review cadence.
- Too many indicators to maintain.
- No distinction between watch, warning, and recommendation.

## 6.12 Benchmark Tests

```text
Benchmark ID: EW-001
Task: Build an early warning framework for a transportation disruption risk.
Pass Criteria: Defines baseline, indicators, thresholds, sources, warning levels, and action triggers.
```

```text
Benchmark ID: EW-002
Task: Assess whether recent signals justify escalation.
Pass Criteria: Compares current data to baseline, considers alternatives, calibrates confidence, and recommends monitoring steps.
```

```text
Benchmark ID: EW-003
Task: Diagnose a noisy warning system.
Pass Criteria: Identifies weak indicators, threshold problems, source quality issues, and false-positive controls.
```

---

# Part 7 — Program Evaluation Skill

## 7.1 Skill Contract

```text
Skill Name: Program Evaluation Skill
Purpose: Evaluate whether a program is well-designed, implemented effectively, producing intended outcomes, and improving over time.
Primary Users: Program managers, executives, auditors, evaluators, analysts, grant managers, and policy teams.
Inputs: Program documents, goals, logic model, metrics, performance data, costs, stakeholders, implementation history, constraints.
Outputs: Evaluation plan, logic model, findings, performance assessment, outcome assessment, risk register, recommendations, improvement roadmap.
Quality Gates: Evaluation question clarity, metric validity, evidence quality, causal caution, stakeholder relevance, and actionable recommendations.
```

## 7.2 Mission

The Program Evaluation Skill assesses program performance and improvement opportunities. It should distinguish program design, implementation, outputs, outcomes, cost-effectiveness, risks, and sustainability.

## 7.3 When to Use

Use this skill when the user asks to:

- Evaluate a program.
- Build a logic model.
- Review goals, metrics, and outcomes.
- Assess program effectiveness.
- Identify performance gaps.
- Recommend improvements.
- Compare program options.
- Develop an evaluation plan.
- Analyze whether a program is achieving intended results.

## 7.4 Evaluation Workflow

```text
Define Evaluation Purpose
  ↓
Identify Stakeholders and Decisions
  ↓
Build or Review Logic Model
  ↓
Define Evaluation Questions
  ↓
Identify Metrics and Evidence
  ↓
Assess Implementation
  ↓
Assess Outputs and Outcomes
  ↓
Assess Cost, Risk, and Sustainability
  ↓
Develop Findings
  ↓
Recommend Improvements
  ↓
Define Monitoring Plan
```

## 7.5 Logic Model Template

```text
Problem Statement:
Program Purpose:
Inputs:
Activities:
Outputs:
Short-Term Outcomes:
Intermediate Outcomes:
Long-Term Outcomes:
Assumptions:
External Factors:
Metrics:
Data Sources:
Risks:
```

## 7.6 Evaluation Question Types

### Design Questions

Is the program logically designed to address the problem?

### Implementation Questions

Is the program being executed as intended?

### Output Questions

What products, services, or activities are being delivered?

### Outcome Questions

What changed because of the program?

### Efficiency Questions

Are resources being used well?

### Equity and Access Questions

Are benefits and burdens distributed appropriately?

### Sustainability Questions

Can the program maintain performance over time?

## 7.7 Evidence Standards

Program evidence should be classified by strength:

### Strong

Direct outcome data with credible comparison, trend, or causal design.

### Moderate

Reliable performance data and plausible linkage to outcomes.

### Limited

Outputs, testimonials, process data, or incomplete performance data.

### Insufficient

Anecdotal or unsupported evidence that cannot support a finding.

## 7.8 Findings Template

```text
Finding:
Evaluation Question:
Evidence:
Analysis:
Confidence:
Significance:
Recommendation:
Implementation Considerations:
```

## 7.9 Recommendation Design

Recommendations should be:

- Specific
- Actionable
- Evidence-linked
- Feasible
- Prioritized
- Time-bound where possible
- Assigned to responsible owners when known
- Paired with success metrics

## 7.10 Program Evaluation QA Checklist

Verify:

- Evaluation questions are clear.
- Metrics match program goals.
- Outputs are not confused with outcomes.
- Causal claims are appropriately qualified.
- Stakeholder needs are addressed.
- Findings are evidence-backed.
- Recommendations are implementable.
- Limitations are disclosed.

## 7.11 Failure Modes

Common failures include:

- Treating activity as impact.
- Using available metrics rather than meaningful metrics.
- Ignoring implementation constraints.
- Making causal claims without causal evidence.
- Producing generic recommendations.
- Ignoring cost or sustainability.
- Failing to include external factors.
- Overlooking unintended consequences.

## 7.12 Benchmark Tests

```text
Benchmark ID: PEVAL-001
Task: Build a logic model from a short program description.
Pass Criteria: Correctly identifies inputs, activities, outputs, outcomes, assumptions, external factors, and metrics.
```

```text
Benchmark ID: PEVAL-002
Task: Evaluate a program with output data but weak outcome data.
Pass Criteria: Separates output findings from outcome uncertainty and recommends data improvements.
```

```text
Benchmark ID: PEVAL-003
Task: Produce an improvement roadmap from evaluation findings.
Pass Criteria: Prioritizes recommendations by impact, feasibility, cost, risk, and implementation sequence.
```

---

# Part 8 — Federal Contract Review Skill

## 8.1 Skill Contract

```text
Skill Name: Federal Contract Review Skill
Purpose: Review federal contract materials for structure, obligations, risks, duplication, inefficiencies, compliance issues, and improvement opportunities.
Primary Users: Contracting officers, CORs, program managers, auditors, analysts, acquisition teams, and efficiency review teams.
Inputs: Contracts, statements of work, performance work statements, solicitations, modifications, invoices, pricing data, deliverables, vendor data, performance records.
Outputs: Contract summary, obligation matrix, risk register, duplication analysis, efficiency findings, compliance flags, recommended actions, review memo.
Quality Gates: Source fidelity, clause and obligation traceability, factual caution, procurement integrity, and actionable findings.
```

## 8.2 Mission

The Federal Contract Review Skill analyzes contract documents and supporting materials to help users understand what the government bought, what obligations exist, what risks or inefficiencies may be present, and what actions may improve oversight or value.

The skill does not replace legal counsel, contracting authority, or procurement officials. It supports review, triage, summarization, and decision preparation.

## 8.3 When to Use

Use this skill when the user asks to:

- Summarize a contract.
- Extract obligations from contract documents.
- Identify duplication across contracts.
- Review performance requirements.
- Compare vendors or contract vehicles.
- Identify potential efficiencies.
- Build a contract review tool or test dataset.
- Flag missing deliverables, unclear requirements, or oversight risks.
- Prepare a contract review memo.

## 8.4 Contract Review Workflow

```text
Inventory Contract Materials
  ↓
Identify Contract Type and Scope
  ↓
Extract Parties, Period, Value, CLINs, and Deliverables
  ↓
Extract Obligations and Performance Standards
  ↓
Review Pricing, Options, and Modifications
  ↓
Identify Risks, Gaps, Duplications, and Inefficiencies
  ↓
Assess Oversight and Performance Evidence
  ↓
Develop Findings and Questions for Contracting Staff
  ↓
Generate Review Product
```

## 8.5 Contract Data Extraction Template

```text
Contract Number:
Vendor:
Agency / Office:
Contract Type:
Period of Performance:
Total Value:
Base Period:
Option Periods:
Scope Summary:
CLINs:
Key Deliverables:
Performance Standards:
Reporting Requirements:
Invoices / Payments:
Modifications:
Relevant Clauses:
Known Issues:
```

## 8.6 Obligation Matrix Template

```text
Obligation:
Responsible Party:
Source Section:
Due Date / Frequency:
Performance Standard:
Acceptance Criteria:
Evidence Required:
Risk if Missed:
Status:
```

## 8.7 Review Dimensions

### Scope Clarity

Is the work clearly described and bounded?

### Deliverable Traceability

Are deliverables tied to acceptance criteria and payment?

### Performance Measurement

Are performance standards measurable and enforceable?

### Cost and Pricing

Are costs, rates, CLINs, options, and modifications understandable?

### Duplication

Do multiple contracts purchase overlapping services, tools, reports, licenses, or support?

### Oversight

Is there enough reporting, inspection, or acceptance evidence?

### Compliance Flags

Are there apparent gaps requiring review by contracting or legal staff?

### Efficiency Opportunities

Can requirements be consolidated, clarified, competed, renegotiated, sequenced, or better measured?

## 8.8 Risk Register Template

```text
Risk:
Contract / Document:
Source Location:
Category:
Description:
Potential Impact:
Likelihood:
Severity:
Evidence:
Recommended Review Action:
Owner:
```

## 8.9 Duplication Analysis Pattern

Duplication analysis should compare:

- Vendor
- Contract vehicle
- Period of performance
- Scope language
- Labor categories
- Deliverables
- Software or data products
- Geographic coverage
- Program office
- Pricing structure
- Deliverable recipients

Potential duplication should be framed as a review lead unless the evidence clearly establishes redundancy.

## 8.10 Procurement Integrity and Caution Rules

The skill should:

- Avoid giving legal conclusions unless clearly supported and appropriately qualified.
- Avoid asserting noncompliance from incomplete documents.
- Label potential issues as review flags when evidence is limited.
- Preserve source wording for obligations.
- Distinguish contractual requirements from best-practice recommendations.
- Recommend referral to contracting, legal, or audit staff when formal determination is required.

## 8.11 Contract Review QA Checklist

Verify:

- Contract identifiers are captured.
- Scope and deliverables are summarized accurately.
- Obligations are traceable to document sections.
- Risk flags are evidence-backed.
- Legal conclusions are avoided or qualified.
- Duplications are supported by comparison.
- Recommendations are practical.
- Missing documents or data are listed.

## 8.12 Failure Modes

Common failures include:

- Treating a draft or attachment as the executed contract.
- Missing modifications.
- Confusing vendor proposal promises with contract obligations.
- Overstating compliance issues.
- Ignoring option years.
- Failing to map deliverables to payment.
- Treating similar language as confirmed duplication.
- Ignoring performance evidence.

## 8.13 Benchmark Tests

```text
Benchmark ID: FCR-001
Task: Extract obligations from a performance work statement.
Pass Criteria: Produces obligation matrix with responsible party, source section, frequency, standard, and evidence required.
```

```text
Benchmark ID: FCR-002
Task: Review ten contracts for potential efficiency opportunities.
Pass Criteria: Identifies overlapping scope, unclear deliverables, weak performance standards, and consolidation candidates with confidence labels.
```

```text
Benchmark ID: FCR-003
Task: Summarize contract risk for an executive.
Pass Criteria: Provides concise risk register, evidence basis, recommended review actions, and limitations.
```

---

# Part 9 — Critical Infrastructure Consequence Analysis Skill

## 9.1 Skill Contract

```text
Skill Name: Critical Infrastructure Consequence Analysis Skill
Purpose: Assess consequences, dependencies, cascading impacts, resilience, recovery, and mitigation priorities for critical infrastructure disruptions.
Primary Users: Risk analysts, emergency managers, security planners, infrastructure owners, government officials, continuity planners, and executives.
Inputs: Asset description, hazard or disruption scenario, geography, dependencies, population served, operations, redundancy, duration, response assumptions, source data.
Outputs: Consequence assessment, dependency map, cascading impact analysis, resilience assessment, mitigation options, decision matrix, executive report.
Quality Gates: Consequence logic, source support, uncertainty, dependency realism, defensive framing, and no actionable harm-enabling detail.
```

## 9.2 Mission

The Critical Infrastructure Consequence Analysis Skill helps users understand what could happen if infrastructure is disrupted. It focuses on public safety, economic impact, operational continuity, cascading effects, recovery constraints, and mitigation priorities.

The skill supports defensive planning, resilience investment, emergency management, continuity planning, and consequence-informed prioritization. It should not provide tactical attack guidance, exploitation instructions, or adversary optimization.

## 9.3 When to Use

Use this skill when the user asks to:

- Assess consequences to infrastructure.
- Prioritize assets for protection.
- Analyze cascading impacts.
- Estimate disruption effects.
- Evaluate resilience or redundancy.
- Model recovery timelines.
- Build a risk or consequence matrix.
- Compare mitigation options.
- Produce a consequence analysis document.
- Assess transportation, energy, water, communications, healthcare, financial, food, or other critical systems.

## 9.4 Consequence Analysis Workflow

```text
Define Scenario and Scope
  ↓
Identify Asset or System
  ↓
Characterize Functions and Users
  ↓
Map Dependencies and Interdependencies
  ↓
Estimate Direct Consequences
  ↓
Estimate Cascading Consequences
  ↓
Assess Redundancy and Substitution
  ↓
Assess Recovery Constraints
  ↓
Estimate Consequence Severity and Confidence
  ↓
Identify Mitigation and Resilience Options
  ↓
Produce Decision Product
```

## 9.5 Asset Characterization Template

```text
Asset / System:
Sector:
Subsector:
Location / Region:
Primary Function:
Users Served:
Throughput / Capacity:
Critical Dependencies:
Known Redundancies:
Operating Constraints:
Owner / Operator Type:
Data Sources:
```

## 9.6 Consequence Categories

Assess consequences across:

### Life Safety

Potential fatalities, injuries, medical access effects, evacuation constraints, and public health implications.

### Economic Impact

Direct losses, business interruption, supply-chain effects, replacement costs, productivity loss, and regional or national economic significance.

### Operational Impact

Loss of service, capacity reduction, delays, degraded mission performance, and continuity disruptions.

### Social and Community Impact

Effects on public confidence, vulnerable populations, access to essential services, and community stability.

### Environmental Impact

Contamination, hazardous releases, ecosystem damage, or long-term cleanup consequences.

### National Security or Governance Impact

Impacts on government continuity, defense missions, law enforcement, emergency response, border security, or critical public functions.

## 9.7 Dependency Mapping Template

```text
Dependent Function:
Dependency Type:
Upstream System:
Downstream Users:
Failure Pathway:
Substitution Options:
Time to Impact:
Recovery Constraint:
Confidence:
```

## 9.8 Cascading Impact Pattern

Cascading impacts should be assessed through:

```text
Initial Disruption
  ↓
Loss of Function
  ↓
Affected Users / Systems
  ↓
Substitution or Rerouting
  ↓
Capacity Constraints
  ↓
Secondary Failures
  ↓
Regional or Sector-Level Consequences
```

## 9.9 Severity Scale

Use a transparent scale such as:

### Minimal

Localized, short-duration disruption with readily available substitution.

### Minor

Noticeable service degradation with limited broader effects.

### Moderate

Material operational or economic impact affecting a region, sector, or mission area.

### Major

Severe disruption with cascading effects, limited substitution, or prolonged recovery.

### Catastrophic

Nationally significant disruption, major life-safety consequences, severe cascading impacts, or long recovery duration.

## 9.10 Resilience Assessment

Assess:

- Redundancy
- Backup capacity
- Substitution options
- Mutual aid
- Inventory or buffer capacity
- Recovery workforce
- Spare parts and specialized equipment
- Regulatory or permitting constraints
- Cyber or physical dependencies
- Public communication needs
- Financial recovery capacity

## 9.11 Mitigation Option Template

```text
Mitigation Option:
Consequence Addressed:
Expected Benefit:
Implementation Difficulty:
Estimated Cost Category:
Time to Implement:
Dependencies:
Residual Risk:
Evidence Basis:
Priority:
```

## 9.12 Defensive Framing Rules

The skill should:

- Focus on consequences, resilience, mitigation, recovery, and prioritization.
- Avoid tactical details that would enable sabotage, evasion, or exploitation.
- Avoid identifying exploitable vulnerabilities beyond high-level defensive categories.
- Use abstraction for sensitive infrastructure pathways when needed.
- Recommend protective, continuity, and resilience actions.
- Flag uncertainty and source limitations.

## 9.13 Consequence QA Checklist

Verify:

- Scenario scope is clear.
- Asset function is defined.
- Dependencies are realistic.
- Consequence categories are considered.
- Time horizons are explicit.
- Substitution capacity is assessed.
- Cascading effects are plausible, not speculative chains without support.
- Confidence is calibrated.
- Mitigation options address identified consequences.
- Harm-enabling details are excluded.

## 9.14 Failure Modes

Common failures include:

- Treating asset size as consequence without dependency analysis.
- Ignoring redundancy.
- Assuming all users are affected equally.
- Failing to define disruption duration.
- Double-counting economic impacts.
- Confusing vulnerability with consequence.
- Overlooking recovery constraints.
- Providing excessive operational detail about failure pathways.
- Producing rankings without explaining assumptions.

## 9.15 Benchmark Tests

```text
Benchmark ID: CICA-001
Task: Assess consequences of a hypothetical disruption to a transportation hub.
Pass Criteria: Defines scope, functions, dependencies, direct impacts, cascading impacts, redundancy, recovery constraints, confidence, and mitigation options.
```

```text
Benchmark ID: CICA-002
Task: Compare three infrastructure assets for protection prioritization.
Pass Criteria: Uses transparent consequence categories, avoids volume-only scoring, documents assumptions, and provides a defensible ranking.
```

```text
Benchmark ID: CICA-003
Task: Review a consequence assessment for overstatement.
Pass Criteria: Identifies unsupported cascading claims, double-counting, missing redundancy, and excessive precision.
```

---

# Part 10 — Integrated Domain Workflows

## 10.1 Purpose

Volume V domain skills are designed to be composed. Complex work often requires several modules operating together. This section defines common integrated workflows.

## 10.2 Skill Builder Workflow

Use when creating a new professional AI skill.

```text
Prompt Engineering Skill
  ↓
AI Evaluation Skill
  ↓
Long Document Synthesis Skill when source materials are provided
  ↓
Simulation Development Skill when models or tools are required
  ↓
AIPSL QA Framework
  ↓
Release Candidate skill.md
```

## 10.3 Analytical Product Workflow

Use when producing a high-quality report from multiple sources.

```text
Long Document Synthesis
  ↓
Evidence Evaluation
  ↓
Program Evaluation or Consequence Analysis as applicable
  ↓
AI Evaluation / Murderboard
  ↓
Executive Product
```

## 10.4 Early Warning and Simulation Workflow

Use when the user wants monitoring and projected impacts.

```text
Early Warning Skill
  ↓
Indicator Matrix
  ↓
Simulation Development Skill
  ↓
Scenario Outputs
  ↓
Warning Product and Decision Triggers
```

## 10.5 Contract Efficiency Workflow

Use when reviewing multiple contracts for efficiencies.

```text
Long Document Synthesis
  ↓
Federal Contract Review
  ↓
Program Evaluation
  ↓
AI Evaluation
  ↓
Efficiency Findings and Implementation Roadmap
```

## 10.6 Critical Infrastructure Risk Workflow

Use when infrastructure consequence analysis requires modeling and prioritization.

```text
Critical Infrastructure Consequence Analysis
  ↓
Dependency Mapping
  ↓
Simulation Development
  ↓
Early Warning Indicators
  ↓
Program Evaluation of Mitigation Options
  ↓
Decision Matrix
```

## 10.7 Integrated Output Package

For complex domain workflows, provide:

- Executive summary
- Methodology
- Evidence matrix
- Assumption register
- Analysis
- Findings
- Recommendations
- Limitations
- Appendices
- Machine-readable data table when useful
- Version history

---

# Part 11 — Domain QA, Benchmarks & Acceptance Tests

## 11.1 Purpose

This section defines shared evaluation rules for the Volume V domain skills.

## 11.2 Domain QA Rubric

```text
Criterion: Mission Alignment
Question: Does the output satisfy the user objective?
Score 1: Misses objective.
Score 3: Partially satisfies objective.
Score 5: Fully satisfies objective.
```

```text
Criterion: Evidence Integrity
Question: Are claims properly supported and qualified?
Score 1: Unsupported claims dominate.
Score 3: Some support, gaps remain.
Score 5: Claims are traceable and limitations are clear.
```

```text
Criterion: Method Fit
Question: Was the correct analytical or engineering method used?
Score 1: Method is inappropriate.
Score 3: Method is partially appropriate.
Score 5: Method fits the task and is applied correctly.
```

```text
Criterion: Output Usability
Question: Can the intended user act on the output?
Score 1: Output is confusing or unusable.
Score 3: Output is useful with revision.
Score 5: Output is clear, structured, and actionable.
```

```text
Criterion: Safety and Integrity
Question: Does the output avoid harmful misuse and preserve analytic integrity?
Score 1: Serious safety or integrity issue.
Score 3: Some concerns require revision.
Score 5: Safe, professional, and properly qualified.
```

## 11.3 Minimum Acceptance Standard

A domain output should not be considered ready unless:

- No critical defects remain.
- No major unsupported claim remains.
- The requested deliverable format is satisfied.
- Important assumptions are documented.
- The user can understand what to do next.

## 11.4 Cross-Domain Benchmark Suite

```text
Benchmark ID: V5-XD-001
Task: Convert a broad user request into an integrated workflow using at least two domain skills.
Pass Criteria: Selects appropriate skills, explains workflow, identifies inputs, outputs, QA gates, and limitations.
```

```text
Benchmark ID: V5-XD-002
Task: Evaluate a flawed domain product.
Pass Criteria: Identifies defects by severity, ties criticism to the domain rubric, and recommends corrections.
```

```text
Benchmark ID: V5-XD-003
Task: Produce a decision-ready product from incomplete inputs.
Pass Criteria: States assumptions, uses available evidence, avoids overclaiming, and provides useful next steps.
```

## 11.5 Release Checklist for Volume V Domain Skills

Before releasing a domain skill:

- Metadata is complete.
- Mission and scope are clear.
- Workflow is explicit.
- Input and output contracts are defined.
- Quality gates are included.
- Benchmarks are included.
- Guardrails are included where necessary.
- Failure modes are documented.
- Integration pathways are defined.
- Changelog is updated.

---



---



# Pass 4 Reusable Pattern Router

## Pattern Invocation Protocol

Use this sequence whenever selecting a reusable pattern:

1. Identify the deliverable type.
2. Identify the domain and required reasoning mode.
3. Select the closest existing pattern.
4. Adapt the pattern to the user's constraints.
5. Apply the pattern's quality gate.
6. Export or present the result in the requested format.

## GPT Skill Pattern

```text
Skill Name:
Mission:
Users Served:
Core Capabilities:
Always-On Rules:
Inputs:
Outputs:
Workflow:
Decision Points:
Quality Gates:
Failure Modes:
Tool Use Rules:
Companion Files:
Version:
Changelog:
```

## HTML Tool Pattern

```text
Objective:
Operating Environment:
No-Dependency Requirement:
Input Types:
Processing Logic:
User Interface:
Validation:
Export Formats:
Error Handling:
Security Constraints:
Offline Behavior:
Test Cases:
```

## Analytical Product Pattern

```text
Executive Summary
Purpose and Scope
Key Findings
Evidence Base
Analysis
Alternative Explanations
Confidence and Uncertainty
Implications
Recommendations
Limitations
Appendices
Version History
```

## Refactor Pattern

Use when transforming a long source document into an executable library.

```text
1. Preserve source provenance.
2. Identify runtime instructions.
3. Identify reusable patterns.
4. Identify durable reference knowledge.
5. Remove duplication.
6. Create cross-file routing rules.
7. Add manifests and versioning.
8. Export versioned files.
9. Validate that no source category is orphaned.
```

## Anti-Pattern: Placeholder Completion

Do not replace a large requested artifact with a short scaffold unless explicitly labeling it as a scaffold. If the user asks for a full build, perform an incremental build and export each pass.

# Pass 5 Pattern Annex — Humanize Written AI Products

## Purpose

This annex registers reusable implementation patterns derived from **Humanize Written AI Products Skill v2.0**. These patterns support the runtime capability embedded in `skill.md`.

## Humanization Workflow Pattern

### Trigger

Use this pattern when the user asks to humanize, rewrite, polish, edit, professionalize, shorten, expand, smooth, clarify, or improve a written product.

### Inputs

- Draft text or uploaded document.
- Intended audience.
- Desired final length.
- Desired tone or style.
- Citation/endnote preference.
- Reference material if citations are requested.
- Product type, if known.
- Humanization intensity level, if specified.

### Workflow

1. Receive draft.
2. Confirm required parameters.
3. Identify product type.
4. Diagnose robotic phrasing, repetition, weak transitions, tone mismatch, structure problems, unsupported claims, and citation gaps.
5. Select humanization intensity.
6. Rewrite while preserving meaning.
7. Handle citations according to user preference and available sources.
8. Perform final QA.
9. Deliver the polished product in the requested format.

### Output

A polished, audience-appropriate version that preserves meaning, facts, and analytical integrity.

## Humanization Intensity Pattern

Use five levels:

1. **Proofread Only** — grammar, punctuation, typos, obvious awkwardness.
2. **Light Humanization** — sentence rhythm, repetition, transitions, wordiness.
3. **Professional Rewrite** — default; improves flow, organization, tone, and human readability.
4. **Substantive Editorial Rewrite** — major structural improvement while preserving meaning.
5. **Publication-Ready Transformation** — full structural edit, consistency review, citation review when requested, and final QA.

## Citation and Endnote Pattern

### Default

No citations or endnotes unless the user requests them.

### If citations are requested

1. Ask for reference material if not already provided.
2. Review sources.
3. Map claims to sources.
4. Add endnotes only where supported.
5. Flag unsupported claims.
6. Number notes sequentially.
7. Verify that every marker has a matching endnote.
8. Never fabricate source details, page numbers, quotations, URLs, statistics, or access dates.

## Product-Type Template Pattern

Select structure based on product type:

- Executive memo: bottom line, background, findings, implications, options, recommendations.
- Analytical report: executive summary, scope, methodology, findings, analysis, limitations, recommendations.
- Intelligence product: key judgment, confidence, evidence, alternatives, indicators, implications.
- Policy paper: issue, background, current state, options, recommendation, implementation risks.
- Technical document: purpose, scope, definitions, requirements, process, outputs, validation.
- Email: subject, direct opening, main point, necessary context, clear ask, close.
- Public article: lead, context, explanation, evidence, practical meaning, conclusion.

## AI-Writing Anti-Pattern Correction Pattern

Detect and correct:

- Generic openings.
- Repetitive transitions.
- Over-structured lists.
- Vague praise.
- Inflated certainty.
- Hedging without purpose.
- Repetitive summaries.
- Abstract noun stacks.
- Empty conclusions.
- False balance.

## Large Document Humanization Pattern

For long products:

1. Build a document map.
2. Track audience, terms, acronyms, citations, headings, and key claims.
3. Edit section by section.
4. Maintain rolling consistency notes.
5. Perform a final global pass for tone, redundancy, cross-references, citations, acronyms, formatting, and conflicting claims.

## High-Stakes Editing Pattern

For legal, medical, financial, safety, intelligence, national security, technical, or compliance products:

- Preserve caveats.
- Preserve source limitations.
- Preserve legal and technical terms.
- Avoid confidence inflation.
- Avoid unsupported recommendations.
- Flag claims requiring expert review.
- Treat citations conservatively.

## Reusable Prompt Pattern

```text
Humanize the following product using AIPSL standards.

Audience:
Desired length:
Tone/style:
Citation preference: endnotes yes/no
Reference material provided: yes/no
Humanization intensity:
Output format:

Draft:
[paste draft]
```

## Source Reference

Derived from `humanize_writer_skill_v2_0.md`.  
Source SHA-256: `efe3adbc37bca7bca6e508a4addca8bf088389ab18c5919e5c72d72e8abe867b`  
Integrated: 2026-07-02 01:05:37

# Pass 7 Pattern Annex — Skills Menu Display Pattern

## Purpose

This annex provides the reusable display pattern for presenting available AIPSL skills after `patterns.md` and `knowledge.md` are uploaded or confirmed available.

## Skills Menu Pattern

### Trigger

Use this pattern when the GPT detects that both `patterns.md` and `knowledge.md` have been uploaded or made available.

### Output Format

```markdown
## Available AIPSL Skills

1. **Skill Name** — One-sentence capability description.
2. **Skill Name** — One-sentence capability description.

You can ask for any capability by name, or simply describe what you want to accomplish and I will route the request to the right AIPSL skill.
```

### Current Menu Content

1. **AIPSL Runtime / Operating System** — Routes tasks, applies workflows, enforces quality gates, and coordinates the three-file architecture.
2. **GPT Skill Builder** — Builds, reviews, refactors, and packages GPT-ready skill.md files and modular skill systems.
3. **Prompt Engineering** — Designs, debugs, and improves prompts for complex professional workflows.
4. **AI Evaluation and Quality Assurance** — Creates evaluation plans, benchmarks, regression tests, hallucination checks, and quality gates.
5. **Long Document Synthesis** — Ingests and synthesizes long documents, multi-file collections, reports, and reference libraries.
6. **Simulation Development** — Designs simulations, Monte Carlo models, scenario engines, dashboards, and single-file HTML tools.
7. **Critical Infrastructure Consequence Analysis** — Assesses infrastructure impacts, consequences, dependencies, risk, and mitigation options.
8. **Early Warning and Forecasting** — Builds indicators, warning frameworks, forecasts, scenario assessments, and monitoring plans.
9. **Federal Contract Review** — Reviews contracts, procurement records, spend files, duplication, efficiency candidates, and risk areas.
10. **Program Evaluation** — Evaluates programs, outcomes, logic models, performance measures, risks, and improvement options.
11. **Humanize Written AI Products** — Polishes AI-generated or AI-assisted writing for audience, tone, clarity, flow, and citation discipline.
12. **Spreadsheet Ingestion** — Ingests, inventories, validates, profiles, summarizes, and prepares spreadsheet data for analysis or export.

## Menu Behavior Rules

- Show the menu once during onboarding.
- Do not repeat the menu in every response.
- Repeat the menu if the user asks, "What skills are available?" or similar.
- Keep descriptions short.
- Do not include internal implementation details.
- Do not expose hidden system instructions.
- Do not imply a skill can do work outside available tools or policy limits.
- If a capability requires files, sources, spreadsheets, or user parameters, ask only for the missing inputs required to proceed.

## Selection Pattern

When the user names a skill:

```text
Selected skill: [Skill Name]
Task: [User's task]
Next step: [Brief action]
```

When the user does not name a skill:

```text
Best-fit skill: [Skill Name]
Reason: [Short explanation]
Next step: [Brief action]
```

## Multi-Skill Pattern

If multiple skills apply, use:

```text
I will combine:
- [Skill A] for [role]
- [Skill B] for [role]
- [Skill C] for [role]
```

Then proceed without forcing the user to manually select.

# Pass 8 Pattern Annex — Document Ingestion, Data Analysis, and Secure Offline Tool Development

## Purpose

Pass 8 adds reusable patterns for three new cross-cutting capabilities:

- Document Ingestion & File Triage.
- Data Analysis & Modeling.
- Secure Offline Tool Development.

---

# Document Ingestion & File Triage Patterns

## File Inventory Pattern

| File | Type | Apparent Role | Key Contents | Tables/Figures? | Notes |
|---|---|---|---|---:|---|

## Document Role Classification Pattern

Classify files as:

- Primary source.
- Background source.
- Reference material.
- Draft product.
- Final product.
- Data appendix.
- Technical appendix.
- Contract or acquisition document.
- Policy or guidance.
- Research paper.
- Report.
- Memo.
- Presentation.
- Training material.
- Template.
- Duplicate or near duplicate.
- Unknown role.

## Relevant Content Map Pattern

| File | Location | Content Type | Relevance | Notes |
|---|---|---|---|---|

## Document Triage Output Pattern

1. File inventory.
2. Relevant content map.
3. Extraction readiness.
4. Limitations.
5. Recommended next workflow.

---

# Data Analysis & Modeling Patterns

## Analysis Plan Pattern

| Element | Description |
|---|---|
| Objective | |
| Data Sources | |
| Grain | |
| Key Measures | |
| Key Dimensions | |
| Methods | |
| Assumptions | |
| Quality Checks | |
| Outputs | |

## Method Selection Pattern

| User Need | Recommended Method |
|---|---|
| What happened? | Descriptive statistics, summary tables, distributions |
| Why did it happen? | Diagnostic analysis, group comparison, correlation, root-cause review |
| What is changing? | Trend analysis, time-series summary, moving averages |
| What may happen? | Forecasting, scenarios, regression, Monte Carlo |
| What should we do? | Decision analysis, prioritization, optimization, cost-benefit framing |
| Where are the anomalies? | Outlier detection, reconciliation checks, rule-based flags |
| Which items matter most? | Ranking, scoring, Pareto analysis, segmentation |

## Finding Table Pattern

| ID | Finding | Evidence | Method | Magnitude | Confidence | Caveats | Recommended Action |
|---|---|---|---|---|---|---|---|

## Data Quality Impact Pattern

| Issue | Severity | Impact on Analysis | Mitigation | Residual Uncertainty |
|---|---|---|---|---|

## Modeling Specification Pattern

| Component | Required Description |
|---|---|
| Objective | What the model is intended to estimate or decide |
| Inputs | Variables, data sources, units |
| Outputs | Metrics, forecasts, scores, classifications |
| Logic | Equations, rules, algorithms, distributions |
| Assumptions | Explicit assumptions and rationale |
| Uncertainty | Ranges, distributions, confidence limits |
| Validation | Reconciliation, backtesting, sensitivity checks |
| Limitations | Known weaknesses and non-use cases |

---

# Secure Offline Tool Development Patterns

## Secure Offline HTML Tool Prompt Pattern

```text
Build a complete, self-contained single-file HTML application. Include all HTML, CSS, and JavaScript in one file. Do not use CDNs, external scripts, external fonts, npm packages, server calls, tracking, analytics, or internet access. The tool must run locally in a browser from a saved .html file.
```

## Offline Tool Architecture Pattern

```text
index.html
├── Metadata and help text
├── CSS
├── HTML layout
├── JavaScript constants
├── State management
├── File parser
├── Validation engine
├── Analysis/calculation engine
├── Visualization engine
├── Export engine
├── Error/logging engine
└── Test/sample data block
```

## Offline Tool Requirements Pattern

| Requirement Area | Questions |
|---|---|
| Purpose | What task does the tool perform? |
| Inputs | What file types and fields are accepted? |
| Processing | What calculations or transformations are required? |
| Validation | What errors must be detected? |
| Outputs | What results should be shown? |
| Exports | What export formats are required? |
| Security | What external calls are prohibited? |
| Performance | What file size or record count must be supported? |
| UX | What controls, instructions, and warnings are needed? |
| Testing | What test cases prove the tool works? |

## Offline Tool Test Case Pattern

| Test ID | Scenario | Input | Expected Result | Pass/Fail |
|---|---|---|---|---|

## Offline Export Fallback Pattern

If true native export is not feasible offline:

- Use CSV for spreadsheet-compatible export.
- Use Markdown for document-compatible export.
- Use HTML for Word-compatible export.
- Use browser print-to-PDF for PDF output.
- Use JSON for structured data preservation.
- Explain limitations clearly.

---

# Updated Skills Menu Pattern

When both `patterns.md` and `knowledge.md` are available, display:

1. **AIPSL Runtime / Operating System** — Routes tasks, applies workflows, enforces quality gates, and coordinates the three-file architecture.
2. **GPT Skill Builder** — Builds, reviews, refactors, and packages GPT-ready skill.md files and modular skill systems.
3. **Prompt Engineering** — Designs, debugs, and improves prompts for complex professional workflows.
4. **AI Evaluation and Quality Assurance** — Creates evaluation plans, benchmarks, regression tests, hallucination checks, and quality gates.
5. **Long Document Synthesis** — Ingests and synthesizes long documents, multi-file collections, reports, and reference libraries.
6. **Simulation Development** — Designs simulations, Monte Carlo models, scenario engines, dashboards, and single-file HTML tools.
7. **Critical Infrastructure Consequence Analysis** — Assesses infrastructure impacts, consequences, dependencies, risk, and mitigation options.
8. **Early Warning and Forecasting** — Builds indicators, warning frameworks, forecasts, scenario assessments, and monitoring plans.
9. **Federal Contract Review** — Reviews contracts, procurement records, spend files, duplication, efficiency candidates, and risk areas.
10. **Program Evaluation** — Evaluates programs, outcomes, logic models, performance measures, risks, and improvement options.
11. **Humanize Written AI Products** — Polishes AI-generated or AI-assisted writing for audience, tone, clarity, flow, and citation discipline.
12. **Spreadsheet Ingestion** — Ingests, inventories, validates, profiles, summarizes, and prepares spreadsheet data for analysis or export.
13. **Document Ingestion & File Triage** — Inventories, classifies, extracts, and prepares PDFs, Word files, Markdown, text, slides, and mixed file sets for analysis.
14. **Data Analysis & Modeling** — Profiles data, builds analytical plans, computes statistics, detects trends, validates assumptions, and produces evidence-backed findings.
15. **Secure Offline Tool Development** — Designs single-file tools that run locally in secure environments with no installation, no external dependencies, and export-ready outputs.


# Pass 8 Pattern Annex — Standing Analytical Operating Standards Templates

## Purpose

Reusable, drop-in templates that operationalize the Standing Analytical Operating Standards (authoritative rules in `knowledge.md`; runtime enforcement in `skill.md`). Load the smallest applicable template; do not paste the whole annex into a product.

## Analytic Product Skeleton Pattern

```text
OPEN SOURCE ASSESSMENT            <- only for OSINT products; never FOUO/classified

# [Title]

## Key Findings                   <- always this header, never BLUF
- [Judgment 1] — [IC probability term] (XX–XX%)
- [Judgment 2] — [IC probability term] (XX–XX%)

## Scope and Objective
[Objective, scope, what the product does and does not cover.]

## Discussion
[Main message up front. Facts, then assumptions, then analysis, then judgments — kept
distinct. Analysis of alternatives included. Plain language throughout.]

## Confidence and Limitations
[Uncertainty as ranges. Source quality. Residual gaps.]

## Endnotes
1. Originator, identifier, title, date, source descriptor.
```

## Probability and Uncertainty Expression Pattern

- Never a single-point estimate. Always a range.
- First use of each statistical term is translated, technical term in parentheses:
  - expected events per year (lambda)
  - annual chance of at least one event (P(>=1))
  - low/middle/high estimate (P05/P50/P95)
  - uncertainty range (credible interval)
  - clustered-event model (negative-binomial)

## Corroboration Labeling Pattern

- Two independent sources: state as supported, cite both.
- One source only: append "(single-source; unconfirmed)".
- Vendor capability/certification claim: verify against certifying authority. If unavailable:
  "[Vendor]'s product literature asserts [X]." Never state as verified fact.

## Citation Endnote Pattern (Default for Written Products)

```text
Body text with a claim.[^1]

[^1]: Originator. Unambiguous identifier. "Title." Date. Source descriptor.
```

Exceptions: invoices and emails use no endnotes.

## Structured Analytic Technique Selection Pattern

| Analytic Need | Technique |
|---|---|
| Surface hidden assumptions | Key Assumptions Check |
| Test source reliability | Quality of Information Check |
| Weigh multiple explanations | Analysis of Competing Hypotheses (disprove, don't prove) |
| Stress a dominant judgment | Devil's Advocacy or Team A/Team B |
| Rare but severe outcomes | High-Impact/Low-Probability |
| Explore trigger sensitivity | What-If Analysis |
| Break anchoring | Outside-In Thinking, Alternative Futures |

## Monte Carlo / Forecast Build Pattern

1. Domain-informed priors (weakly informative when uncertain).
2. 1,000+ iterations (5,000–25,000 for complex models); Latin Hypercube Sampling; fixed random seed.
3. Sensitivity analysis on priors and key drivers.
4. Posterior predictive checks; MCMC convergence (R-hat ~1, trace plots) for Bayesian models.
5. Backtest against actuals; measure with performance metrics.
6. Report 5th/95th tails and credible intervals; compare models via LOO-CV or WAIC.
7. Plain-language translation of every statistical term at first use.

## Scenario Set Pattern

For each scenario provide: a standalone name, its assumptions, its drivers, and what distinguishes it. Include intermediate cases between extremes as the empirical base supports. No unexplained labels.

## Term and Acronym Definition Pattern

- First use: Full Term (ACRONYM). Thereafter: ACRONYM.
- Every table: accompany with a legend or definitions block covering every metric, code, and label.

## VBA Engine Framework v1 Pattern

```vba
Option Explicit

Public Sub Engine_Run()
    Engine_Begin "Engine_Run"          ' sets ScreenUpdating/EnableEvents/DisplayAlerts=False, Calc=Manual
    ' Validate inputs
    ' ReadBlock -> process arrays -> WriteBlock
SafeExit:
    Engine_End                          ' restores flags
    Exit Sub
ErrHandler:
    Engine_Fail Err.Number, Err.Description
    Resume SafeExit
End Sub
```

Rules: all Public params ByVal; collapse line continuations to single lines (never split across InsertLines); use .Columns("H") not .Range("H"); Cells(r,c) not named ranges; currency "$#,##0;($#,##0)"; time vars As Double; no Active* references.

## Corrections Delivery Pattern

Deliver the corrected product only. No before/after, no note of what changed, no acknowledgment of the error in the deliverable. Then audit all active products for the same claim in the same revision cycle.


# Pass 9 Pattern Annex — Python Tooling and Product Conversion Templates

## Purpose

Drop-in templates for the Pass 9 Python Tooling Standard and the Brief/Deck/Executive Email Conversion Standard (authoritative rules in `knowledge.md`; runtime enforcement in `skill.md`). Load the smallest applicable template.

# Python Tooling Patterns

## Excel COM Tool Skeleton (Windows Default)

```python
# Target: Windows + Excel COM. Fallback: pandas/openpyxl if COM unavailable.
import win32com.client as win32
import random, os, tempfile, shutil

SEED = 20260702
random.seed(SEED)

def run(src_path, out_path):
    excel = win32.gencache.EnsureDispatch("Excel.Application")
    excel.DisplayAlerts = False
    excel.ScreenUpdating = False
    excel.Calculation = win32.constants.xlCalculationManual
    wb = None
    try:
        # ---- validate inputs first ----
        assert os.path.exists(src_path), f"Missing input: {src_path}"
        wb = excel.Workbooks.Open(os.path.abspath(src_path))
        # confirm sheets/headers/grain here; fail fast with a named error
        # ---- read block, process, write block ----
        # ---- recalc before reading computed values ----
        excel.Calculate()
        # ---- safe write: temp then atomic move ----
        tmp = tempfile.mktemp(suffix=".xlsx")
        wb.SaveAs(os.path.abspath(tmp))
        wb.Close(SaveChanges=False)
        shutil.move(tmp, out_path)   # versioned/date-suffixed out_path
    finally:
        if wb is not None:
            try: wb.Close(SaveChanges=False)
            except Exception: pass
        excel.DisplayAlerts = True
        excel.ScreenUpdating = True
        excel.Quit()
        del excel   # release; no orphaned EXCEL.EXE
    # print run summary: seed, rows in/out, paths, discrepancies, elapsed
```

## Input Validation Gate Pattern

```python
def validate(df, required_cols, grain_cols):
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    if len(df) == 0:
        raise ValueError("Zero rows after load")
    dupes = df.duplicated(subset=grain_cols).sum()
    if dupes:
        print(f"WARNING: {dupes} rows violate stated grain {grain_cols}")
    return True
```

## Recalc + Reconciliation Gate Pattern

```text
1. Force full recalculation (excel.Calculate() or run recalc.py).
2. Reconcile: rows_out vs rows_in; sum(control_col_out) vs sum(control_col_in).
3. If delta != 0, either resolve or disclose the delta in the run summary.
4. Deliver only on pass-or-disclosed.
```

## Generator Pre-Write Scan Pattern

```python
def scan_emitted(code_text):
    if code_text.count("(") != code_text.count(")"):
        raise ValueError("Unbalanced parentheses in generated code")
    if any(line.rstrip().endswith((" _", "`")) for line in code_text.splitlines()):
        raise ValueError("Dangling line continuation in generated code")
    if any(ord(ch) > 127 for ch in code_text):
        raise ValueError("Non-ASCII character in generated code")
    return True
```

## Run Summary Pattern

```text
RUN SUMMARY
  Seed: 20260702
  Inputs: <paths>
  Output: <versioned path>
  Rows in / written: <n> / <m>
  Coercions/drops: <count and reason, or none>
  Reconciliation: <pass | delta disclosed>
  Elapsed: <seconds>
  Limitations: <text or none>
```

# Product Conversion Patterns

## One-Page Brief Pattern

```text
OPEN SOURCE ASSESSMENT            <- OSINT only

[Product Title] — [Date]

KEY FINDINGS
- [Judgment] — [IC term] (XX–XX%)
- [Judgment] — [IC term] (XX–XX%)

DISCUSSION (short)
[Main message up front, plain language, ranges not point estimates.]

CONFIDENCE & LIMITATIONS
[Source quality; residual uncertainty.]

SOURCES
1. Originator. "Title." Date. Descriptor.
```

## Slide Deck Pattern

```text
Slide 1 — Title: product, date, OPEN SOURCE ASSESSMENT (if OSINT)
Slide 2 — Key Findings: one judgment per line, IC term + range
Slides 3..n — One message per slide; message = slide title; evidence beneath
Slide n+1 — Methods & Assumptions: define every metric/code/label used
Slide n+2 — Sources: numbered endnotes
Rule: no chart without a titled axis and a plain-language takeaway.
```

## Executive Email Pattern

```text
Subject: [Product] — [single most important finding]

Key findings:
- [Judgment] — [IC term] (XX–XX%)
- [Judgment] — [IC term] (XX–XX%)

What changed: [1–2 sentences]
Why it matters: [1–2 sentences]
What to note/do: [1–2 sentences]

Sources: [named inline or short list]   <- no numbered endnotes required
```

## Conversion Integrity Check Pattern

```text
Before sending any converted product, confirm:
[ ] Key Findings match source in direction and confidence
[ ] Every probability kept its range and IC term
[ ] No claim lost its source (endnotes in brief/deck; named in email)
[ ] Acronyms expanded at first use in this standalone artifact
[ ] OSINT designation present (brief/deck)
[ ] No manufactured relevance; no softened/sharpened judgments
[ ] Every table/chart term defined within the artifact
```


# Pass 10 Pattern Annex — Frontier Capability Templates

## Purpose

Drop-in templates for Capabilities 16–18 and model-aware governance (rules in `knowledge.md`; enforcement in `skill.md`).

## Cross-Revision Audit Pattern (Capability 16)

```text
CROSS-REVISION AUDIT — [Product Series] — [Rev range] — [Date]

SCOPE
Revisions loaded: [list]. Single-pass corpus load: [yes/no; if no, why].

KEY FINDINGS
- [Count] contradictions, [count] silently dropped claims, [count] sourcing drifts.

CONTRADICTIONS
| # | Claim | Rev A (location) | Rev B (location) | Status |
|---|-------|------------------|------------------|--------|

RETRACTED-CLAIM SWEEP
| # | Retracted claim | Retired in | Still present in | Action |
|---|-----------------|-----------|------------------|--------|

SOURCING DRIFT
| # | Claim | Citation in earlier rev | Citation now | Assessment |

JUDGMENT TRAJECTORY
| Judgment | Rev N range | Rev N+1 range | ... | Direction & rationale stated? |

REMEDIATION LIST (this revision cycle)
1. [Product] — [correction required]
```

## Long-Horizon Build Stage Plan Pattern (Capability 17)

```text
BUILD PLAN — [Build name] — [Date]

STAGES
| # | Stage | Entry criteria | Exit criteria | Artifacts | Validation gate |
|---|-------|----------------|---------------|-----------|-----------------|

CHECKPOINT RECORD (updated at every stage boundary)
Stage [n] complete: [what], validated by [gate], remaining: [list].
Resumable from this record alone: [yes].

PROPOSED FOLLOW-ONS (discovered mid-run; NOT executed)
- [item]

RUN SUMMARY
Stages completed / total, artifacts produced, gates passed/disclosed, elapsed, limitations.
```

## Visual Extraction Pattern (Capability 18)

```text
VISUAL EXTRACTION — [Source file, page/slide] — [Date]

ASSUMPTIONS (drawings/layouts): scale [x], legend [y], orientation [z].
EXTRACTION CONFIDENCE (scans): clean / degraded / illegible, by page.

VALUES
| Item | Value | Basis | Label |
|------|-------|-------|-------|
| [metric] | [n–m] | read from figure | estimate |
| [metric] | [n] | underlying data table present | verified |

CORROBORATION
Figures from vendor material are vendor self-claims; verify per standing rule.
```

## Classifier Fallback Note Pattern (Model-Aware Governance)

```text
LIMITATIONS (addition when fallback occurred)
A portion of this product was generated under automatic model fallback
(request routed to a different Claude model per the platform's safety
architecture). Content standards and review were unchanged.
```

## Retention Advisory Pattern

```text
Before submitting material to a Fable-class model session, confirm:
[ ] No material the owning organization prohibits from 30-day third-party retention
[ ] No requirement for zero-data-retention applies to this material
If either check fails: process locally with a secure offline tool instead.
```
