# AIPSL Pass 10 Capability Expansion Manifest

**Generated:** 2026-07-02  
**Pass:** 10  
**Package version:** 2.0.0-pass10-frontier-capability  
**Update:** Added the Frontier Model Capability Layer (Fable-class): Corpus-Scale Analysis & Cross-Revision Audit, Long-Horizon Autonomous Build, Visual Document Analysis, and Model-Aware Governance — on top of the Pass 9 standards set. Menu expands from 15 to 18 skills.

## Three-File Architecture

| Architecture File | Install Filename | Role |
|---|---|---|
| Runtime / Operating System | skill.md | Execution behavior, routing, always-on rules, quality gates |
| Pattern Library | patterns.md | Reusable workflows, templates, drop-in skeletons |
| Knowledge Base | knowledge.md | Authoritative governance, standards, registries, changelogs |

The install-folder files (`skill.md`, `patterns.md`, `knowledge.md`) carry the correct install filenames. The top-level `AIPSL_*_pass10_capability_expansion.md` files are byte-identical copies for reference.

## Source Lineage

| Pass | Source Package |
|---|---|
| 7 | AIPSL Pass 7 Skills Menu (retained in `Pass7_Source/`) |
| 8 | AIPSL Pass 8 Capability Expansion |
| 9 | AIPSL Pass 9 Capability Expansion (standards layers) |
| 10 | This package (built on the Pass 9 base) |

## User-Facing Skills Menu (18)

1. **AIPSL Runtime / Operating System** — Routes tasks, applies workflows, enforces quality gates, coordinates the three-file architecture.
2. **GPT Skill Builder** — Builds, reviews, refactors, and packages GPT-ready skill.md files and modular skill systems.
3. **Prompt Engineering** — Designs, debugs, and improves prompts for complex professional workflows.
4. **AI Evaluation and Quality Assurance** — Creates evaluation plans, benchmarks, regression tests, hallucination checks, and quality gates.
5. **Long Document Synthesis** — Ingests and synthesizes long documents, multi-file collections, reports, and reference libraries.
6. **Simulation Development** — Designs simulations, Monte Carlo models, scenario engines, dashboards, and single-file HTML tools.
7. **Critical Infrastructure Consequence Analysis** — Assesses infrastructure impacts, consequences, dependencies, risk, and mitigation options.
8. **Early Warning and Forecasting** — Builds indicators, warning frameworks, forecasts, scenario assessments, and monitoring plans.
9. **Federal Contract Review** — Reviews contracts, procurement records, spend files, duplication, efficiency candidates, and risk areas.
10. **Program Evaluation** — Evaluates programs, outcomes, logic models, performance measures, risks, and improvement options.
11. **Humanize Written AI Products** — Polishes AI-generated or AI-assisted writing for audience, tone, clarity, flow, and citation discipline.
12. **Spreadsheet Ingestion** — Ingests, inventories, validates, profiles, summarizes, and prepares spreadsheet data for analysis or export.
13. **Document Ingestion & File Triage** — Inventories, classifies, extracts, and prepares PDFs, Word files, Markdown, text, slides, and mixed file sets for analysis.
14. **Data Analysis & Modeling** — Profiles data, builds analytical plans, computes statistics, detects trends, validates assumptions, and produces evidence-backed findings.
15. **Secure Offline Tool Development** — Designs single-file tools that run locally in secure environments with no installation, no external dependencies, and export-ready outputs.
16. **Corpus-Scale Analysis & Cross-Revision Audit** — Loads an entire product series in one pass and audits cross-revision consistency, retracted claims, sourcing drift, and judgment trajectories.
17. **Long-Horizon Autonomous Build** — Executes large multi-stage builds as one sustained run with staged checkpoints, validation gates, and a resumable record.
18. **Visual Document Analysis** — Extracts and analyzes diagrams, layouts, scanned documents, embedded charts, and photographs under estimate-labeling and corroboration rules.

## Pass 10 Additions

### Frontier Model Capability Layer (Fable-class)
- Attributed capability profile per the vendor self-claim rule (Anthropic newsroom June 9 and June 30, 2026; Claude Platform documentation; AWS News Blog July 1, 2026): 1M-token context / 128k output, sustained long-horizon and asynchronous execution, analytics benchmark claims, tool generalization, vision, classifier fallback architecture, 30-day retention with no zero-data-retention, summarized-only reasoning.
- **Capability 16 — Corpus-Scale Analysis & Cross-Revision Audit:** whole-series single-pass audits producing contradiction tables, retracted-claim sweeps, sourcing-drift reports, judgment trajectories, and a remediation list enforcing the Cross-Product Accuracy Standard.
- **Capability 17 — Long-Horizon Autonomous Build:** staged builds with entry/exit criteria, checkpoint records resumable in isolation, validation gates between stages, scope control via proposed-follow-on lists.
- **Capability 18 — Visual Document Analysis:** figure reads labeled as estimates with ranges, drawing assumptions stated first, scan-confidence reporting, vendor-figure self-claim treatment.
- **Model-Aware Governance:** classifier-fallback limitation notes (never evade classifiers), 30-day-retention submission advisory, deliverables carry their own justification since raw reasoning traces are unavailable as audit records.
- Placement: knowledge.md (rules + attributed profile + annex sources), skill.md (menu extension 16–18, always-on rules, routing, quality gate), patterns.md (audit, stage-plan, visual-extraction, fallback-note, retention-advisory templates).

## Pass 9 Additions (prior pass)

### Standing Analytical Operating Standards (always-on across all products)
- knowledge.md — authoritative rules: clarify-when-unsure, authentic-sources-only, sourcing discipline (banned sources, primary-only, permitted institutional blogs), corroboration + vendor self-claim, cross-product accuracy, ICD-203, ICD-206, OMB Risk Bulletin, Structured Analytic Techniques, Brier scoring, Bayesian estimation, Monte Carlo, quantitative forecasting, plain-language translation, scenario labeling, term definition, numbered-endnote citations, Key Findings header, open-source designation, analytical integrity, corrections handling, VBA Engine Framework v1 / Excel / CFB best practices, plus a Standing Standards QA Checklist.
- skill.md — runtime enforcement layer (always-on rules, routing table, quality gate).
- patterns.md — drop-in templates (analytic skeleton, uncertainty expression, corroboration labeling, endnote pattern, SAT selection, Monte Carlo build, scenario set, VBA framework, corrections delivery).

### Python Tooling Standard (companion to the VBA standards)
- Default target: Windows + PowerShell + Excel COM; fallback pandas/openpyxl.
- Covers determinism/seeding, input validation with data-grain confirmation, COM discipline (try/finally, no orphaned EXCEL.EXE, explicit recalc), recalculation and row-count/control-total reconciliation gates, safe file writes (temp-then-atomic-move, versioned names, sources untouched), generator pre-write scans, logging, and completion criteria.
- Placement: knowledge.md (rules), skill.md (runtime + routing), patterns.md (COM skeleton, validation gate, reconciliation gate, emitted-code scanner, run summary).

### Brief, Deck, and Executive Email Conversion Standard
- Compression-without-distortion rule plus preservation requirements (Key Findings lead, uncertainty ranges and IC terms retained, source traceability, acronym expansion, OSINT designation).
- Per-format standards for the one-page brief, slide deck, and executive email (email retains the numbered-endnote exemption), with a Conversion QA Checklist.
- Placement: knowledge.md (rules), skill.md (runtime + routing), patterns.md (one-pager, deck, email, integrity-check templates).

## Exported Files

- AIPSL_Pass10_Capability_Expansion/skill.md
- AIPSL_Pass10_Capability_Expansion/patterns.md
- AIPSL_Pass10_Capability_Expansion/knowledge.md
- AIPSL_skill_pass10_capability_expansion.md
- AIPSL_patterns_pass10_capability_expansion.md
- AIPSL_knowledge_pass10_capability_expansion.md
- AIPSL_Refactor_Pass10_Capability_Expansion_Manifest.md
- Pass7_Source/ (retained source)

## Prior-Pass History (preserved)

- **Pass 9** — Added Standing Analytical Operating Standards, the Python Tooling Standard (Windows + Excel COM default), and the Brief/Deck/Executive Email Conversion Standard. Changelog entries remain intact inside each architecture file.
- **Pass 8** — Added Document Ingestion & File Triage, Data Analysis & Modeling, and Secure Offline Tool Development; expanded the skills menu from 12 to 15. Pass 8 changelog entries remain intact inside each architecture file.
- **Pass 7** — Skills menu build (retained in `Pass7_Source/`).

## Notes

The top-level active files may be write-protected by the runtime. The ZIP contains a folder with the correct install filenames: `skill.md`, `patterns.md`, and `knowledge.md`.
