# Build and Test Report — Version 2.1.0

Build date: 2026-08-05

## Upgrade scope implemented

Version 2.1 preserves all Version 2.0 analytic-workbench capabilities and enhances PDF import quality. The upgrade includes:

- Page-tree traversal and stable page-order extraction.
- Expansion of compressed PDF object streams.
- Page resource, font, and content-stream resolution.
- Embedded ToUnicode character-map decoding.
- Text extraction from invoked Form XObjects, including nested forms.
- Coordinate-based line reconstruction and configurable two-column ordering.
- Repeated header/footer detection across multi-page documents.
- Line-break hyphen repair.
- Duplicate overlay-text suppression.
- Ligature, zero-width, control-character, and common mojibake cleanup.
- Per-page quality scores and a user-visible extraction report.
- Controlled OCR fallback for likely page-sized JPEG images.
- OCR confidence and language-quality gates that reject artifact-heavy output.
- Configurable PDF import controls in Settings.
- PDF extraction quality and repair counts in source records and cumulative Markdown metadata.
- Revision-preserving re-extraction from retained original PDFs.

## Automated checks performed

### Static checks

- JavaScript syntax validation with Node.js for all application, worker, and service-worker scripts: PASS.
- Python syntax validation for launcher and browser test: PASS.
- HTML duplicate-ID validation: PASS.
- Application script and asset reference validation: PASS.
- SHA-256 known-vector check: PASS.

### Browser smoke and regression test

The execution environment blocks Chromium navigation to local HTTP addresses (`ERR_BLOCKED_BY_ADMINISTRATOR`). The test harness therefore loads the actual application HTML and JavaScript in Chromium and substitutes an in-memory database adapter for IndexedDB. The included Python server itself was reachable over `127.0.0.1` during the check. Results:

- Direct text import, stable source ID, and taxonomy: PASS.
- DOCX extraction: PASS.
- Basic PDF parsing: PASS.
- Three-page, two-column reading-order reconstruction: PASS.
- Repeated header/footer removal: PASS.
- Line-break hyphen repair: PASS.
- Duplicate text-overlay suppression: PASS.
- Embedded Unicode/ToUnicode font-map extraction: PASS.
- Form XObject text extraction: PASS.
- Low-quality OCR rejection: PASS.
- PDF extraction report display in import preview: PASS.
- Revision-preserving PDF re-extraction: PASS.
- Source revisioning and stable passage IDs: PASS.
- Evidence review, snapshots, change reports, and issue lifecycle: PASS.
- LLM-result reimport and citation validation: PASS.
- Reproducible ZIP package and analysis-run registry: PASS.
- Built-in diagnostics: PASS.
- Unhandled browser page errors: NONE.

The executable test is located at `tests/browser_smoke_test.py`. Regression fixtures are under `test-data/pdf-regression/`.

## PDF regression fixtures

- `multi-column-artifacts.pdf`: repeated headers/footers, two columns, split-word hyphenation, and duplicate overlay text.
- `unicode-font-map.pdf`: embedded Unicode font and ToUnicode mappings.
- `form-xobject.pdf`: page text stored inside a Form XObject.
- `scanned-image.pdf`: image-only page used to verify that poor OCR is rejected rather than appended.

## Remaining limitations

- Encrypted or password-protected PDFs must be unlocked before import.
- OCR fallback can directly process embedded JPEG page images; image-only pages using JBIG2, JPEG 2000, CCITT fax, or unsupported masks may require conversion.
- PDF layout inference is heuristic. Complex magazines, overlapping text, forms, irregular tables, vertical writing, and highly graphical documents still require review.
- Some fonts do not provide usable Unicode maps. Unmapped glyphs are counted and disclosed rather than replaced with invented text.
- Browser OCR remains less capable than a dedicated document-OCR engine. Low-quality output is deliberately rejected.
- The browser smoke harness does not replace testing with the target organization's browser policies and endpoint configuration.
