# Changelog

## 2.1.0 — 2026-08-05

- Replaced stream-concatenation PDF extraction with page-tree-aware processing.
- Added compressed object-stream expansion and page-order preservation.
- Added embedded ToUnicode font-map decoding for Unicode text.
- Added PDF Form XObject text extraction.
- Added coordinate-based line reconstruction and two-column ordering.
- Added repeated header/footer removal, line-break hyphen repair, ligature normalization, and duplicate-overlay suppression.
- Added page-level quality scoring and a visible PDF extraction/repair report.
- Added controlled page-image OCR fallback with confidence and language-quality rejection gates.
- Added configurable PDF repair and OCR thresholds.
- Added revision-preserving **Re-extract PDF** for retained originals.
- Added difficult-PDF regression fixtures and automated browser tests.

## 2.0.0 — 2026-08-05

- Added evidence-provenance and source-independence fields.
- Added TSA taxonomy and local tag suggestions.
- Added quality, evidence, collection-gap, duplicate, derivative, and contradiction reports.
- Added collection snapshots and change comparisons.
- Added weak-signal and issue lifecycle tracking.
- Added stable passage identifiers.
- Added related-source search, timeline, and dependency matrix.
- Added analysis-run registry and result reimport.
- Added citation validation and source-support heuristics.
- Added primary, murderboard, and collection-gap prompts.
- Added token-aware package warnings and expanded ZIP contents.
- Added encrypted backups, session lock, signature checks, DOCX safety limits, and database health checks.
- Added direct-file SHA-256 fallback and expanded diagnostics.
