# Third-Party Licenses

## JSZip 3.10.1

JSZip is distributed under the MIT License or GPL-3.0-or-later. This package uses it under the MIT option. The bundled minified file retains its upstream license header.

The remaining application code in this package was generated for the TSA Emerging Issues Source Aggregator and uses browser-native APIs.
