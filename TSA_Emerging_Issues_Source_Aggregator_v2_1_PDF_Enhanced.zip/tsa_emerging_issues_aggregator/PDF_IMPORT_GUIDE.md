# PDF Import and Repair Guide

## Recommended workflow

1. Import the PDF.
2. Expand **PDF extraction and repair report** in the review panel.
3. Review pages with low quality, no text, OCR substitution, or warnings.
4. Correct extracted text before adding the source when necessary.
5. After changing PDF settings, open the saved source and use **Re-extract PDF**.

## Settings

- **Repair line-break hyphenation:** joins words such as `environ-` plus `ment`.
- **Remove repeated PDF headers and footers:** removes short top/bottom lines repeated across at least three pages.
- **Detect and reorder two-column PDFs:** reads the left column before the right when a clear split is detected.
- **Preserve PDF page markers:** inserts `--- Page N ---` boundaries for later citation and review.
- **OCR low-text embedded JPEG pages:** attempts OCR when native text is absent or poor.
- **Maximum PDF pages for OCR fallback:** limits expensive OCR attempts.
- **Minimum native characters per page:** controls when OCR is considered.
- **Minimum OCR confidence:** rejects OCR below the selected threshold. A separate language-quality gate also blocks symbol-heavy or implausible output.

## Interpreting the report

The report lists extraction method, character count, quality, OCR confidence, detected columns, and warnings for each page. Repair totals show how much content was automatically changed. A low score is a review flag, not a statement about source reliability.

## Re-extraction

**Re-extract PDF** creates a new source revision using the retained original file and current settings. It preserves the source ID and the previous revision. Any manual edits in the current extraction are preserved in revision history but are replaced in the new revision by the fresh extraction.

## When conversion is needed

Convert the PDF before import when it is encrypted, damaged, entirely image-based with unsupported compression, or uses font encodings without usable Unicode mappings. Exporting a searchable PDF from a trusted local PDF/OCR tool is generally preferable to copying visibly garbled text.
