# TSA Emerging Issues Source Aggregator 2.1

A local-first, multi-file browser application for accumulating source material, preserving provenance, generating a cumulative Markdown collection, and preparing evidence-controlled prompts and packages for a GPT-5.5-based LLM.

Version 2.1 retains the Version 2 analytic workbench and replaces the original stream-level PDF reader with a page-aware extraction and repair pipeline. Existing IndexedDB source records, stable source IDs, revisions, and settings are migrated in place when the upgraded application opens.

## Start the application

### Windows

Extract the ZIP, then double-click:

```text
Start_App.cmd
```

The launcher starts a local-only Python server on `127.0.0.1:8765` and opens the application. If Python is unavailable, it opens `index.html` directly.

### macOS or Linux

```bash
./Start_App.sh
```

or:

```bash
python3 start_server.py
```

Use a current desktop version of Microsoft Edge or Google Chrome. The local server is recommended because browser security rules can restrict workers, Web Crypto, service workers, clipboard access, and persistent file handles under `file://`.

## Major Version 2 capabilities

### Evidence and provenance controls

Each source can record:

- Primary, secondary, tertiary, user-note, or unclassified source status.
- Source tier and publisher type.
- Original, derivative, syndicated, reposted, compiled, or unknown status.
- Independence group and derivative-source relationship.
- Reliability rating and rationale.
- Publication-date certainty.
- Potential bias or institutional interest.
- Processing, OCR, and duplicate warnings.

The **Quality & Evidence** workspace identifies metadata gaps, low primary-source coverage, stale sources, exact duplicates, derivative groups, potential contradictions, and issue-level evidence sufficiency.

### TSA taxonomy

Sources and issues can be tagged to configurable TSA-oriented fields, including:

- Transportation modes.
- TSA mission areas.
- Security layers.
- Threat actors.
- Attack methods.
- Vulnerabilities.
- Consequences.
- Cross-sector dependencies.

A local keyword engine suggests tags. Suggestions are editable and are not treated as analytic findings.

### What Changed reports

Create named collection snapshots and compare the current collection against a baseline. The application reports:

- Newly added sources.
- Removed or no-longer-active sources.
- Revised source records.
- New and rising terms.
- Mode and category coverage changes.
- Issue lifecycle changes.
- Potential contradictions in newly added material.

The comparison report can be exported as Markdown and included in an analysis package.

### Weak-signal and issue lifecycle register

Track issues through:

```text
Weak Signal → Candidate Issue → Emerging Issue → Established Issue → Declining Issue → Closed/Archived
```

Each record supports linked source IDs, first and last observation dates, modes, mission areas, dependencies, potential implications, reassessment triggers, disconfirming indicators, monitoring frequency, probability, confidence, owner, notes, and transition history.

### Stable passage identifiers

The cumulative Markdown file assigns paragraph-level identifiers such as:

```text
SRC-000001-R02-P0004
```

The identifier records source, source revision, and paragraph number. Editing a source creates a new revision and therefore a new passage-ID series rather than silently changing previously cited text.

### LLM-result reimport and citation validation

Paste or import an LLM result and link it to an analysis run. The validator checks for:

- Source IDs that do not exist.
- Page references beyond a source’s recorded page count.
- Factual-looking passages without citations.
- Citations with very low lexical overlap to the cited source.
- Claims that cite several records from only one independence group.
- Citation concentration and overreliance on a small number of sources.

These are local screening heuristics. They help focus human review but do not prove whether a claim is true or fully supported.

### Analysis-run registry

Every exported analysis package records:

- Run ID and creation time.
- Model designation.
- Included source IDs.
- Prompt text and prompt hash.
- Forecast horizon and selected baseline.
- Package manifest.
- Result-import status.

### Primary and red-team prompts

The application generates:

- TSA emerging-issues analysis prompt.
- Murderboard/red-team prompt.
- Collection-gap plan prompt.

The red-team prompt challenges base-rate neglect, selection bias, circular reporting, false emergence, reporting-volume fallacies, unsupported causality, false precision, probability-confidence confusion, TSA-relevance inflation, cascading-effect overreach, and recommendation mismatch.

### Timeline, dependencies, and local related-source search

- Timeline view combines source dates and issue lifecycle events.
- Dependency matrix maps open issues to supporting sectors and services.
- Related-source search uses local term-vector similarity. No source text is transmitted externally.

### Security and recovery enhancements

- File-size limits and basic signature checks.
- DOCX entry-count and expanded-size protections.
- Inert HTML extraction.
- Macro rejection and active-content suppression.
- CSV formula-injection protection.
- AES-GCM encrypted database backups when Web Crypto is available.
- Optional session interface lock.
- Source revision snapshots and restore controls.
- Database schema health checks.
- Strict Preservation Mode.

The session lock only blocks the application interface. It does not encrypt IndexedDB, browser caches, the device, or exported files.


## Enhanced PDF import in Version 2.1

The PDF pipeline now:

- Resolves the PDF page tree instead of concatenating unrelated streams.
- Expands compressed object streams used by many modern PDFs.
- Preserves page order and optional `--- Page N ---` markers.
- Uses embedded `ToUnicode` font maps to recover accented and non-ASCII text.
- Extracts text invoked through PDF Form XObjects.
- Reconstructs lines from text coordinates rather than PDF object order alone.
- Detects and reorders clear two-column layouts.
- Removes recurring headers and footers when they repeat across at least three pages.
- Repairs words split by line-break hyphenation.
- Suppresses duplicate overlay text commonly produced by OCR layers, shadows, or repeated drawing operations.
- Normalizes ligatures, zero-width characters, control characters, and common encoding artifacts.
- Scores each page for extraction quality and creates a page-by-page PDF extraction report.
- Attempts OCR only on likely page-sized embedded JPEG images when native text is insufficient.
- Rejects low-quality OCR output instead of automatically adding artifact-heavy text.
- Preserves the original PDF so an imported record can be re-extracted later with revised settings.

Open a PDF source in **Source Library** and select **Re-extract PDF** to create a new source revision without changing its stable source ID. The previous extraction remains available in revision history.

## Supported inputs

- TXT, Markdown, CSV, TSV, JSON, XML, HTML, LOG, and basic RTF.
- DOCX and DOCM; macros are ignored and never executed.
- PDF, using page-aware native-text extraction, embedded Unicode font maps, object-stream expansion, Form XObject extraction, layout repair, and controlled embedded-JPEG OCR fallback.
- PNG, JPG/JPEG, WEBP, BMP, GIF, TIFF where browser decoding is available.
- Direct pasted or typed text.

Legacy `.doc` files are deliberately rejected because a browser cannot reliably parse the binary format without a separate converter.

## PDF and OCR limitations

The enhanced PDF engine is fully local and handles substantially more PDFs than the earlier stream-level reader, but PDF is a highly variable format. The browser fallback cannot decrypt password-protected files and does not render every image compression format. Scanned pages using JBIG2, JPEG 2000, CCITT fax, or unusual masks may require conversion to a searchable PDF or high-resolution image before import.

Two-column detection, header/footer removal, and hyphen repair are configurable in **Settings**. Every repair is counted in the PDF extraction report. Disable a repair if a document's design causes an incorrect reconstruction, then use **Re-extract PDF**.

OCR is used only when native text is insufficient and a likely page-sized JPEG image is available. Low-confidence or linguistically implausible OCR is rejected to prevent garbled text from entering the Markdown collection. Browser `TextDetector` or locally available Tesseract.js is used when present; otherwise the application uses a limited template-matching fallback. Human review remains required for OCR-derived text.

## Core workflow

1. Import files or paste text.
2. Review extraction output, warnings, provenance, and suggested taxonomy.
3. Add the source to persistent browser storage.
4. Classify and revise records in Source Library.
5. Run Quality & Evidence review.
6. Create a collection snapshot.
7. Track weak signals and emerging issues.
8. Generate the primary and red-team prompts.
9. Export a reproducible analysis package.
10. Reimport the LLM response and validate citations.

## Analysis package contents

The ZIP package can contain:

```text
tsa-emerging-issues-analysis-package/
├── TSA_Emerging_Issues_Sources.md
├── TSA_Emerging_Issues_Sources_Volume_XX.md
├── TSA_Emerging_Issues_Analysis_Prompt.md
├── TSA_Emerging_Issues_Red_Team_Prompt.md
├── evidence-quality-report.md
├── changes-since-baseline.md
├── issue-register.md
├── analysis-run-registry.md
├── analysis-run.json
├── source-index.csv
├── collection-manifest.json
├── processing-warnings.txt
├── README.txt
└── original-sources/                 optional
```

Token estimates are approximate. Set a warning threshold and split packages by estimated token count when necessary. Individual source sections are not split across volumes.

## Persistence and migration

- IndexedDB database name remains `tsa-emerging-issues-aggregator`.
- Version 2 adds stores for snapshots, analysis runs, LLM results, issues, and quality reports.
- Existing sources are normalized with new fields but retain their IDs, order, text, metadata, status, and revisions.
- Stable source IDs are never reused.
- Rebuilding Markdown reconstructs the collection from source records.
- Browser privacy tools or profile deletion can still erase IndexedDB; maintain backups.

## Backup and restore

Use **Export Package → Backup database**.

- Leave the passphrase blank for a plain JSON backup.
- Enter at least eight characters for an AES-GCM encrypted `.tsaenc` backup.
- Encrypted backup creation and restore require Web Crypto; use the local server if direct-file mode does not expose it.

The JSON backup preserves extracted text, metadata, analytic registers, revisions, snapshots, and audit records. Original file blobs are not guaranteed to survive JSON serialization; include originals in an analysis package when they must be preserved externally.

## Developer tests

The `tests` directory includes a Playwright smoke test. The test creates a screenshot when it runs. It exercises synthetic text and DOCX inputs plus a difficult PDF regression set covering page trees, object streams, Unicode font maps, Form XObjects, two-column ordering, repeated headers and footers, split-word repair, duplicate overlays, OCR-quality rejection, PDF extraction reports, and revision-preserving re-extraction. It also verifies taxonomy, passage IDs, evidence review, snapshots, issue lifecycle, citation validation, ZIP construction, and built-in diagnostics.

Run from the extracted application directory in an environment with Python Playwright and Chromium:

```bash
python3 tests/browser_smoke_test.py
```

Ordinary application use does not require Playwright, Node.js, npm, or a build process.

## Troubleshooting

- **Application does not initialize:** use current Chrome or Edge and start through `Start_App.cmd`.
- **Old service-worker content appears:** close all tabs for the application, reopen it, or clear site data for `127.0.0.1:8765`.
- **Connected Markdown permission was lost:** reconnect the file and grant read/write permission.
- **PDF text order is incorrect:** change the PDF repair settings, especially two-column detection, then use **Re-extract PDF**.
- **PDF has little or no text:** expand the PDF extraction report. For image-only pages using unsupported compression, convert the document to a searchable PDF or high-resolution PNG/JPEG and import again.
- **PDF contains garbled OCR:** the application normally rejects low-quality OCR. Raise the minimum OCR confidence, disable OCR fallback, or import a better-quality scan.
- **OCR is inaccurate:** use a higher-resolution, upright, high-contrast image and correct the preview.
- **Encrypted backup is unavailable:** run through the included local server so Web Crypto is available.
- **Large collections become slow:** split exports, archive inactive records, limit OCR concurrency, and maintain regular backups.
