# Release Notes — Version 2.1 PDF Enhanced

This release focuses on the PDF artifacting reported in Version 2.0.

## Key changes

- Page-aware PDF reading instead of indiscriminate stream concatenation.
- Embedded Unicode font-map and Form XObject support.
- Coordinate-based line and paragraph reconstruction.
- Two-column reading-order detection.
- Repeated header/footer removal.
- Line-break hyphen repair.
- Duplicate overlay-text suppression.
- Page-level extraction-quality reporting.
- Low-quality OCR rejection.
- Configurable PDF repair settings.
- Non-destructive re-extraction of retained PDFs as a new source revision.

## Upgrade behavior

Use the same local address and port as the earlier application to retain the existing IndexedDB collection. Existing source IDs and revisions are not reset. Open an existing PDF in Source Library and select **Re-extract PDF** to apply the new engine.
