@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 start_server.py
  goto :eof
)
where python >nul 2>nul
if %errorlevel%==0 (
  python start_server.py
  goto :eof
)
echo Python was not found. Opening index.html directly in your default browser.
start "" index.html
pause
