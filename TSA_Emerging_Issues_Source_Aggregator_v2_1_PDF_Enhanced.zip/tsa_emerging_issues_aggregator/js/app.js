(async function(){
  const A=window.TSAApp,save=document.getElementById('saveStatus');
  try{
    save.textContent='Opening browser database…';
    await A.db.open();
    const health=await A.db.health();
    if(!health.ok)throw new Error(`Database schema is incomplete: ${health.missing.join(', ')}`);
    await A.db.load();
    A.state.latestQuality=A.state.qualityReports[0]||null;
    save.textContent='Rebuilding collection…';
    await A.markdown.rebuild({incrementRevision:false});
    await A.ui.init();
    A.state.initialized=true;
    save.textContent=`Saved locally · ${A.state.sources.length} source(s)`;
    document.getElementById('localStatus').textContent=location.protocol==='file:'?'Local file mode':'Local processing · no external APIs';
    if(navigator.storage?.persist)navigator.storage.persist().then(granted=>A.db.log('Persistent storage request',granted?'success':'warning','',granted?'Browser granted persistent storage':'Browser may evict storage under pressure')).catch(()=>{});
    if(location.protocol.startsWith('http')&&'serviceWorker'in navigator)navigator.serviceWorker.register('./service-worker.js').catch(()=>{});
    window.addEventListener('unhandledrejection',async e=>{console.error(e.reason);A.util.toast(`Error: ${e.reason?.message||e.reason}`);try{await A.db.log('Unhandled error','failed','',String(e.reason?.message||e.reason))}catch{}});
    window.addEventListener('error',async e=>{try{await A.db.log('Runtime error','failed','',String(e.message||'Unknown runtime error'))}catch{}});
  }catch(e){
    console.error(e);save.textContent='Initialization failed';
    document.getElementById('main').innerHTML=`<section class="panel"><h2>Application initialization failed</h2><p>${String(e.message||e)}</p><p>Use current Chrome or Edge. If direct file mode is restricted, start the included local server launcher.</p></section>`;
  }
})();
