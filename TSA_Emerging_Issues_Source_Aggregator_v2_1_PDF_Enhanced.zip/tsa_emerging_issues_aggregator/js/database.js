(function(){
  const A=window.TSAApp;
  const DB='tsa-emerging-issues-aggregator',VER=2;
  const reqP=req=>new Promise((res,rej)=>{req.onsuccess=()=>res(req.result);req.onerror=()=>rej(req.error)});
  function ensureStore(db,name,options,indexes=[]){let s;if(!db.objectStoreNames.contains(name))s=db.createObjectStore(name,options);else return;for(const [n,k,o] of indexes)s.createIndex(n,k,o||{unique:false})}
  function normalizeSource(s){
    const defaults={sourceClass:'Unclassified',sourceTier:'Not assessed',publisherType:'Unknown',originality:'Unknown',independenceGroup:'',derivativeOf:'',reliabilityRating:'Not assessed',reliabilityRationale:'',publicationCertainty:s.publicationDate?'Known':'Unknown',biasNotes:'',missionAreas:[],securityLayers:[],threatActors:[],attackMethods:[],vulnerabilities:[],consequences:[],dependencies:[],taxonomyTags:[],passageSchema:'revision-paragraph',status:'active',revision:1,processingWarnings:[],categories:[],modes:[],tags:[]};
    return {...defaults,...s,missionAreas:s.missionAreas||[],securityLayers:s.securityLayers||[],threatActors:s.threatActors||[],attackMethods:s.attackMethods||[],vulnerabilities:s.vulnerabilities||[],consequences:s.consequences||[],dependencies:s.dependencies||[],taxonomyTags:s.taxonomyTags||[]};
  }
  A.db={
    async open(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB,VER);r.onupgradeneeded=()=>{const db=r.result;ensureStore(db,'sources',{keyPath:'id'},[['hash','hash'],['status','status'],['importedAt','importedAt']]);ensureStore(db,'audit',{keyPath:'id'},[['timestamp','timestamp']]);ensureStore(db,'settings',{keyPath:'key'});ensureStore(db,'meta',{keyPath:'key'});ensureStore(db,'revisions',{keyPath:'id'},[['sourceId','sourceId'],['timestamp','timestamp']]);ensureStore(db,'snapshots',{keyPath:'id'},[['createdAt','createdAt'],['kind','kind']]);ensureStore(db,'analysisRuns',{keyPath:'id'},[['createdAt','createdAt'],['status','status']]);ensureStore(db,'llmResults',{keyPath:'id'},[['importedAt','importedAt'],['runId','runId']]);ensureStore(db,'issues',{keyPath:'id'},[['status','status'],['updatedAt','updatedAt']]);ensureStore(db,'qualityReports',{keyPath:'id'},[['createdAt','createdAt']]);};r.onsuccess=()=>{A.state.db=r.result;resolve(r.result)};r.onerror=()=>reject(r.error)});},
    store(name,mode='readonly'){return A.state.db.transaction(name,mode).objectStore(name)},
    async all(name){return reqP(this.store(name).getAll())},async get(name,key){return reqP(this.store(name).get(key))},async put(name,val){return reqP(this.store(name,'readwrite').put(val))},async del(name,key){return reqP(this.store(name,'readwrite').delete(key))},async clear(name){return reqP(this.store(name,'readwrite').clear())},async byIndex(name,index,key){return reqP(this.store(name).index(index).getAll(key))},
    async load(){
      A.state.sources=(await this.all('sources')).map(normalizeSource).sort((a,b)=>(a.sequence||0)-(b.sequence||0));
      A.state.audit=(await this.all('audit')).sort((a,b)=>String(b.timestamp).localeCompare(String(a.timestamp)));
      A.state.snapshots=(await this.all('snapshots')).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
      A.state.analysisRuns=(await this.all('analysisRuns')).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
      A.state.llmResults=(await this.all('llmResults')).sort((a,b)=>String(b.importedAt).localeCompare(String(a.importedAt)));
      A.state.issues=(await this.all('issues')).sort((a,b)=>String(b.updatedAt).localeCompare(String(a.updatedAt)));
      A.state.qualityReports=(await this.all('qualityReports')).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
      const settings=await this.get('settings','app');if(settings)A.state.settings={...A.state.settings,...settings.value};const handle=await this.get('meta','connectedHandle');if(handle?.value)A.state.connectedHandle=handle.value;
      for(const s of A.state.sources)await this.put('sources',s);
    },
    async nextSequence(){const m=await this.get('meta','sequence');const existingMax=A.state.sources.reduce((n,s)=>Math.max(n,s.sequence||0),0);const n=Math.max(m?.value||0,existingMax)+1;await this.put('meta',{key:'sequence',value:n});return n},
    async saveSource(source){source=normalizeSource(source);await this.put('sources',source);const i=A.state.sources.findIndex(x=>x.id===source.id);if(i>=0)A.state.sources[i]=source;else A.state.sources.push(source);A.state.sources.sort((a,b)=>(a.sequence||0)-(b.sequence||0));return source},
    async revision(source,reason='edit'){const revision={id:A.util.uid('REV'),sourceId:source.id,timestamp:A.util.now(),reason,data:A.util.clone(source)};await this.put('revisions',revision);return revision},
    async log(action,result='success',sourceId='',message='',details={}){const item={id:A.util.uid('LOG'),timestamp:A.util.now(),action,result,sourceId,message,details};await this.put('audit',item);A.state.audit.unshift(item);return item},
    async saveSettings(){await this.put('settings',{key:'app',value:A.state.settings})},
    async health(){const stores=[...A.state.db.objectStoreNames];const expected=['sources','audit','settings','meta','revisions','snapshots','analysisRuns','llmResults','issues','qualityReports'];return {ok:expected.every(x=>stores.includes(x)),stores,missing:expected.filter(x=>!stores.includes(x)),sourceCount:(await this.all('sources')).length}},
    async backup(){return {application:'TSA Emerging Issues Source Aggregator',version:A.VERSION,schemaVersion:A.SCHEMA_VERSION,exportedAt:A.util.now(),sources:await this.all('sources'),audit:await this.all('audit'),settings:await this.all('settings'),meta:(await this.all('meta')).filter(x=>x.key!=='connectedHandle'),revisions:await this.all('revisions'),snapshots:await this.all('snapshots'),analysisRuns:await this.all('analysisRuns'),llmResults:await this.all('llmResults'),issues:await this.all('issues'),qualityReports:await this.all('qualityReports')};},
    async restore(data){if(!data||!Array.isArray(data.sources))throw new Error('Invalid backup file');const stores=['sources','audit','settings','meta','revisions','snapshots','analysisRuns','llmResults','issues','qualityReports'];for(const n of stores)await this.clear(n);for(const n of stores)for(const x of(data[n]||[]))await this.put(n,x);await this.load();await this.log('Database restored','success','',`Restored ${data.sources.length} sources`)},
    normalizeSource
  };
})();
