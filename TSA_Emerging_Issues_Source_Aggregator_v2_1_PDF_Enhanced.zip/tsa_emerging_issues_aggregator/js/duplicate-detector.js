(function(){
  const A=window.TSAApp;
  function fingerprint(text=''){return A.util.normalizeText(text).toLowerCase().replace(/[^a-z0-9\s]/g,'').split(/\s+/).filter(Boolean).slice(0,1000)}
  function jaccard(a,b){const A1=new Set(a),B1=new Set(b);let n=0;for(const x of A1)if(B1.has(x))n++;return n/Math.max(1,A1.size+B1.size-n)}
  A.duplicates={
    exact(hash){return A.state.sources.filter(s=>s.hash&&s.hash===hash)},
    likely(candidate){const fp=fingerprint(candidate.editedText||candidate.originalText||candidate.text);return A.state.sources.map(s=>{let score=0;if(candidate.originalFilename&&s.originalFilename&&candidate.originalFilename.toLowerCase()===s.originalFilename.toLowerCase())score+=.3;if(candidate.title&&s.title&&candidate.title.toLowerCase()===s.title.toLowerCase())score+=.2;if(candidate.fileSize&&s.fileSize&&candidate.fileSize===s.fileSize)score+=.15;score+=jaccard(fp,fingerprint(s.editedText||s.originalText))*.55;return {source:s,score}}).filter(x=>x.score>=.72).sort((a,b)=>b.score-a.score).slice(0,5)}
  };
})();
