(function(){
  const A=window.TSAApp;
  A.fileSystem={
    supported(){return 'showSaveFilePicker'in window},
    async connect(){if(!this.supported())throw new Error('The File System Access API is not available. Use Download .md instead.');const handle=await window.showSaveFilePicker({suggestedName:'TSA_Emerging_Issues_Sources.md',types:[{description:'Markdown file',accept:{'text/markdown':['.md']}}]});A.state.connectedHandle=handle;try{await A.db.put('meta',{key:'connectedHandle',value:handle})}catch(e){await A.db.log('File handle persistence warning','warning','',e.message)}await A.db.log('Markdown file connected','success','',handle.name);return handle},
    async permission(handle=A.state.connectedHandle){if(!handle)return false;let p=await handle.queryPermission({mode:'readwrite'});if(p==='prompt')p=await handle.requestPermission({mode:'readwrite'});return p==='granted'},
    async writeConnected(text=A.state.markdown){const h=A.state.connectedHandle;if(!h)throw new Error('No local Markdown file is connected.');if(!(await this.permission(h)))throw new Error('Write permission was not granted for the connected file.');const w=await h.createWritable();await w.write(text);await w.close();await A.db.put('meta',{key:'lastConnectedWrite',value:A.util.now()});await A.db.log('Connected file updated','success','',h.name);return h.name},
    downloadMarkdown(text=A.state.markdown,name='TSA_Emerging_Issues_Sources.md'){A.util.download(name,new Blob([text],{type:'text/markdown;charset=utf-8'}))}
  };
})();
