(function(){
  const A=window.TSAApp;
  const stop=new Set(('a an and are as at be been being but by can could did do does for from had has have he her hers him his how i if in into is it its may might more most must no not of on or our ours shall she should so than that the their theirs them then there these they this those to under up us was we were what when where which who will with would you your report reports source sources said says according new also one two three government tsa transportation security issue issues system systems united states u s'.split(/\s+/)));
  const neg=new Set(['no','not','never','none','without','unlikely','denied','reject','false','decrease','decline','reduced','failed']);
  function tokens(text){return String(text).toLowerCase().replace(/https?:\/\/\S+/g,' ').replace(/[^a-z0-9%$-]+/g,' ').split(/\s+/).filter(x=>x.length>2&&!stop.has(x))}
  function sentences(text){return String(text).replace(/\s+/g,' ').split(/(?<=[.!?])\s+(?=[A-Z0-9])/).map(x=>x.trim()).filter(x=>x.length>20)}
  function termCounts(sources){const c={};for(const s of sources){const seen=new Set(tokens(`${s.title} ${s.editedText||s.originalText||''}`).slice(0,15000));for(const t of seen)c[t]=(c[t]||0)+1}return c}
  function topTerms(sources,limit=40){return Object.entries(termCounts(sources)).sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0])).slice(0,limit).map(([term,count])=>({term,count}))}
  function vector(text){const m={};for(const t of tokens(text))m[t]=(m[t]||0)+1;return m}
  function cosine(a,b){const va=typeof a==='string'?vector(a):a,vb=typeof b==='string'?vector(b):b;let dot=0,aa=0,bb=0;for(const [k,v] of Object.entries(va)){aa+=v*v;if(vb[k])dot+=v*vb[k]}for(const v of Object.values(vb))bb+=v*v;return dot/Math.max(1,Math.sqrt(aa*bb))}
  function related(sourceId,limit=8){const src=A.util.byId(sourceId);if(!src)return[];const a=vector(`${src.title} ${src.editedText||''}`);return A.state.sources.filter(s=>s.id!==sourceId).map(s=>({source:s,score:cosine(a,`${s.title} ${s.editedText||''}`)})).filter(x=>x.score>.08).sort((x,y)=>y.score-x.score).slice(0,limit)}
  function contradictionCandidates(sources=A.state.sources,limit=20){
    const docs=sources.slice(-300).map((s,idx)=>{const text=`${s.title} ${s.editedText||''}`,v=vector(text),top=Object.entries(v).sort((a,b)=>b[1]-a[1]).slice(0,35).map(x=>x[0]);return {idx,s,v,top,sent:sentences(s.editedText||'').slice(0,35)}});
    const inv=new Map();for(const d of docs)for(const t of d.top){if(!inv.has(t))inv.set(t,[]);inv.get(t).push(d.idx)}
    const pairs=new Map();for(const ids of inv.values()){if(ids.length<2||ids.length>35)continue;for(let a=0;a<ids.length;a++)for(let b=a+1;b<ids.length;b++){const key=`${Math.min(ids[a],ids[b])}:${Math.max(ids[a],ids[b])}`;pairs.set(key,(pairs.get(key)||0)+1)}}
    const candidatePairs=[...pairs.entries()].filter(([,shared])=>shared>=2).sort((a,b)=>b[1]-a[1]).slice(0,4000);const out=[];
    for(const [key] of candidatePairs){const [i,j]=key.split(':').map(Number),A1=docs[i],B1=docs[j],sim=cosine(A1.v,B1.v);if(sim<.14)continue;let candidate=null;for(const a of A1.sent){const at=tokens(a),an=at.some(x=>neg.has(x));if(at.length<5)continue;for(const b of B1.sent){const bn=tokens(b).some(x=>neg.has(x));if(an===bn)continue;const ss=cosine(a,b);if(ss>.24){candidate={sourceA:A1.s.id,sourceB:B1.s.id,similarity:ss,sentenceA:a.slice(0,400),sentenceB:b.slice(0,400)};break}}if(candidate)break}if(candidate)out.push(candidate);if(out.length>=limit*3)break}
    return out.sort((a,b)=>b.similarity-a.similarity).slice(0,limit)
  }
  function passageTerms(text){return A.util.unique(tokens(text)).slice(0,200)}
  A.nlp={tokens,sentences,termCounts,topTerms,vector,cosine,related,contradictionCandidates,passageTerms};
})();
