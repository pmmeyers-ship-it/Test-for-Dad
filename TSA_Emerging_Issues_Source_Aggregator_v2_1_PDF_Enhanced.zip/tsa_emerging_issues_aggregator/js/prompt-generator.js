(function(){
  const A=window.TSAApp;
  const probability=`- Almost no chance: about 1–5 percent
- Very unlikely: about 5–20 percent
- Unlikely: about 20–40 percent
- Roughly even chance: about 40–60 percent
- Likely: about 60–80 percent
- Very likely: about 80–95 percent
- Almost certain: about 95–99 percent`;
  A.prompt={
    defaults:{horizon:'1–6 months',geo:'United States, with international developments relevant to U.S. transportation security',max:12,detail:'Detailed',ops:true,policy:true,gaps:true,scenarios:true,quant:false,leadership:true,extra:'',type:'Emerging Issues'},
    generate(o={}){o={...this.defaults,...o};if(o.type==='Murderboard / Red Team')return this.murderboard(o);const requested=[o.ops&&'operational considerations',o.policy&&'policy considerations',o.gaps&&'collection gaps',o.scenarios&&'scenarios, indicators, and warnings',o.quant&&'quantitative estimates only where the evidence supports them',o.leadership&&'a senior-leadership executive summary'].filter(Boolean).join('; ');
return `# Task: Identify Emerging Issues Affecting TSA and U.S. Transportation Security

You are supporting a strategic and operational emerging-issues review for the Transportation Security Administration (TSA). Analyze the accompanying source collection, evidence-quality report, issue register, and—when provided—the change report. Treat each section labeled with a stable source ID such as \`SRC-000001\` as distinct evidence. Generated prompts and analytic registers are context, not independent source evidence.

## Analysis Parameters

- **Geographic scope:** ${o.geo}
- **Primary forecast horizon:** ${o.horizon}
- **Maximum prioritized issues:** ${o.max}
- **Detail level:** ${o.detail}
- **Requested components:** ${requested||'prioritized emerging-issues analysis'}
${o.extra?`- **Additional instructions:** ${o.extra}`:''}

## Objective

Identify new or materially changing developments that could affect TSA operations, authorities, workforce, screening, technology, regulated entities, transportation systems, critical dependencies, or the broader U.S. transportation-security environment. Do not classify a longstanding issue as emerging unless the evidence shows a meaningful change in likelihood, capability, scale, velocity, consequences, geographic reach, operational relevance, or policy significance.

## Analytic Integrity Rules

1. Review the complete supplied collection before reaching conclusions.
2. Separate confirmed reporting, unconfirmed claims, assumptions, analytic judgments, and forecasts.
3. Do not treat inclusion in the collection as proof of accuracy.
4. Cite every material factual statement to source IDs and, when useful, stable passage IDs such as \`SRC-000001-R01-P0004\`.
5. Identify duplicate, derivative, syndicated, circular, or shared-independence reporting. Do not count it as independent corroboration.
6. Normally require at least ${Number(A.state.settings.evidenceMinSources)||2} genuinely independent sources for a material claim. Explicitly label exceptions and single-source reporting.
7. Prefer authoritative primary sources. Explain when a conclusion depends primarily on secondary or low-confidence sources.
8. Identify contradictions, extraction warnings, OCR uncertainty, missing metadata, stale evidence, and collection gaps.
9. Do not invent facts, dates, quotations, statistics, policies, authorities, source titles, passage IDs, or citations.
10. Use institutionally neutral, apolitical language suitable for senior TSA leadership.
11. Do not average ordinal ratings or manufacture numerical precision.
12. Distinguish probability from analytic confidence.

## Probability and Confidence

${probability}

- **High confidence:** strong, consistent, independently corroborated evidence with limited important gaps.
- **Moderate confidence:** credible evidence supports the judgment, but important gaps, assumptions, or inconsistencies remain.
- **Low confidence:** limited, fragmented, uncertain, potentially biased, weakly corroborated, or extraction-dependent evidence.

## Required Output

### 1. Executive Summary
Summarize the most important emerging issues, why they matter to TSA, which require near-term leadership attention, principal uncertainties, and collection limitations.

### 2. Prioritized Emerging-Issues Table

| Priority | Emerging Issue | What Is Changing | TSA Relevance | Modes Affected | Time Horizon | Direction | Probability | Confidence | Independent Evidence Groups | Supporting Sources/Passages |
|---|---|---|---|---|---|---|---|---|---:|---|

Use Direction: Increasing; Stable but elevated; Uncertain; Decreasing; or Potential discontinuity.

### 3. Detailed Issue Assessments
For each issue provide: key judgment; evidence; why it is emerging; TSA implications; modes and mission areas; dependencies and cascading effects; time horizon; probability; confidence; indicators and warnings; disconfirming indicators; collection gaps; alternative analysis; and proportionate TSA considerations.

### 4. What Changed
When a change report is supplied, explain which judgments are driven by newly added sources, rising topics, changed records, lifecycle transitions, or new contradictions. Do not confuse increased reporting volume with increased real-world risk.

### 5. Cross-Cutting Findings
Identify shared dependencies, cross-modal consequences, technological or cyber vulnerabilities, workforce effects, supply-chain effects, and weak signals that collectively suggest a larger development.

### 6. Weak Signals and Watchlist
For each weak signal, state what was observed, why it may matter, why evidence remains insufficient, the trigger for reassessment, monitoring frequency, and supporting source/passages.

### 7. Collection Gaps and Source Assessment
Prioritize gaps by how much resolving them could change issue ranking, probability, consequences, or TSA considerations. Assess primary-source coverage, originality, source independence, bias, OCR problems, contradictions, single-source claims, and uneven mode coverage.

### 8. Analytic Limitations
Explain limitations caused by source selection, missing dates or metadata, stale evidence, uneven coverage, OCR errors, duplicate reporting, and lack of classified, law-enforcement-sensitive, proprietary, or other nonpublic information.

## Citation Format

- \`[SRC-000001]\`
- \`[SRC-000001, p. 4]\`
- \`[SRC-000001-R01-P0004]\`
- \`[SRC-000001; SRC-000017]\`

Do not cite a source or passage that does not support the statement.

## Final Quality Review

Before completing the response, confirm that every issue is genuinely new or materially changing; factual claims are traceable; source independence has been evaluated; evidence and judgments are separated; probability and confidence are distinct; single-source claims and contradictions are identified; recommendations are proportionate; and unsupported speculation has been removed.`},
    murderboard(o={}){o={...this.defaults,...o};return `# Task: Red-Team the TSA Emerging-Issues Analysis

Act as an independent analytic murderboard. Review the source collection, evidence-quality report, change report, issue register, and the primary emerging-issues analysis. Your purpose is to identify methodological, evidentiary, technical, operational, and presentation weaknesses before senior review.

## Parameters
- **Geographic scope:** ${o.geo}
- **Forecast horizon:** ${o.horizon}
- **Required rigor:** ${o.detail}
${o.extra?`- **Additional instructions:** ${o.extra}`:''}

## Required Challenges

1. **Base-rate neglect:** Identify judgments that ignore historical frequency or confuse possibility with probability.
2. **Selection and availability bias:** Assess whether the imported collection overrepresents dramatic, recent, or easily available reporting.
3. **Circular reporting:** Identify duplicated, syndicated, derivative, or mutually dependent sources treated as independent corroboration.
4. **Source-quality weakness:** Flag conclusions resting on secondary, low-reliability, undated, OCR-damaged, or unidentified sources.
5. **False emergence:** Identify longstanding issues labeled emerging without evidence of material change.
6. **Reporting-volume fallacy:** Challenge claims based only on more mentions rather than actual change in risk, capability, exposure, or consequence.
7. **Unsupported causality:** Identify correlations, temporal sequences, or anecdotes presented as causal evidence.
8. **False precision:** Flag unjustified scores, percentages, rankings, weighted averages, or ordinal arithmetic.
9. **Probability-confidence confusion:** Identify cases where evidence quality is treated as likelihood or likelihood as confidence.
10. **Target-method disconnect:** Test whether threat actors, capabilities, attack methods, targets, and operational pathways are realistically connected.
11. **TSA relevance inflation:** Identify issues with weak or indirect connection to TSA authorities, operations, workforce, or regulated stakeholders.
12. **Missing alternatives:** Provide credible alternative explanations and disconfirming evidence.
13. **Cascading-effect overreach:** Test whether second-order effects have plausible mechanisms, timing, dependencies, and scale.
14. **Recommendation mismatch:** Identify actions that are disproportionate, outside authority, unsupported, duplicative, or insufficiently prioritized.
15. **Citation integrity:** Verify cited source IDs and passage IDs; identify nonexistent, invalid, or weakly supporting citations.

## Output

### Executive Murderboard Judgment
State whether the analysis is ready for leadership review, ready with revisions, or not ready.

### Critical Findings Table
| Severity | Vulnerability | Why It Matters | Affected Judgment/Section | Evidence | Required Fix |
|---|---|---|---|---|---|

### Reconstructed Priority List
Provide a revised list after removing unsupported, duplicated, or non-emerging issues.

### Strongest Alternative Analysis
Present the best competing interpretation of the evidence.

### Required Corrections
Separate mandatory corrections from optional improvements.

### Residual Uncertainty
Identify uncertainties that cannot be resolved from the current collection and the collection needed to resolve them.

Use source and passage citations. Do not invent evidence.`},
    collectionGapPrompt(){return `# Task: Build a TSA Emerging-Issues Collection Plan

Use the source collection, evidence-quality report, citation-validation report, and issue register to identify the highest-value information gaps. Rank gaps by the expected value of information: how much resolving the gap could change issue priority, probability, consequences, confidence, or TSA actions. For each gap, specify the question, why it matters, preferred primary-source type, relevant organizations, search terms, collection frequency, trigger for reassessment, and the judgment that could change.`},
    async append(text,type='Emerging Issues'){const rec=await A.db.get('meta','promptAppendices'),list=rec?.value||[];list.push({id:A.util.uid('PROMPT'),generatedAt:A.util.now(),type,text});await A.db.put('meta',{key:'promptAppendices',value:list});await A.db.log('Analysis prompt appended','success','',`${type} prompt appended to Markdown collection`);await A.markdown.rebuild();return list[list.length-1]}
  };
})();
