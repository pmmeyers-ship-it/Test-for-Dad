(function(){
  const A=window.TSAApp=window.TSAApp||{};
  A.VERSION='2.1.0';
  A.SCHEMA_VERSION='2.0';
  A.state={
    db:null,sources:[],audit:[],snapshots:[],analysisRuns:[],llmResults:[],issues:[],qualityReports:[],
    settings:{strictMode:false,autoWrite:false,darkMode:false,sizeWarning:50,maxImportMB:250,staleDays:365,evidenceMinSources:2,inactivityMinutes:0,ocrCharset:'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,:;!?%$#@&()-/\'"',modelDesignation:'GPT-5.5-based LLM',pdfRepairHyphenation:true,pdfRemoveHeaders:true,pdfDetectColumns:true,pdfPreservePageMarkers:true,pdfOcrFallback:true,pdfOcrMaxPages:20,pdfMinNativeChars:50,pdfMinOcrConfidence:45},
    pendingImports:[],currentPreview:null,connectedHandle:null,markdown:'',networkLog:[],initialized:false,latestQuality:null,latestChangeReport:null,toastTimer:null,lockTimer:null
  };
  A.util={
    now:()=>new Date().toISOString(),
    uid:(prefix='ID')=>`${prefix}-${Date.now().toString(36)}-${(globalThis.crypto?.getRandomValues?crypto.getRandomValues(new Uint32Array(1))[0]:Math.floor(Math.random()*0xffffffff)).toString(36)}`,
    formatBytes(n){if(!Number.isFinite(n))return'—';const u=['B','KB','MB','GB'];let i=0;while(n>=1024&&i<u.length-1){n/=1024;i++}return `${n.toFixed(i?1:0)} ${u[i]}`},
    escapeMd(s=''){return String(s).replace(/\r\n/g,'\n').replace(/\r/g,'\n')},
    escapeTable(s=''){return String(s).replace(/\|/g,'\\|').replace(/\r?\n/g,' ')},
    splitList(s=''){return Array.isArray(s)?s:String(s).split(/[;,\n]/).map(x=>x.trim()).filter(Boolean)},
    unique(a=[]){return [...new Set(a.filter(Boolean))]},
    estimateTokens(text=''){return Math.ceil(String(text).length/4)},
    words(text=''){return (String(text).trim().match(/\S+/g)||[]).length},
    async sha256(data){
      const bytes=data instanceof ArrayBuffer?new Uint8Array(data):data instanceof Uint8Array?data:new TextEncoder().encode(String(data));
      if(globalThis.crypto?.subtle){const hash=await crypto.subtle.digest('SHA-256',bytes);return [...new Uint8Array(hash)].map(b=>b.toString(16).padStart(2,'0')).join('')}
      const r=(n,x)=>(x>>>n)|(x<<(32-n)),K=new Uint32Array([0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]),H=new Uint32Array([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]);
      const bitLen=bytes.length*8,padLen=((bytes.length+9+63)>>6)<<6,msg=new Uint8Array(padLen);msg.set(bytes);msg[bytes.length]=0x80;const dv=new DataView(msg.buffer);dv.setUint32(padLen-4,bitLen>>>0,false);dv.setUint32(padLen-8,Math.floor(bitLen/0x100000000),false);const w=new Uint32Array(64);
      for(let off=0;off<padLen;off+=64){for(let i=0;i<16;i++)w[i]=dv.getUint32(off+i*4,false);for(let i=16;i<64;i++){const a=w[i-15],b=w[i-2],s0=(r(7,a)^r(18,a)^(a>>>3))>>>0,s1=(r(17,b)^r(19,b)^(b>>>10))>>>0;w[i]=(w[i-16]+s0+w[i-7]+s1)>>>0}let[a,b,c,d,e,f,g,h]=H;for(let i=0;i<64;i++){const S1=(r(6,e)^r(11,e)^r(25,e))>>>0,ch=((e&f)^((~e)&g))>>>0,t1=(h+S1+ch+K[i]+w[i])>>>0,S0=(r(2,a)^r(13,a)^r(22,a))>>>0,maj=((a&b)^(a&c)^(b&c))>>>0,t2=(S0+maj)>>>0;h=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0}H[0]=(H[0]+a)>>>0;H[1]=(H[1]+b)>>>0;H[2]=(H[2]+c)>>>0;H[3]=(H[3]+d)>>>0;H[4]=(H[4]+e)>>>0;H[5]=(H[5]+f)>>>0;H[6]=(H[6]+g)>>>0;H[7]=(H[7]+h)>>>0}
      return [...H].map(x=>x.toString(16).padStart(8,'0')).join('')
    },
    download(name,blob){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500)},
    csvCell(v){const s=String(v??'');const guarded=/^[=+\-@]/.test(s)?`'${s}`:s;return `"${guarded.replace(/"/g,'""')}"`},
    debounce(fn,ms=250){let t;return(...args)=>{clearTimeout(t);t=setTimeout(()=>fn(...args),ms)}},
    toast(msg){const el=document.getElementById('toast');if(!el)return;el.textContent=msg;el.classList.add('show');clearTimeout(A.state.toastTimer);A.state.toastTimer=setTimeout(()=>el.classList.remove('show'),3000)},
    safeName(s='file'){return String(s).replace(/[<>:"/\\|?*\x00-\x1F]/g,'_').replace(/\s+/g,'_').slice(0,120)||'file'},
    parseDate(s){if(!s)return'';const d=new Date(s);return Number.isNaN(d.valueOf())?'':d.toISOString().slice(0,10)},
    daysSince(s){if(!s)return null;const d=new Date(s);return Number.isNaN(d.valueOf())?null:Math.floor((Date.now()-d.valueOf())/86400000)},
    normalizeText(s=''){return String(s).replace(/\u0000/g,'').replace(/[ \t]+\n/g,'\n').replace(/\n{4,}/g,'\n\n\n').trim()},
    htmlToText(html=''){const doc=new DOMParser().parseFromString(String(html),'text/html');doc.querySelectorAll('script,style,iframe,object,embed,link,meta,svg').forEach(n=>n.remove());return A.util.normalizeText(doc.body?.innerText||doc.documentElement?.textContent||'')},
    route(view){document.querySelectorAll('.view').forEach(x=>x.classList.toggle('active',x.id===`view-${view}`));document.querySelectorAll('.nav-btn').forEach(x=>x.classList.toggle('active',x.dataset.view===view));},
    byId(id){return A.state.sources.find(s=>s.id===id)},
    dateLabel(s){if(!s)return'Unknown';const d=new Date(s);return Number.isNaN(d.valueOf())?s:d.toLocaleDateString()},
    percentage(n,d){return d?`${Math.round(n/d*100)}%`:'0%'},
    clone(v){return typeof structuredClone==='function'?structuredClone(v):JSON.parse(JSON.stringify(v))},
    event(name,detail){document.dispatchEvent(new CustomEvent(`tsa:${name}`,{detail}))}
  };
})();
