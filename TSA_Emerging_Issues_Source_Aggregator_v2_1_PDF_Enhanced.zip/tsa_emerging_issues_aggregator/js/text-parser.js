(function(){
  const A=window.TSAApp;
  function decodeXml(s){return s.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&apos;/g,"'")}
  function rtfToText(rtf){return A.util.normalizeText(rtf.replace(/\\par[d]?/g,'\n').replace(/\\tab/g,'\t').replace(/\\'[0-9a-fA-F]{2}/g,m=>String.fromCharCode(parseInt(m.slice(2),16))).replace(/\\u(-?\d+)\??/g,(_,n)=>String.fromCharCode(Number(n)<0?Number(n)+65536:Number(n))).replace(/\{\\\*[^{}]*\}/g,'').replace(/\\[a-zA-Z]+-?\d* ?/g,'').replace(/[{}]/g,''))}
  async function docxToText(buffer){
    if(!window.JSZip)throw new Error('DOCX support requires the bundled JSZip library.');
    const zip=await JSZip.loadAsync(buffer);const entries=Object.values(zip.files);if(entries.length>5000)throw new Error('The Word package contains too many entries and was blocked as potentially unsafe.');const declared=entries.reduce((n,e)=>n+(e._data?.uncompressedSize||0),0);if(declared>200*1024*1024)throw new Error('The Word package expands beyond the 200 MB safety limit.');const entry=zip.file('word/document.xml');if(!entry)throw new Error('The Word document does not contain word/document.xml.');
    const xml=await entry.async('string');const paragraphs=[];
    const pRe=/<w:p\b[\s\S]*?<\/w:p>/g;let p;
    while((p=pRe.exec(xml))){let block=p[0];let out='';const tokenRe=/<w:(t|tab|br|cr)\b[^>]*>([\s\S]*?)<\/w:\1>|<w:(tab|br|cr)\b[^>]*\/>/g;let t;while((t=tokenRe.exec(block))){const kind=t[1]||t[3];if(kind==='t')out+=decodeXml(t[2]||'');else if(kind==='tab')out+='\t';else out+='\n'}if(out.trim())paragraphs.push(out.trim())}
    const core=zip.file('docProps/core.xml');let metadata={};if(core){const c=await core.async('string');const get=tag=>{const m=c.match(new RegExp(`<[^:>]*:?${tag}[^>]*>([\\s\\S]*?)<\\/[^:>]*:?${tag}>`,'i'));return m?decodeXml(m[1].replace(/<[^>]+>/g,'')):''};metadata={title:get('title'),author:get('creator'),created:get('created'),modified:get('modified')}}
    return {text:A.util.normalizeText(paragraphs.join('\n\n')),metadata,warnings:[]};
  }
  A.textParser={
    async parse(file,buffer){const name=file.name||'source';const ext=(name.split('.').pop()||'').toLowerCase();const mime=file.type||'';let text='',metadata={},warnings=[];
      if(['docx','docm'].includes(ext)){const r=await docxToText(buffer);text=r.text;metadata=r.metadata;warnings=r.warnings;if(ext==='docm')warnings.push('Macros and active content were ignored and were not executed.');}
      else if(ext==='doc'){throw new Error('Legacy .doc files cannot be reliably parsed in a browser. Convert this file to .docx, .pdf, .rtf, or .txt.');}
      else{let decoded;try{decoded=new TextDecoder('utf-8',{fatal:true}).decode(buffer)}catch{decoded=new TextDecoder('windows-1252').decode(buffer);warnings.push('The file was decoded as Windows-1252 because UTF-8 decoding failed.')}if(['html','htm'].includes(ext)||mime.includes('html'))text=A.util.htmlToText(decoded);else if(ext==='rtf')text=rtfToText(decoded);else if(ext==='json'){try{text=JSON.stringify(JSON.parse(decoded),null,2)}catch{text=decoded;warnings.push('The JSON file could not be parsed; raw text was retained.')}}else if(ext==='xml')text=A.util.htmlToText(decoded.replace(/<\?xml[^>]*>/i,''));else text=decoded;}
      return {text:A.util.normalizeText(text),metadata,warnings,method:['docx','docm'].includes(ext)?'DOCX XML extraction':'Browser text decoding'};
    }
  };
})();
