(function(){
  const A=window.TSAApp;
  A.workers={
    async hash(buffer){
      if(!('Worker'in window)||location.protocol==='file:')return A.util.sha256(buffer);
      return new Promise(resolve=>{let settled=false;let worker;const fallback=async()=>{if(settled)return;settled=true;try{worker?.terminate()}catch{}resolve(await A.util.sha256(buffer))};try{worker=new Worker('workers/document-worker.js');const timer=setTimeout(fallback,4000);worker.onmessage=e=>{if(e.data?.type==='hashResult'){clearTimeout(timer);if(settled)return;settled=true;worker.terminate();resolve(e.data.hash)}else if(e.data?.error){clearTimeout(timer);fallback()}};worker.onerror=()=>{clearTimeout(timer);fallback()};worker.postMessage({type:'hash',buffer})}catch{fallback()}})
    },
    async ping(){if(!('Worker'in window))return false;return new Promise(resolve=>{let w;try{w=new Worker('workers/document-worker.js');const t=setTimeout(()=>{w.terminate();resolve(false)},2500);w.onmessage=e=>{if(e.data?.type==='pong'){clearTimeout(t);w.terminate();resolve(true)}};w.onerror=()=>{clearTimeout(t);w.terminate();resolve(false)};w.postMessage({type:'ping'})}catch{resolve(false)}})}
  };
})();
