#!/usr/bin/env python3
"""Small local-only server for the TSA Emerging Issues Source Aggregator."""
from __future__ import annotations
import argparse, http.server, socketserver, webbrowser, threading, os

class Handler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control','no-store')
        self.send_header('Cross-Origin-Opener-Policy','same-origin')
        self.send_header('Cross-Origin-Embedder-Policy','require-corp')
        super().end_headers()
    def log_message(self, fmt, *args):
        print('[local]', fmt % args)

def main():
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8765);p.add_argument('--no-browser',action='store_true');a=p.parse_args()
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    with socketserver.TCPServer(('127.0.0.1',a.port),Handler) as httpd:
        url=f'http://127.0.0.1:{a.port}/index.html'
        print(f'TSA Emerging Issues Source Aggregator: {url}')
        print('Press Ctrl+C to stop. No external network service is used.')
        if not a.no_browser: threading.Timer(.6,lambda:webbrowser.open(url)).start()
        try:httpd.serve_forever()
        except KeyboardInterrupt:pass

if __name__=='__main__':main()
