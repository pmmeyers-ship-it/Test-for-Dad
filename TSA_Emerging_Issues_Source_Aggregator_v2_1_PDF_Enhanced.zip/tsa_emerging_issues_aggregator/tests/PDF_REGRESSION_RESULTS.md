# PDF Regression Results — Version 2.1.0

Tested in headless Chromium using the application's production PDF parser.

| Fixture | Capability | Result |
|---|---|---|
| `multi-column-artifacts.pdf` | Page order | PASS |
| `multi-column-artifacts.pdf` | Two-column ordering across three pages | PASS |
| `multi-column-artifacts.pdf` | Repeated header and footer removal | PASS |
| `multi-column-artifacts.pdf` | Line-break hyphen repair | PASS |
| `multi-column-artifacts.pdf` | Duplicate overlay suppression | PASS |
| `unicode-font-map.pdf` | Embedded Unicode and ToUnicode recovery | PASS |
| `form-xobject.pdf` | Form XObject text extraction | PASS |
| `scanned-image.pdf` | Low-quality OCR rejection | PASS |
| Application UI | PDF extraction report in import preview | PASS |
| Application UI | Revision-preserving Re-extract PDF | PASS |

The scanned-page fixture intentionally exercises a weak local OCR result. The test passes only when the artifact-heavy output is rejected rather than appended to source text.
