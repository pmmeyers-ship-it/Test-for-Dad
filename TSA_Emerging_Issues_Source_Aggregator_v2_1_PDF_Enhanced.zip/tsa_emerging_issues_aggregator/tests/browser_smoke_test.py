#!/usr/bin/env python3
"""Developer smoke test for the local-first TSA Aggregator.
Uses an in-memory database adapter because this execution environment blocks normal browser navigation.
"""
from __future__ import annotations
import asyncio, base64, json, re
from pathlib import Path
from playwright.async_api import async_playwright

ROOT=Path(__file__).resolve().parents[1]
HTML=re.sub(r'<script[^>]*>.*?</script>','', (ROOT/'index.html').read_text(encoding='utf-8'), flags=re.S).replace('<link rel="manifest" href="manifest.webmanifest">','')
SCRIPTS=['vendor/jszip/jszip.min.js','js/state.js']
MODULES=['js/taxonomy.js','js/local-nlp.js','js/security.js','js/workers.js','js/text-parser.js','js/pdf-parser.js','js/image-ocr.js','js/duplicate-detector.js','js/file-importer.js','js/issue-tracker.js','js/quality.js','js/change-detector.js','js/citation-validator.js','js/prompt-generator.js','js/analysis-registry.js','js/markdown-builder.js','js/file-system.js','js/export.js','js/diagnostics.js','js/ui.js']
SESSION_SHIM="""(()=>{const m=new Map();Object.defineProperty(window,'sessionStorage',{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear()}});})();"""
FAKE_DB=r"""
(function(){const A=window.TSAApp;const stores={sources:new Map(),audit:new Map(),settings:new Map(),meta:new Map(),revisions:new Map(),snapshots:new Map(),analysisRuns:new Map(),llmResults:new Map(),issues:new Map(),qualityReports:new Map()};A.db={async open(){A.state.db={objectStoreNames:Object.keys(stores)}},async load(){},async all(n){return[...stores[n].values()]},async get(n,k){return stores[n].get(k)},async put(n,v){stores[n].set(v.id||v.key,v);return v},async del(n,k){stores[n].delete(k)},async clear(n){stores[n].clear()},async byIndex(n,index,key){return[...stores[n].values()].filter(x=>x[index]===key)},async nextSequence(){const m=stores.meta.get('sequence'),n=(m?.value||0)+1;stores.meta.set('sequence',{key:'sequence',value:n});return n},async saveSource(s){stores.sources.set(s.id,s);const i=A.state.sources.findIndex(x=>x.id===s.id);if(i>=0)A.state.sources[i]=s;else A.state.sources.push(s);return s},async revision(s,reason='edit'){const r={id:A.util.uid('REV'),sourceId:s.id,timestamp:A.util.now(),reason,data:A.util.clone(s)};stores.revisions.set(r.id,r);return r},async log(action,result='success',sourceId='',message='',details={}){const x={id:A.util.uid('LOG'),timestamp:A.util.now(),action,result,sourceId,message,details};stores.audit.set(x.id,x);A.state.audit.unshift(x);return x},async saveSettings(){stores.settings.set('app',{key:'app',value:A.state.settings})},async health(){return{ok:true,stores:Object.keys(stores),missing:[],sourceCount:A.state.sources.length}},async backup(){const o={};for(const[k,v]of Object.entries(stores))o[k]=[...v.values()];return{sources:o.sources,audit:o.audit,settings:o.settings,meta:o.meta,revisions:o.revisions,snapshots:o.snapshots,analysisRuns:o.analysisRuns,llmResults:o.llmResults,issues:o.issues,qualityReports:o.qualityReports}},async restore(){},normalizeSource:s=>s};})();
"""

def b64(path: Path)->str:
    return base64.b64encode(path.read_bytes()).decode('ascii')

async def main()->None:
    results=[]
    async with async_playwright() as p:
        browser=await p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
        page=await browser.new_page()
        errors=[]
        page.on('pageerror', lambda e: errors.append(str(e)))
        await page.set_content(HTML)
        await page.add_script_tag(content=SESSION_SHIM)
        for name in SCRIPTS:
            await page.add_script_tag(content=(ROOT/name).read_text(encoding='utf-8'))
        await page.add_script_tag(content=FAKE_DB)
        for name in MODULES:
            await page.add_script_tag(content=(ROOT/name).read_text(encoding='utf-8'))
        await page.evaluate("async()=>{await TSAApp.markdown.rebuild({incrementRevision:false});await TSAApp.ui.init();TSAApp.state.initialized=true;}")

        # Direct text import and taxonomy.
        await page.click('[data-view="import"]')
        await page.fill('#pasteTitle','Test Airport Cyber Source')
        await page.fill('#pasteOrg','Test Agency')
        await page.fill('#pasteDate','2026-08-04')
        await page.fill('#pasteText','A cyber incident disrupted an airport identity service. The disruption affected passenger screening and created flight delays.')
        await page.click('#savePastedText'); await page.wait_for_timeout(250)
        source=await page.evaluate('TSAApp.state.sources[0]')
        assert source['id']=='SRC-000001' and 'Aviation' in source['modes'] and 'Maritime' not in source['modes']
        results.append('Direct text import, stable ID, and taxonomy: PASS')

        # Parser checks using packaged synthetic files.
        docx_result=await page.evaluate("""async b=>{const u=Uint8Array.from(atob(b),c=>c.charCodeAt(0));const f=new File([u],'sample-source.docx',{type:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'});return TSAApp.textParser.parse(f,await f.arrayBuffer())}""", b64(ROOT/'test-data/sample-source.docx'))
        assert len(docx_result['text'])>20
        results.append('DOCX extraction: PASS')
        pdf_result=await page.evaluate("""async b=>{const u=Uint8Array.from(atob(b),c=>c.charCodeAt(0));const f=new File([u],'sample-source.pdf',{type:'application/pdf'});return TSAApp.pdfParser.parse(f,await f.arrayBuffer())}""", b64(ROOT/'test-data/sample-source.pdf'))
        assert 'warnings' in pdf_result and pdf_result['pdfDiagnostics']['pageCount']>=1
        results.append('PDF parser completed without crash: PASS')

        # Difficult PDF regression set: page order, columns, headers/footers, Unicode maps,
        # Form XObjects, line-break hyphenation, duplicate overlays, and low-quality OCR rejection.
        multi=await page.evaluate("""async b=>{const u=Uint8Array.from(atob(b),c=>c.charCodeAt(0));const f=new File([u],'multi-column-artifacts.pdf',{type:'application/pdf'});return TSAApp.pdfParser.parse(f,await f.arrayBuffer())}""", b64(ROOT/'test-data/pdf-regression/multi-column-artifacts.pdf'))
        assert 'operational environment requires resilient fallback' in multi['text']
        assert 'TSA Emerging Issues Working Draft' not in multi['text'] and 'Page 1 of 3' not in multi['text']
        repairs=multi['pdfDiagnostics']['artifactRepairs']
        assert repairs['columnPages']==3 and repairs['hyphenJoins']==3 and repairs['overlayDuplicates']==3
        unicode_pdf=await page.evaluate("""async b=>{const u=Uint8Array.from(atob(b),c=>c.charCodeAt(0));const f=new File([u],'unicode-font-map.pdf',{type:'application/pdf'});return TSAApp.pdfParser.parse(f,await f.arrayBuffer())}""", b64(ROOT/'test-data/pdf-regression/unicode-font-map.pdf'))
        assert 'résumé — naïve façade' in unicode_pdf['text'] and 'Łódź' in unicode_pdf['text']
        form_pdf=await page.evaluate("""async b=>{const u=Uint8Array.from(atob(b),c=>c.charCodeAt(0));const f=new File([u],'form-xobject.pdf',{type:'application/pdf'});return TSAApp.pdfParser.parse(f,await f.arrayBuffer())}""", b64(ROOT/'test-data/pdf-regression/form-xobject.pdf'))
        assert 'Text stored inside a PDF Form XObject' in form_pdf['text']
        scanned=await page.evaluate("""async b=>{const u=Uint8Array.from(atob(b),c=>c.charCodeAt(0));const f=new File([u],'scanned-image.pdf',{type:'application/pdf'});return TSAApp.pdfParser.parse(f,await f.arrayBuffer())}""", b64(ROOT/'test-data/pdf-regression/scanned-image.pdf'))
        assert not scanned['text'].strip() and any('rejected to prevent artifact text' in w for w in scanned['warnings'])
        results.append('Enhanced PDF layout, Unicode, Form XObject, repair, and OCR-quality controls: PASS')

        # Source revision and passage ID.
        await page.click('[data-view="library"]'); await page.click('.open-source')
        await page.select_option('#dialogSourceClass','Primary Source')
        await page.select_option('#dialogReliability','High')
        await page.click('#saveSourceEdit'); await page.wait_for_timeout(200)
        edited=await page.evaluate('TSAApp.state.sources[0]')
        assert edited['revision']==2 and edited['sourceClass']=='Primary Source'
        markdown=await page.evaluate('TSAApp.state.markdown')
        assert '[Passage ID: SRC-000001-R02-P0001]' in markdown
        results.append('Revision history and stable passage IDs: PASS')

        # Quality, snapshots, issues, and change detection.
        await page.click('[data-view="quality"]'); await page.click('#runQuality'); await page.wait_for_timeout(150)
        assert len(await page.locator('#qualityReport').input_value())>500
        await page.click('[data-view="changes"]'); await page.fill('#snapshotName','Smoke baseline'); await page.click('#createSnapshot'); await page.click('#compareSnapshot'); await page.wait_for_timeout(100)
        assert (await page.locator('#changeReport').input_value()).startswith('# Changes Since')
        await page.click('[data-view="issues"]'); await page.click('#newIssue'); await page.fill('#issueTitle','Airport identity-service disruption'); await page.fill('#issueSources','SRC-000001'); await page.fill('#issueModes','Aviation'); await page.fill('#issueDependencies','Identity Services; Cloud Services'); await page.click('#saveIssue'); await page.wait_for_timeout(100)
        assert await page.evaluate('TSAApp.state.issues.length')==1
        results.append('Evidence review, snapshots, delta report, and issue lifecycle: PASS')

        # LLM result validation.
        await page.click('[data-view="results"]'); await page.fill('#resultTitle','Smoke result'); await page.fill('#resultText','The airport identity service disrupted screening [SRC-000001].\n\nA claim cites a nonexistent source [SRC-999999].\n\nAnother unsupported factual claim states that 300 airports failed.')
        await page.click('#importResult'); await page.wait_for_timeout(120)
        validation=await page.evaluate('TSAApp.state.llmResults[0].validation')
        assert len(validation['invalidIds'])==1 and len(validation['uncitedParagraphs'])>=1
        results.append('LLM reimport and citation validation: PASS')

        # Package generation and content inspection.
        package=await page.evaluate("""async()=>{TSAApp.util.download=(name,blob)=>window.__capture={name,blob};const m=await TSAApp.exporter.package({activeOnly:true,includeOriginals:false,includeQuality:true,prompt:TSAApp.prompt.generate(),snapshotId:TSAApp.state.snapshots[0].id,tokenWarningThreshold:1});const z=await JSZip.loadAsync(window.__capture.blob);return {manifest:m,files:Object.keys(z.files)}}""")
        required={'tsa-emerging-issues-analysis-package/TSA_Emerging_Issues_Analysis_Prompt.md','tsa-emerging-issues-analysis-package/TSA_Emerging_Issues_Red_Team_Prompt.md','tsa-emerging-issues-analysis-package/evidence-quality-report.md','tsa-emerging-issues-analysis-package/issue-register.md','tsa-emerging-issues-analysis-package/analysis-run.json','tsa-emerging-issues-analysis-package/changes-since-baseline.md'}
        assert required.issubset(set(package['files'])) and package['manifest'].get('tokenWarning')
        results.append('Reproducible ZIP package and run registry: PASS')

        # PDF import preview report and non-destructive re-extraction of a retained original.
        await page.click('[data-view="import"]')
        pdf_b64=b64(ROOT/'test-data/pdf-regression/form-xobject.pdf')
        await page.evaluate("""b=>{const u=Uint8Array.from(atob(b),c=>c.charCodeAt(0));const f=new File([u],'form-xobject.pdf',{type:'application/pdf'});TSAApp.importer.enqueue([f])}""", pdf_b64)
        await page.wait_for_function("TSAApp.state.currentPreview && TSAApp.state.currentPreview.originalFilename==='form-xobject.pdf'", timeout=15000)
        assert not await page.locator('#previewPdfDetails').evaluate("e=>e.classList.contains('hidden')")
        assert 'PDF Extraction Report' in await page.locator('#previewPdfReport').input_value()
        await page.click('#commitPreview'); await page.wait_for_timeout(300)
        pdf_source=await page.evaluate("TSAApp.state.sources.find(s=>s.originalFilename==='form-xobject.pdf')")
        assert pdf_source and pdf_source['revision']==1 and pdf_source['pdfDiagnostics']['pageCount']==1
        await page.click('[data-view="library"]'); await page.click(f'.open-source[data-id="{pdf_source["id"]}"]')
        assert not await page.locator('#reprocessPdf').evaluate("e=>e.classList.contains('hidden')")
        await page.click('#reprocessPdf')
        await page.wait_for_function(f"TSAApp.state.sources.find(s=>s.id==='{pdf_source['id']}').revision===2", timeout=15000)
        assert 'PDF Extraction Report' in await page.locator('#dialogPdfReport').input_value()
        await page.locator('#sourceDialog button[value="cancel"]').last.click()
        results.append('PDF preview report and revision-preserving re-extraction: PASS')

        # Built-in self-tests.
        await page.click('[data-view="help"]'); await page.click('#runTests'); await page.wait_for_timeout(900)
        self_text=await page.locator('#testResults').inner_text()
        assert 'SHA-256: ba7816bf8f01' in self_text and 'fail' not in self_text.lower()
        results.append('Built-in diagnostics: PASS')
        assert not errors, f'Browser page errors: {errors}'
        await page.screenshot(path=str(ROOT/'tests/browser_smoke_test.png'), full_page=True)
        await browser.close()
    print('\n'.join(results))

if __name__=='__main__':
    asyncio.run(main())
