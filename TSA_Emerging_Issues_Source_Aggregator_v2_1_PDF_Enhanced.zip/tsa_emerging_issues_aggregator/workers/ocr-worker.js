// Optional pixel-processing worker. Recognition remains in the main thread because
// canvas/font template generation is not consistently available in workers.
self.onmessage=e=>{const d=e.data||{};if(d.type==='threshold'){const pixels=new Uint8ClampedArray(d.pixels);const out=new Uint8Array(pixels.length/4);for(let i=0;i<out.length;i++){const k=i*4;const g=.299*pixels[k]+.587*pixels[k+1]+.114*pixels[k+2];out[i]=g<(d.threshold||160)?1:0}self.postMessage({type:'thresholdResult',pixels:out},[out.buffer])}else if(d.type==='ping')self.postMessage({type:'pong'})}
