TSA PULSE — ADMINISTRATOR COMMAND CENTER
Executive Decision Intelligence Demonstration

IMPORTANT
This is a capability simulation containing entirely NOTIONAL data. It is not connected to TSA, DHS, airport, intelligence, law-enforcement, personnel, email, calendar, screening, or operational systems. It contains no real SSI, CUI, classified information, credentials, or personal employee records.

RUN
1. Extract the entire TSA_Pulse_Demo folder to a local Windows directory.
2. Keep the directory structure intact.
3. Double-click TSA_Pulse.hta.
4. If Windows prompts about opening an HTA, choose the normal Windows HTML Application host.

No web server, Internet connection, Node.js, Python, PowerShell, browser extension, package manager, or installation is required.

RECOMMENDED DISPLAY
1920x1080 Windows desktop. The application is also designed to remain usable at 1366x768.

FIVE-MINUTE DEMONSTRATION
1. HOME
   Start on the Administrator Executive Dashboard. Explain that the top row answers “What needs my attention?” in roughly 30 seconds.

2. DECISION
   Open “Enhanced Screening Technology Pilot Expansion.”
   Review the decision question and options.
   Click ASK PULSE or COMPARE OPTIONS.
   Approve or return the decision and show how the dashboard updates.

3. AIRPORTS
   Open Airports and show the stylized national visualization and notional wait times.
   Open MCO or another elevated airport.
   Ask Pulse why the airport is elevated.

4. PUBLIC ISSUE
   Open Public Issues and select “Summer Travel Screening Communications.”
   Explain the issue lifecycle and the relationship between operational conditions and public attention.

5. CALENDAR
   Open Calendar and select PREPARE ME on the next meeting.
   Review objective, participants, open issues, questions, talking points, and previous commitment.

6. PULSE
   Ask: “Give me my morning brief.”
   Ask: “What changed since yesterday?”
   Ask: “What should I do first?”

7. SCENARIO MODE
   Select “Summer Travel Surge” from the left sidebar.
   Observe airport waits, workforce pressure, public issues, and priorities change together.
   Ask Pulse: “What needs my attention today?”

8. TIME ADVANCE
   Use +6 HOURS or NEXT DAY to demonstrate changing conditions and reprioritization.
   Use RESET DEMO to restore the original baseline.

KEYBOARD
CTRL+K opens the Executive Command palette.
ESC closes overlays or the detail drawer.

PULSE SAMPLE QUESTIONS
- Give me my morning brief.
- What are the three things I need to get done today?
- What decisions are waiting on me?
- Which decision is most urgent?
- What happens if I delay that decision?
- What changed since yesterday?
- Which airports have the worst wait-time problems?
- Why is MCO elevated?
- Are wait times getting better or worse nationally?
- Which public issue is growing fastest?
- What congressional commitments are due?
- What am I waiting on from staff?
- What should I discuss with the COO?
- Prepare me for my next meeting.
- Summarize workforce conditions.
- What are my five biggest risks?
- Draft talking points on wait times.

DESIGN INTENT
This application demonstrates an executive operating environment in which dashboard information, decisions, tasks, calendar context, public issues, operating indicators, and a personal AI assistant share one local notional context. The design concept is “Pulse advises; the Administrator decides.”

HTA COMPATIBILITY
The application is written around IE11/MSHTML-era JavaScript and avoids fetch(), ES modules, npm, CDNs, and external libraries. Data is loaded from local JavaScript files.

LIMITATION
Because this package is generated outside Windows, final rendering is syntax-validated but cannot be fully exercised in the Windows mshta.exe host here. If a specific Windows policy blocks HTA execution, that is an environment control rather than a missing application dependency.
