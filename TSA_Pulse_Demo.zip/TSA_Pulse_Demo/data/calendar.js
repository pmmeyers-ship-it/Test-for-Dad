window.CALENDAR = [
  {
    "id": "E-501",
    "time": "09:00",
    "title": "Administrator Daily Operations Brief",
    "participants": "COO, Chief of Staff, Operations leadership",
    "objective": "Review overnight changes and peak-period posture.",
    "background": "Southeast airport wait times are elevated in the simulated dataset.",
    "issues": "Surge staffing; public communications; airport coordination",
    "decisions": "Confirm whether staffing contingency requires Administrator action today.",
    "questions": [
      "Which airports are deteriorating fastest?",
      "What is driving the change?",
      "What can improve by this afternoon?"
    ],
    "talking": [
      "Focus on exceptions, not national averages.",
      "Separate demand effects from staffing effects."
    ],
    "previous": "Requested a clear comparison to baseline and a 24-hour outlook."
  },
  {
    "id": "E-502",
    "time": "10:30",
    "title": "Technology Pilot Decision Review",
    "participants": "Requirements, Policy, Operations, Privacy",
    "objective": "Prepare for final pilot expansion decision.",
    "background": "Six-airport limited expansion is the staff recommendation.",
    "issues": "Readiness, training, evaluation metrics",
    "decisions": "Approve, return, or defer the package.",
    "questions": [
      "What evidence would change the recommendation?",
      "Are evaluation criteria measurable within 60 days?"
    ],
    "talking": [
      "Keep pilot bounded.",
      "Define stop conditions before launch."
    ],
    "previous": "Requested explicit review gate and cross-office concurrence."
  },
  {
    "id": "E-503",
    "time": "13:00",
    "title": "Airport Executive Call",
    "participants": "Representative airport executives",
    "objective": "Discuss late-summer travel conditions and partnership expectations.",
    "background": "Several airports are experiencing notional peak-period pressure.",
    "issues": "Queues, communications, coordination",
    "decisions": "No formal decision; capture commitments.",
    "questions": [
      "Where can HQ coordination remove friction?",
      "Which issues are common versus local?"
    ],
    "talking": [
      "Acknowledge local variation.",
      "Focus on shared passenger experience objectives."
    ],
    "previous": "Committed to return with an executive partnership forum concept."
  },
  {
    "id": "E-504",
    "time": "15:30",
    "title": "Congressional Preparation Session",
    "participants": "Legislative Affairs, Policy, Operations",
    "objective": "Prepare for staff-level oversight engagement.",
    "background": "Committee staff requested updated travel readiness information.",
    "issues": "Wait times, staffing, technology",
    "decisions": "Approve response posture.",
    "questions": [
      "What is confirmed?",
      "What is still changing?"
    ],
    "talking": [
      "Use clear trend language.",
      "Avoid overgeneralizing localized issues."
    ],
    "previous": "Provide updated passenger-volume and wait-time summary."
  },
  {
    "id": "E-505",
    "time": "17:00",
    "title": "Chief of Staff Closeout",
    "participants": "Chief of Staff",
    "objective": "Review open decisions, commitments, and tomorrow priorities.",
    "background": "Daily closeout.",
    "issues": "Overdue tasks and next-day priorities",
    "decisions": "Set top three priorities for tomorrow.",
    "questions": [
      "What did not close today?",
      "What will become urgent overnight?"
    ],
    "talking": [
      "Keep list to three priorities."
    ],
    "previous": "Maintain five-item morning priority list."
  }
];
