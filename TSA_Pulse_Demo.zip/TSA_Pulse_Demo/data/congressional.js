window.CONGRESSIONAL = [
  {
    "id": "C-401",
    "stakeholder": "House oversight staff",
    "topic": "Summer travel readiness",
    "commitment": "Provide updated passenger-volume and wait-time summary",
    "owner": "Legislative Affairs",
    "due": "2026-08-13",
    "sentiment": "Neutral",
    "status": "Ready for Review",
    "next": "Administrator clearance"
  },
  {
    "id": "C-402",
    "stakeholder": "Senate committee staff",
    "topic": "Technology pilot",
    "commitment": "Provide pilot evaluation framework",
    "owner": "Policy",
    "due": "2026-08-14",
    "sentiment": "Interested",
    "status": "In Progress",
    "next": "Complete metrics appendix"
  },
  {
    "id": "C-403",
    "stakeholder": "DHS leadership",
    "topic": "Travel surge posture",
    "commitment": "Provide daily executive summary",
    "owner": "Chief of Staff",
    "due": "2026-08-10",
    "sentiment": "Neutral",
    "status": "In Progress",
    "next": "Send simulated summary"
  },
  {
    "id": "C-404",
    "stakeholder": "Airport executive forum",
    "topic": "Partnership model",
    "commitment": "Return with engagement options",
    "owner": "Strategy",
    "due": "2026-08-20",
    "sentiment": "Positive",
    "status": "In Progress",
    "next": "Administrator decision"
  },
  {
    "id": "C-405",
    "stakeholder": "Surface transportation partners",
    "topic": "Exercise planning",
    "commitment": "Share proposed objectives",
    "owner": "Surface Operations",
    "due": "2026-08-18",
    "sentiment": "Positive",
    "status": "Not Started",
    "next": "Finalize draft objectives"
  },
  {
    "id": "C-406",
    "stakeholder": "Privacy stakeholder roundtable",
    "topic": "Technology modernization",
    "commitment": "Schedule follow-up briefing",
    "owner": "Policy",
    "due": "2026-08-15",
    "sentiment": "Constructive",
    "status": "Waiting",
    "next": "Confirm participants"
  },
  {
    "id": "C-407",
    "stakeholder": "DHS management office",
    "topic": "Budget execution",
    "commitment": "Submit milestone update",
    "owner": "Finance",
    "due": "2026-08-16",
    "sentiment": "Neutral",
    "status": "In Progress",
    "next": "Complete variance note"
  },
  {
    "id": "C-408",
    "stakeholder": "Airport association",
    "topic": "Wait-time trends",
    "commitment": "Share notional trend deck",
    "owner": "Operations",
    "due": "2026-08-12",
    "sentiment": "Concerned",
    "status": "In Progress",
    "next": "Validate figures"
  }
];
