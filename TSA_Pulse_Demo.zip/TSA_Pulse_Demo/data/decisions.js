window.DECISIONS = [
  {
    "id": "D-101",
    "title": "Enhanced Screening Technology Pilot Expansion",
    "office": "Requirements & Capabilities",
    "due": "2026-08-10 14:00",
    "priority": "Critical",
    "area": "Technology",
    "question": "Approve a limited expansion of the simulated checkpoint technology pilot to six additional airports?",
    "recommendation": "Approve limited expansion with a 60-day review gate and standardized performance reporting.",
    "options": [
      {
        "name": "A \u2014 Hold current footprint",
        "benefit": "Lowest implementation burden",
        "risk": "Delays evidence collection",
        "cost": "Low",
        "speed": "Immediate"
      },
      {
        "name": "B \u2014 Limited six-airport expansion",
        "benefit": "Balanced evidence and implementation pace",
        "risk": "Moderate coordination load",
        "cost": "Medium",
        "speed": "30 days"
      },
      {
        "name": "C \u2014 Broad national expansion",
        "benefit": "Fastest scaling",
        "risk": "Highest execution uncertainty",
        "cost": "High",
        "speed": "60 days"
      }
    ],
    "operational": "Medium positive",
    "workforce": "Moderate training demand",
    "public": "Potentially positive if passenger experience improves",
    "stakeholders": "Airport partners, airlines, technology offices",
    "dependencies": "Training package and site readiness confirmation",
    "delay": "Could shift deployment decision into peak fall planning cycle.",
    "status": "Pending",
    "confidence": "High"
  },
  {
    "id": "D-102",
    "title": "Summer Travel Staffing Contingency",
    "office": "Operations Support",
    "due": "2026-08-11 10:00",
    "priority": "High",
    "area": "Operations",
    "question": "Authorize a notional surge staffing contingency for selected high-growth airports through Labor Day?",
    "recommendation": "Authorize targeted surge with weekly reassessment.",
    "options": [
      {
        "name": "A \u2014 No surge",
        "benefit": "No additional cost",
        "risk": "Queue volatility persists",
        "cost": "Low",
        "speed": "Immediate"
      },
      {
        "name": "B \u2014 Targeted surge",
        "benefit": "Focuses resources at pressure points",
        "risk": "Requires coordination",
        "cost": "Medium",
        "speed": "7 days"
      },
      {
        "name": "C \u2014 Broad surge",
        "benefit": "Maximum buffer",
        "risk": "Inefficient resource use",
        "cost": "High",
        "speed": "14 days"
      }
    ],
    "operational": "High positive at selected airports",
    "workforce": "Overtime pressure but bounded",
    "public": "Could reduce visible queues",
    "stakeholders": "Airport leadership, field operations",
    "dependencies": "Regional staffing plans",
    "delay": "Wait-time exceptions may continue through the next peak weekend.",
    "status": "Pending",
    "confidence": "High"
  },
  {
    "id": "D-103",
    "title": "National Checkpoint Communications Campaign",
    "office": "Public Affairs",
    "due": "2026-08-12 12:00",
    "priority": "High",
    "area": "Communications",
    "question": "Approve a coordinated passenger-preparation communications campaign?",
    "recommendation": "Approve with emphasis on travel readiness and real-time airport coordination.",
    "options": [
      {
        "name": "A \u2014 Current messaging",
        "benefit": "No new effort",
        "risk": "Limited reach",
        "cost": "Low",
        "speed": "Immediate"
      },
      {
        "name": "B \u2014 Coordinated campaign",
        "benefit": "Higher reach and consistency",
        "risk": "Requires rapid content clearance",
        "cost": "Medium",
        "speed": "5 days"
      },
      {
        "name": "C \u2014 Paid national push",
        "benefit": "Maximum reach",
        "risk": "Higher cost and scrutiny",
        "cost": "High",
        "speed": "10 days"
      }
    ],
    "operational": "Indirect positive",
    "workforce": "Low burden",
    "public": "High visibility",
    "stakeholders": "Airports, airlines, travelers",
    "dependencies": "Content approval and partner alignment",
    "delay": "Narrative may be set by isolated wait-time stories.",
    "status": "Pending",
    "confidence": "Moderate"
  },
  {
    "id": "D-104",
    "title": "Credentialing Modernization Pilot",
    "office": "Enrollment Services",
    "due": "2026-08-14 17:00",
    "priority": "Medium",
    "area": "Credentialing",
    "question": "Proceed with a simulated modernization pilot for enrollment workflow?",
    "recommendation": "Proceed with limited pilot and clear success criteria.",
    "options": [
      {
        "name": "A \u2014 Defer",
        "benefit": "Avoid near-term change",
        "risk": "Modernization delay",
        "cost": "Low",
        "speed": "Immediate"
      },
      {
        "name": "B \u2014 Limited pilot",
        "benefit": "Manageable validation",
        "risk": "Pilot may not generalize",
        "cost": "Medium",
        "speed": "45 days"
      },
      {
        "name": "C \u2014 Accelerated rollout",
        "benefit": "Faster benefits",
        "risk": "Implementation risk",
        "cost": "High",
        "speed": "90 days"
      }
    ],
    "operational": "Medium positive",
    "workforce": "Moderate change-management",
    "public": "Low visibility",
    "stakeholders": "Enrollment partners",
    "dependencies": "Privacy and technical review",
    "delay": "Pushes evaluation into next fiscal cycle.",
    "status": "Pending",
    "confidence": "Moderate"
  },
  {
    "id": "D-105",
    "title": "Surface Security Exercise Strategy",
    "office": "Surface Operations",
    "due": "2026-08-17 09:00",
    "priority": "Medium",
    "area": "Surface",
    "question": "Select the next cycle of multi-modal tabletop exercise priorities?",
    "recommendation": "Prioritize cross-modal continuity and coordinated communications.",
    "options": [
      {
        "name": "A \u2014 Mode-specific exercises",
        "benefit": "Simpler planning",
        "risk": "Less cross-modal learning",
        "cost": "Medium",
        "speed": "60 days"
      },
      {
        "name": "B \u2014 Cross-modal exercises",
        "benefit": "Tests dependencies",
        "risk": "More complex coordination",
        "cost": "Medium",
        "speed": "75 days"
      },
      {
        "name": "C \u2014 National full-scale event",
        "benefit": "Broadest validation",
        "risk": "High planning burden",
        "cost": "High",
        "speed": "180 days"
      }
    ],
    "operational": "Preparedness benefit",
    "workforce": "Planning demand",
    "public": "Minimal",
    "stakeholders": "State/local and industry partners",
    "dependencies": "Partner availability",
    "delay": "Reduces preparation window before next exercise cycle.",
    "status": "Pending",
    "confidence": "Moderate"
  },
  {
    "id": "D-106",
    "title": "Airport Partnership Initiative",
    "office": "Strategy",
    "due": "2026-08-20 15:00",
    "priority": "Medium",
    "area": "Stakeholders",
    "question": "Approve a quarterly executive airport partnership forum?",
    "recommendation": "Approve a six-month trial with defined outcomes.",
    "options": [
      {
        "name": "A \u2014 Maintain bilateral outreach",
        "benefit": "Flexible",
        "risk": "Fragmented lessons",
        "cost": "Low",
        "speed": "Immediate"
      },
      {
        "name": "B \u2014 Quarterly forum",
        "benefit": "Shared learning",
        "risk": "Meeting load",
        "cost": "Low",
        "speed": "30 days"
      },
      {
        "name": "C \u2014 Monthly forum",
        "benefit": "Frequent alignment",
        "risk": "High executive burden",
        "cost": "Medium",
        "speed": "14 days"
      }
    ],
    "operational": "Indirect positive",
    "workforce": "Low",
    "public": "Low",
    "stakeholders": "Airport executives",
    "dependencies": "Secretariat support",
    "delay": "No major near-term consequence.",
    "status": "Pending",
    "confidence": "High"
  },
  {
    "id": "D-107",
    "title": "International Aviation Security Engagement Framework",
    "office": "Strategy",
    "due": "2026-08-12 12:00",
    "priority": "Low",
    "area": "Policy",
    "question": "Select a notional path forward for international aviation security engagement framework.",
    "recommendation": "Proceed with a bounded pilot and review gate.",
    "options": [
      {
        "name": "A \u2014 Defer",
        "benefit": "Lower burden",
        "risk": "Slower progress",
        "cost": "Low",
        "speed": "Immediate"
      },
      {
        "name": "B \u2014 Pilot",
        "benefit": "Balanced learning",
        "risk": "Manageable uncertainty",
        "cost": "Medium",
        "speed": "60 days"
      }
    ],
    "operational": "Low to medium",
    "workforce": "Low",
    "public": "Low",
    "stakeholders": "Internal and external partners",
    "dependencies": "Routine coordination",
    "delay": "Limited near-term impact.",
    "status": "Completed",
    "confidence": "Moderate"
  },
  {
    "id": "D-108",
    "title": "Technology Procurement Sequencing",
    "office": "Strategy",
    "due": "2026-08-13 12:00",
    "priority": "Low",
    "area": "Policy",
    "question": "Select a notional path forward for technology procurement sequencing.",
    "recommendation": "Proceed with a bounded pilot and review gate.",
    "options": [
      {
        "name": "A \u2014 Defer",
        "benefit": "Lower burden",
        "risk": "Slower progress",
        "cost": "Low",
        "speed": "Immediate"
      },
      {
        "name": "B \u2014 Pilot",
        "benefit": "Balanced learning",
        "risk": "Manageable uncertainty",
        "cost": "Medium",
        "speed": "60 days"
      }
    ],
    "operational": "Low to medium",
    "workforce": "Low",
    "public": "Low",
    "stakeholders": "Internal and external partners",
    "dependencies": "Routine coordination",
    "delay": "Limited near-term impact.",
    "status": "Returned",
    "confidence": "Moderate"
  },
  {
    "id": "D-109",
    "title": "Field Leadership Reporting Standard",
    "office": "Strategy",
    "due": "2026-08-14 12:00",
    "priority": "Low",
    "area": "Policy",
    "question": "Select a notional path forward for field leadership reporting standard.",
    "recommendation": "Proceed with a bounded pilot and review gate.",
    "options": [
      {
        "name": "A \u2014 Defer",
        "benefit": "Lower burden",
        "risk": "Slower progress",
        "cost": "Low",
        "speed": "Immediate"
      },
      {
        "name": "B \u2014 Pilot",
        "benefit": "Balanced learning",
        "risk": "Manageable uncertainty",
        "cost": "Medium",
        "speed": "60 days"
      }
    ],
    "operational": "Low to medium",
    "workforce": "Low",
    "public": "Low",
    "stakeholders": "Internal and external partners",
    "dependencies": "Routine coordination",
    "delay": "Limited near-term impact.",
    "status": "Completed",
    "confidence": "Moderate"
  },
  {
    "id": "D-110",
    "title": "Major Event Readiness Framework",
    "office": "Strategy",
    "due": "2026-08-15 12:00",
    "priority": "Low",
    "area": "Policy",
    "question": "Select a notional path forward for major event readiness framework.",
    "recommendation": "Proceed with a bounded pilot and review gate.",
    "options": [
      {
        "name": "A \u2014 Defer",
        "benefit": "Lower burden",
        "risk": "Slower progress",
        "cost": "Low",
        "speed": "Immediate"
      },
      {
        "name": "B \u2014 Pilot",
        "benefit": "Balanced learning",
        "risk": "Manageable uncertainty",
        "cost": "Medium",
        "speed": "60 days"
      }
    ],
    "operational": "Low to medium",
    "workforce": "Low",
    "public": "Low",
    "stakeholders": "Internal and external partners",
    "dependencies": "Routine coordination",
    "delay": "Limited near-term impact.",
    "status": "Returned",
    "confidence": "Moderate"
  },
  {
    "id": "D-111",
    "title": "Customer Experience Measurement Pilot",
    "office": "Strategy",
    "due": "2026-08-16 12:00",
    "priority": "Low",
    "area": "Policy",
    "question": "Select a notional path forward for customer experience measurement pilot.",
    "recommendation": "Proceed with a bounded pilot and review gate.",
    "options": [
      {
        "name": "A \u2014 Defer",
        "benefit": "Lower burden",
        "risk": "Slower progress",
        "cost": "Low",
        "speed": "Immediate"
      },
      {
        "name": "B \u2014 Pilot",
        "benefit": "Balanced learning",
        "risk": "Manageable uncertainty",
        "cost": "Medium",
        "speed": "60 days"
      }
    ],
    "operational": "Low to medium",
    "workforce": "Low",
    "public": "Low",
    "stakeholders": "Internal and external partners",
    "dependencies": "Routine coordination",
    "delay": "Limited near-term impact.",
    "status": "Completed",
    "confidence": "Moderate"
  },
  {
    "id": "D-112",
    "title": "Surface Stakeholder Communications Plan",
    "office": "Strategy",
    "due": "2026-08-17 12:00",
    "priority": "Low",
    "area": "Policy",
    "question": "Select a notional path forward for surface stakeholder communications plan.",
    "recommendation": "Proceed with a bounded pilot and review gate.",
    "options": [
      {
        "name": "A \u2014 Defer",
        "benefit": "Lower burden",
        "risk": "Slower progress",
        "cost": "Low",
        "speed": "Immediate"
      },
      {
        "name": "B \u2014 Pilot",
        "benefit": "Balanced learning",
        "risk": "Manageable uncertainty",
        "cost": "Medium",
        "speed": "60 days"
      }
    ],
    "operational": "Low to medium",
    "workforce": "Low",
    "public": "Low",
    "stakeholders": "Internal and external partners",
    "dependencies": "Routine coordination",
    "delay": "Limited near-term impact.",
    "status": "Returned",
    "confidence": "Moderate"
  }
];
