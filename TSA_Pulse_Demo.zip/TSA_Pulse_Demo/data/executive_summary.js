window.EXECUTIVE_SUMMARY = {
  "simDate": "2026-08-10T08:42:00",
  "greeting": "Good morning. Your simulated executive environment is current.",
  "portfolio": [
    {
      "name": "Aviation Operations",
      "status": "Stable",
      "trend": "\u2192",
      "attention": "Low"
    },
    {
      "name": "Surface Security",
      "status": "Watch",
      "trend": "\u2191",
      "attention": "Medium"
    },
    {
      "name": "Workforce",
      "status": "Watch",
      "trend": "\u2192",
      "attention": "Medium"
    },
    {
      "name": "Technology",
      "status": "Improving",
      "trend": "\u2191",
      "attention": "Medium"
    },
    {
      "name": "Public Affairs",
      "status": "Elevated",
      "trend": "\u2191",
      "attention": "High"
    },
    {
      "name": "Congressional",
      "status": "Stable",
      "trend": "\u2192",
      "attention": "Medium"
    },
    {
      "name": "Budget",
      "status": "Stable",
      "trend": "\u2192",
      "attention": "Low"
    }
  ]
};
