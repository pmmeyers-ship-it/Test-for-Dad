window.MESSAGES = [
  {
    "time": "08:42",
    "type": "Operations",
    "text": "Operations updated the Southeast airport status cluster."
  },
  {
    "time": "08:34",
    "type": "Public Affairs",
    "text": "Summer Travel Communications changed to Escalating."
  },
  {
    "time": "08:15",
    "type": "Pulse",
    "text": "Morning Brief generated from current notional data."
  },
  {
    "time": "07:58",
    "type": "Technology",
    "text": "Checkpoint technology decision package updated."
  },
  {
    "time": "07:41",
    "type": "Congressional",
    "text": "Committee response package marked Ready for Review."
  },
  {
    "time": "07:18",
    "type": "Workforce",
    "text": "Peak-period overtime indicator moved to Elevated."
  },
  {
    "time": "06:50",
    "type": "Calendar",
    "text": "Airport Executive Call participant list updated."
  }
];
