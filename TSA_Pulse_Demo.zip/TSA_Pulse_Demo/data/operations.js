window.OPERATIONS = [
  {
    "portfolio": "Aviation",
    "status": "Watch",
    "trend": "\u2191",
    "issue": "Localized peak-period wait-time pressure",
    "action": "Targeted staffing contingency under review",
    "milestone": "Administrator decision tomorrow"
  },
  {
    "portfolio": "Surface Transportation",
    "status": "Stable",
    "trend": "\u2192",
    "issue": "Exercise planning cycle",
    "action": "Cross-modal scenario selection",
    "milestone": "Leadership review next week"
  },
  {
    "portfolio": "Credentialing",
    "status": "Stable",
    "trend": "\u2191",
    "issue": "Modernization pilot package",
    "action": "Privacy and technical review",
    "milestone": "Decision Friday"
  },
  {
    "portfolio": "Screening Technology",
    "status": "Improving",
    "trend": "\u2191",
    "issue": "Pilot expansion decision",
    "action": "Six-airport limited expansion proposed",
    "milestone": "Decision today 1400"
  },
  {
    "portfolio": "International",
    "status": "Stable",
    "trend": "\u2192",
    "issue": "Routine partner engagements",
    "action": "Engagement framework implementation",
    "milestone": "Monthly review"
  },
  {
    "portfolio": "Security Operations",
    "status": "Stable",
    "trend": "\u2192",
    "issue": "No national exception",
    "action": "Routine coordination",
    "milestone": "Daily brief"
  },
  {
    "portfolio": "Emergency / Continuity",
    "status": "Stable",
    "trend": "\u2192",
    "issue": "Seasonal severe-weather readiness",
    "action": "Monitor regional forecasts",
    "milestone": "Daily readiness check"
  }
];
