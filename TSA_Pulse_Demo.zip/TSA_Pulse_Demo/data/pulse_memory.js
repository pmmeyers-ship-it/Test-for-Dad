window.PULSE_MEMORY_DEFAULTS = [
  "Administrator prefers a five-item morning priority list.",
  "Highlight deadlines within 48 hours.",
  "Always include the operational consequence of delaying a decision.",
  "Congressional commitments remain visible until confirmed complete.",
  "Pair public-affairs implications with significant operational issues.",
  "Prefer concise recommendations with a clear next action."
];
