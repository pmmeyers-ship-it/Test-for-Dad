window.RISKS = [
  {
    "id": "R-601",
    "category": "Operational",
    "description": "Localized airport queue pressure persists through peak travel periods.",
    "likelihood": "High",
    "impact": "Medium",
    "trend": "\u2191",
    "owner": "Operations",
    "mitigation": "Targeted staffing and airport coordination",
    "residual": "Medium",
    "admin": "Review contingency decision"
  },
  {
    "id": "R-602",
    "category": "Reputation",
    "description": "Localized wait-time stories shape a national narrative.",
    "likelihood": "Medium",
    "impact": "Medium",
    "trend": "\u2191",
    "owner": "Public Affairs",
    "mitigation": "Coordinated facts and passenger preparation messaging",
    "residual": "Medium",
    "admin": "Approve talking points"
  },
  {
    "id": "R-603",
    "category": "Technology",
    "description": "Pilot expansion outpaces training and evaluation readiness.",
    "likelihood": "Medium",
    "impact": "Medium",
    "trend": "\u2192",
    "owner": "Technology",
    "mitigation": "Limited expansion and 60-day gate",
    "residual": "Low",
    "admin": "Decision today"
  },
  {
    "id": "R-604",
    "category": "Workforce",
    "description": "Overtime pressure becomes concentrated at high-growth airports.",
    "likelihood": "Medium",
    "impact": "Medium",
    "trend": "\u2191",
    "owner": "Human Capital",
    "mitigation": "Targeted surge and scheduling adjustments",
    "residual": "Medium",
    "admin": "Monitor"
  },
  {
    "id": "R-605",
    "category": "Stakeholder",
    "description": "Airport partners receive inconsistent HQ engagement.",
    "likelihood": "Medium",
    "impact": "Low",
    "trend": "\u2192",
    "owner": "Strategy",
    "mitigation": "Structured partnership forum",
    "residual": "Low",
    "admin": "Decision pending"
  },
  {
    "id": "R-606",
    "category": "Schedule",
    "description": "Congressional response clearance misses committed deadline.",
    "likelihood": "Low",
    "impact": "Medium",
    "trend": "\u2192",
    "owner": "Legislative Affairs",
    "mitigation": "Early Administrator review",
    "residual": "Low",
    "admin": "Review by Thursday"
  },
  {
    "id": "R-607",
    "category": "Budget",
    "description": "Late-year execution limits flexibility for surge requirements.",
    "likelihood": "Low",
    "impact": "Medium",
    "trend": "\u2192",
    "owner": "Finance",
    "mitigation": "Weekly variance review",
    "residual": "Low",
    "admin": "No action today"
  },
  {
    "id": "R-608",
    "category": "External Environment",
    "description": "Severe weather disrupts multiple airport regions during peak travel.",
    "likelihood": "Medium",
    "impact": "High",
    "trend": "\u2192",
    "owner": "Continuity",
    "mitigation": "Regional readiness and communication protocols",
    "residual": "Medium",
    "admin": "Monitor"
  }
];
