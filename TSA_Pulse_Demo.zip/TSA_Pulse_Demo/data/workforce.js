window.WORKFORCE = [
  {
    "metric": "National staffing posture",
    "value": "Stable",
    "trend": "\u2192",
    "detail": "Aggregate simulated staffing remains within planned range."
  },
  {
    "metric": "Peak-period overtime pressure",
    "value": "Elevated",
    "trend": "\u2191",
    "detail": "Concentrated at selected high-growth airports."
  },
  {
    "metric": "Hiring pipeline",
    "value": "On Track",
    "trend": "\u2191",
    "detail": "Simulated onboarding volume is meeting plan."
  },
  {
    "metric": "Training throughput",
    "value": "Watch",
    "trend": "\u2192",
    "detail": "Technology pilot training creates temporary demand."
  },
  {
    "metric": "Attrition trend",
    "value": "Stable",
    "trend": "\u2192",
    "detail": "No material national change in simulated data."
  },
  {
    "metric": "Employee engagement",
    "value": "Stable",
    "trend": "\u2192",
    "detail": "No material change in demonstration data."
  },
  {
    "metric": "Leadership vacancies",
    "value": "Low",
    "trend": "\u2193",
    "detail": "Two simulated vacancies filled this month."
  },
  {
    "metric": "Schedule flexibility demand",
    "value": "Watch",
    "trend": "\u2191",
    "detail": "Peak travel surge is increasing shift-adjustment requests."
  }
];
