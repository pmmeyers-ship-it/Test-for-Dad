window.Briefing=(function(){
  function model(){
    var p=App.getPriorities(),air=App.getAirportExceptions(),issues=App.getEscalatingIssues(),dec=App.getPendingDecisions(),cal=App.state.calendar;
    return {priorities:p,airports:air,issues:issues,decisions:dec,calendar:cal};
  }
  function html(shortMode){
    var m=model(),h='';
    h+='<div class="brief-section"><h3>Overnight</h3><p>'+Util.esc(App.state.messages[0].text)+' '+Util.esc(App.state.messages[1].text)+'</p></div>';
    h+='<div class="brief-section"><h3>Administrator Decisions</h3><p>'+m.decisions.length+' decisions remain pending. '+(m.decisions.length?'Most urgent: '+Util.esc(m.decisions[0].title)+'.':'No pending decisions.')+'</p></div>';
    h+='<div class="brief-section"><h3>Operations</h3><p>'+m.airports.length+' representative airports are elevated or require Administrator attention in the notional dataset.</p></div>';
    h+='<div class="brief-section"><h3>Public Environment</h3><p>'+m.issues.length+' issues are Active or Escalating. '+(m.issues.length?'Highest visibility: '+Util.esc(m.issues[0].title)+'.':'No major issue.')+'</p></div>';
    if(!shortMode){h+='<div class="brief-section"><h3>Workforce</h3><p>National posture is stable, with simulated peak-period overtime pressure concentrated at selected high-growth airports.</p></div><div class="brief-section"><h3>Congress</h3><p>'+App.state.congress.length+' tracked notional commitments; the committee response package is ready for Administrator review.</p></div>';}
    h+='<div class="brief-section"><h3>Today</h3><p>'+App.state.calendar.length+' simulated executive events. First: '+Util.esc(App.state.calendar[0].time+' — '+App.state.calendar[0].title)+'.</p></div>';
    h+='<div class="brief-section"><h3>Pulse Recommendation</h3><p>1) Close the technology pilot decision. 2) Confirm the Southeast wait-time mitigation path. 3) Align operational facts and public messaging before the afternoon peak.</p></div>';
    return h;
  }
  function prepareMeeting(id){var e=App.findCalendar(id);if(!e)return;var h='<div class="eyebrow">Meeting Preparation</div><div class="pagetitle" style="font-size:21px">'+Util.esc(e.title)+'</div><div class="detail-section"><h4>Objective</h4><p>'+Util.esc(e.objective)+'</p></div><div class="detail-section"><h4>Participants</h4><p>'+Util.esc(e.participants)+'</p></div><div class="detail-section"><h4>Background</h4><p>'+Util.esc(e.background)+'</p></div><div class="detail-section"><h4>Open Issues</h4><p>'+Util.esc(e.issues)+'</p></div><div class="detail-section"><h4>Decisions Needed</h4><p>'+Util.esc(e.decisions)+'</p></div><div class="detail-section"><h4>Questions to Ask</h4><p>• '+Util.esc(e.questions.join('\n• '))+'</p></div><div class="detail-section"><h4>Talking Points</h4><p>• '+Util.esc(e.talking.join('\n• '))+'</p></div><div class="detail-section"><h4>Previous Commitment</h4><p>'+Util.esc(e.previous)+'</p></div><button class="btn btn-primary" onclick="Pulse.askContext(\'meeting\',\''+e.id+'\')">ASK PULSE</button>';App.openDrawer(h);}
  return {model:model,html:html,prepareMeeting:prepareMeeting};
})();
