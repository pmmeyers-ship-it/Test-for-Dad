window.Charts=(function(){
  function spark(values,w,h){
    w=w||190;h=h||42;if(!values||!values.length)return '';
    var min=values[0],max=values[0],i;for(i=1;i<values.length;i++){if(values[i]<min)min=values[i];if(values[i]>max)max=values[i];}
    var pts=[];for(i=0;i<values.length;i++){var x=i*(w-8)/(values.length-1)+4;var y=h-4-(max===min?h/2:(values[i]-min)*(h-8)/(max-min));pts.push(x.toFixed(1)+','+y.toFixed(1));}
    return '<svg class="spark" viewBox="0 0 '+w+' '+h+'" preserveAspectRatio="none"><polyline points="'+pts.join(' ')+'" fill="none" stroke="#45c8ed" stroke-width="2"/><line x1="0" y1="'+(h-3)+'" x2="'+w+'" y2="'+(h-3)+'" stroke="#173044"/></svg>';
  }
  function bars(items,max){var h='';var i;max=max||100;for(i=0;i<items.length;i++){var p=Math.max(3,Math.round(items[i].value/max*100));h+='<div class="rankbar"><div class="ranklabel">'+Util.esc(items[i].label)+'</div><div class="ranktrack"><div class="rankfill" style="width:'+p+'%"></div></div><div class="rankvalue">'+Util.esc(items[i].display===undefined?items[i].value:items[i].display)+'</div></div>';}return h;}
  return {spark:spark,bars:bars};
})();
