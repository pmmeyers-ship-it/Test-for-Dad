window.DecisionUI=(function(){
  function open(id){
    var d=App.findDecision(id);if(!d)return;
    var html='<div class="eyebrow">Decision Required</div><div class="pagetitle" style="font-size:21px">'+Util.esc(d.title)+'</div><div style="margin-top:8px">'+Util.status(d.priority)+' '+Util.status(d.status)+'</div>';
    html+='<div class="detail-section"><h4>The Question</h4><p>'+Util.esc(d.question)+'</p></div>';
    html+='<div class="detail-section"><h4>Why This Is Before You</h4><p>Sponsored by '+Util.esc(d.office)+'. Requested by '+Util.esc(d.due)+'. Consequence of delay: '+Util.esc(d.delay)+'</p></div>';
    html+='<div class="detail-section"><h4>Recommended Decision</h4><p>'+Util.esc(d.recommendation)+'</p></div>';
    html+='<div class="detail-section"><h4>Options</h4>';
    var i,o;for(i=0;i<d.options.length;i++){o=d.options[i];html+='<div class="optioncard"><div class="optiontitle">'+Util.esc(o.name)+'</div><p><b>Benefit:</b> '+Util.esc(o.benefit)+'<br><b>Risk:</b> '+Util.esc(o.risk)+'<br><b>Cost:</b> '+Util.esc(o.cost)+' &nbsp; <b>Implementation:</b> '+Util.esc(o.speed)+'</p></div>';}
    html+='</div><div class="detail-section"><h4>Impact</h4><p><b>Operational:</b> '+Util.esc(d.operational)+'<br><b>Workforce:</b> '+Util.esc(d.workforce)+'<br><b>Public:</b> '+Util.esc(d.public)+'<br><b>Dependencies:</b> '+Util.esc(d.dependencies)+'</p></div>';
    html+='<div class="detail-section"><h4>Pulse Assessment</h4><p>'+Util.esc(assessment(d))+'</p><div>'+Util.status(d.confidence+' confidence')+'</div></div>';
    html+='<div class="detail-section"><button class="btn btn-primary" onclick="Pulse.askContext(\'decision\',\''+d.id+'\')">ASK PULSE</button><button class="btn" onclick="Pulse.submitText(\'Compare options for '+Util.esc(d.title).replace(/'/g,"\\'")+'\')">COMPARE OPTIONS</button><button class="btn" onclick="Pulse.submitText(\'Generate questions for staff about '+Util.esc(d.title).replace(/'/g,"\\'")+'\')">GENERATE QUESTIONS</button></div>';
    if(d.status==='Pending')html+='<div class="detail-section"><button class="btn btn-good" onclick="DecisionUI.act(\''+d.id+'\',\'Approved\')">APPROVE</button><button class="btn btn-warn" onclick="DecisionUI.act(\''+d.id+'\',\'Returned\')">RETURN FOR INFO</button></div>';
    App.openDrawer(html);
  }
  function assessment(d){if(d.priority==='Critical')return 'This is the most time-sensitive pending policy decision in the demonstration. The recommended bounded option preserves flexibility while creating measurable evidence.';return 'The recommended option balances implementation speed, operational benefit, and reversibility within the notional evidence available.';}
  function act(id,status){var d=App.findDecision(id);if(!d)return;d.status=status;App.addActivity('Decision',d.title+' marked '+status+'.');App.notify('Decision',d.title+' — '+status);App.closeDrawer();Dashboard.renderAll();Pulse.systemNote('Decision updated: '+d.title+' is now '+status+'.');}
  return {open:open,act:act};
})();
