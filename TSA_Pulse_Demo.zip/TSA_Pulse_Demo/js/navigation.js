window.Nav = (function(){
  function show(page){
    var pages=document.getElementsByClassName('page'),items=document.getElementsByClassName('navitem'),i;
    for(i=0;i<pages.length;i++)pages[i].className=pages[i].className.replace(/ active/g,'');
    for(i=0;i<items.length;i++)items[i].className=items[i].className.replace(/ active/g,'');
    var p=Util.byId('page-'+page);if(p)p.className+=' active';
    var n=Util.byId('nav-'+page);if(n)n.className+=' active';
    if(window.Dashboard)Dashboard.renderPage(page);
    if(page==='pulse'&&window.Pulse)Pulse.focus();
    var c=Util.byId('content');if(c)c.scrollTop=0;
  }
  function init(){
    var items=document.getElementsByClassName('navitem'),i;
    for(i=0;i<items.length;i++)(function(x){x.onclick=function(){show(x.getAttribute('data-page'));};})(items[i]);
  }
  return {show:show,init:init};
})();
