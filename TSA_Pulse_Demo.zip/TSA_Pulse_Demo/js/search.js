window.SearchUI=(function(){
  function open(){var o=Util.byId('search-overlay');o.className='search-overlay open';var i=Util.byId('global-search');i.value='';i.focus();results('');}
  function close(){Util.byId('search-overlay').className='search-overlay';}
  function results(q){q=String(q||'').toLowerCase();var out=[],i,x;if(q.length<1){out.push({type:'Hint',title:'Search decisions, tasks, airports, issues, calendar, media, and stakeholders'});}else{
    for(i=0;i<App.state.decisions.length;i++){x=App.state.decisions[i];if((x.title+' '+x.office+' '+x.area).toLowerCase().indexOf(q)>=0)out.push({type:'Decision',title:x.title,action:"DecisionUI.open('"+x.id+"');SearchUI.close();"});}
    for(i=0;i<App.state.airports.length;i++){x=App.state.airports[i];if((x.code+' '+x.name).toLowerCase().indexOf(q)>=0)out.push({type:'Airport',title:x.code+' — '+x.name,action:"Dashboard.openAirport('"+x.code+"');SearchUI.close();"});}
    for(i=0;i<App.state.issues.length;i++){x=App.state.issues[i];if(x.title.toLowerCase().indexOf(q)>=0)out.push({type:'Public Issue',title:x.title,action:"Dashboard.openIssue('"+x.id+"');SearchUI.close();"});}
    for(i=0;i<App.state.tasks.length;i++){x=App.state.tasks[i];if((x.task+' '+x.owner).toLowerCase().indexOf(q)>=0)out.push({type:'Task',title:x.task,action:"Nav.show('tasks');SearchUI.close();"});}
    for(i=0;i<App.state.calendar.length;i++){x=App.state.calendar[i];if((x.title+' '+x.participants).toLowerCase().indexOf(q)>=0)out.push({type:'Calendar',title:x.time+' — '+x.title,action:"Briefing.prepareMeeting('"+x.id+"');SearchUI.close();"});}
  }
  var h='';for(i=0;i<Math.min(20,out.length);i++)h+='<div class="searchresult" '+(out[i].action?'onclick="'+out[i].action+'"':'')+'><div class="resulttype">'+Util.esc(out[i].type)+'</div><div class="resulttitle">'+Util.esc(out[i].title)+'</div></div>';Util.byId('search-results').innerHTML=h||'<div class="empty">No matching demonstration records.</div>';}
  return {open:open,close:close,results:results};
})();
