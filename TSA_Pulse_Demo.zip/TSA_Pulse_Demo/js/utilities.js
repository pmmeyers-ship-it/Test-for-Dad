window.Util = (function(){
  function esc(v){return String(v===undefined||v===null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
  function clone(v){return JSON.parse(JSON.stringify(v));}
  function byId(id){return document.getElementById(id);}
  function statusClass(s){s=String(s||'').toLowerCase();if(s.indexOf('attention')>=0||s.indexOf('critical')>=0||s.indexOf('escalat')>=0||s.indexOf('overdue')>=0)return 'status-red';if(s.indexOf('elevated')>=0||s.indexOf('watch')>=0||s.indexOf('high')>=0||s.indexOf('pending')>=0||s.indexOf('active')>=0||s.indexOf('waiting')>=0)return 'status-amber';if(s.indexOf('stable')>=0||s.indexOf('normal')>=0||s.indexOf('complete')>=0||s.indexOf('improving')>=0||s.indexOf('on track')>=0||s.indexOf('stabil')>=0)return 'status-green';return 'status-blue';}
  function status(s){return '<span class="status '+statusClass(s)+'">'+esc(s)+'</span>';}
  function pad(n){return n<10?'0'+n:String(n);}
  function dateTime(d){var x=d instanceof Date?d:new Date(d);return pad(x.getMonth()+1)+'/'+pad(x.getDate())+'/'+x.getFullYear()+' '+pad(x.getHours())+':'+pad(x.getMinutes());}
  function dateOnly(v){var d=new Date(String(v).replace(' ','T')); if(isNaN(d.getTime()))return v;return pad(d.getMonth()+1)+'/'+pad(d.getDate())+'/'+d.getFullYear();}
  function parseDate(v){var s=String(v||'').replace(' ','T');var d=new Date(s);return d;}
  function hoursUntil(v,now){var d=parseDate(v);return (d.getTime()-now.getTime())/3600000;}
  function sortPriority(a,b){var m={'Critical':0,'High':1,'Medium':2,'Low':3};return (m[a.priority]||9)-(m[b.priority]||9);}
  function el(tag,cls,html){var e=document.createElement(tag);if(cls)e.className=cls;if(html!==undefined)e.innerHTML=html;return e;}
  function pct(n,min,max){if(max===min)return 0;return Math.max(0,Math.min(100,Math.round((n-min)*100/(max-min))));}
  return {esc:esc,clone:clone,byId:byId,status:status,statusClass:statusClass,dateTime:dateTime,dateOnly:dateOnly,parseDate:parseDate,hoursUntil:hoursUntil,sortPriority:sortPriority,el:el,pct:pct};
})();
